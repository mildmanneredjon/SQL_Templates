/*
Fundamentals of Query Tuning: Common T-SQL Anti-Patterns

v1.0 - 2019-06-30

https://www.BrentOzar.com/go/queryfund


This demo requires:
* Any supported version of SQL Server
* Any Stack Overflow database: https://www.BrentOzar.com/go/querystack

This first RAISERROR is just to make sure you don't accidentally hit F5 and
run the entire script. You don't need to run this:
*/
RAISERROR(N'Oops! No, don''t just hit F5. Run these demos one at a time.', 20, 1) WITH LOG;
GO


/* I'm using the 50GB medium Stack database: */
USE StackOverflow2013;
GO
/* And this stored procedure drops all nonclustered indexes: */
DropIndexes;
GO
SET STATISTICS IO, TIME ON;
GO
/* Create a few indexes to support our queries: */
CREATE INDEX IX_Location ON dbo.Users(Location);
CREATE INDEX IX_UserId ON dbo.Comments(UserId);
CREATE INDEX IX_CreationDate ON dbo.Comments(CreationDate);
GO



/* Table Variables */
DECLARE @Users TABLE (Id INT);
INSERT INTO @Users (Id)
  SELECT Id
  FROM dbo.Users;

SELECT COUNT(*) FROM @Users;
GO



/* Multi-statement table-valued functions */
CREATE OR ALTER FUNCTION dbo.fn_GetUsers ( @Location NVARCHAR(200) )
RETURNS @Out TABLE ( UserId INT )
    WITH SCHEMABINDING
AS
    BEGIN
        INSERT  INTO @Out(UserId)
        SELECT  Id
        FROM    dbo.Users
        WHERE   Location = @Location;
		RETURN;
    END;
GO

SELECT * FROM dbo.fn_GetUsers( 'India' );
GO

SELECT c.*
  FROM dbo.fn_GetUsers ( 'India' ) u
  INNER JOIN dbo.Comments c ON u.UserId = c.UserId
  ORDER BY c.CreationDate;
GO



/* Functions in the WHERE clause - sometimes: */
SELECT *
  FROM dbo.Users
  WHERE Location = 'Helsinki, Finland';
GO

SELECT *
  FROM dbo.Users
  WHERE LTRIM(RTRIM(Location)) = 'Helsinki, Finland';
GO

SELECT *
  FROM dbo.Users
  WHERE UPPER(Location) = 'Helsinki, Finland';
GO

SELECT *
  FROM dbo.Users
  WHERE UpVotes + DownVotes > 1000000;
GO

/* Can we fix that with indexes? */



/* Sometimes, functions in the WHERE clause are okay though: */
SELECT *
  FROM dbo.Comments
  WHERE CAST(CreationDate AS DATE) = '2009-11-10';
GO


SELECT *
  FROM dbo.Users
  WHERE Location = LTRIM(RTRIM('Helsinki, Finland'));
GO





/* 
Implicit conversions: when SQL Server needs to compare two things, but the
datatypes aren't the same. Sometimes SQL Server can convert them automatically:
*/
DECLARE @Location XML = 'Helsinki, Finland';
SELECT *
  FROM dbo.Users
  WHERE Location = @Location;
GO

/* Or try this: */
DECLARE @Location VARCHAR(100) = 'Helsinki, Finland';
SELECT *
  FROM dbo.Users
  WHERE Location = @Location;
GO
/* Note - no warning in the plan.

Or this - note that I'm passing in a string, not a date:
*/
DECLARE @NotADate NVARCHAR(100) = '2009-11-10';
SELECT *
  FROM dbo.Comments
  WHERE CreationDate = @NotADate;
GO


/* 
But if you pass in a higher-fidelity datatype than what's stored in the table:
*/
DECLARE @NotADate SQL_VARIANT = '2009-11-10';
SELECT *
  FROM dbo.Comments
  WHERE CreationDate = @NotADate;
GO

/* 
Things to think about:

 * SQL Server up-converts what's in the table to match the incoming data type
 * The CPU use goes up linearly with the number of rows/columns to be converted
 * We get a scan, not a seek
 * The estimates are usually way off, too

Granted, you probably never see people using SQL_VARIANT (and now you know why.)

But I bet you see tables with VARCHAR in them, so let's set one up:
*/
CREATE TABLE dbo.Users_Varchar (Id INT PRIMARY KEY CLUSTERED, DisplayName VARCHAR(40));
INSERT INTO dbo.Users_Varchar (Id, DisplayName)
  SELECT Id, DisplayName
  FROM dbo.Users;
GO
CREATE INDEX IX_DisplayName ON dbo.Users_Varchar(DisplayName);
GO

/* Will our query use the index if we pass in an NVARCHAR variable? */
DECLARE @DisplayNameNvarchar NVARCHAR(40) = 'Brent Ozar';
SELECT *
  FROM dbo.Users_Varchar
  WHERE DisplayName = @DisplayNameNvarchar;
GO



/* This can hit you really hard on joins, so check the fields you join on: */
WITH ProblematicColumns AS  (
SELECT COLUMN_NAME
  FROM INFORMATION_SCHEMA.COLUMNS c1
  GROUP BY COLUMN_NAME
  HAVING COUNT(DISTINCT DATA_TYPE) > 1
)
SELECT c.*
  FROM ProblematicColumns pc
  INNER JOIN INFORMATION_SCHEMA.COLUMNS c ON pc.COLUMN_NAME = c.COLUMN_NAME
  ORDER BY c.COLUMN_NAME, c.DATA_TYPE;
GO




/* Comparing the contents of two columns in the same table: */
SELECT u.DisplayName, u.Id, COUNT(*) AS NumberOfComments
  FROM dbo.Users u
  INNER JOIN dbo.Comments c ON u.Id = c.UserId
  WHERE u.DownVotes + u.UpVotes > 1000000
  GROUP BY u.DisplayName, u.Id;
GO

/*
Things to think about:

 * How are estimates vs actuals?
 * What's the effect?
 * Can you fix the estimate by putting in indexes?
 * Can you imagine a scenario where this query runs very, very slowly?
 * How might you rework this query, either to fix the estimate, AND/OR reduce
   the blast radius of that bad estimate?
*/



/*
License: Creative Commons Attribution-ShareAlike 3.0 Unported (CC BY-SA 3.0)
More info: https://creativecommons.org/licenses/by-sa/3.0/

You are free to:
* Share - copy and redistribute the material in any medium or format
* Adapt - remix, transform, and build upon the material for any purpose, even 
  commercially

Under the following terms:
* Attribution - You must give appropriate credit, provide a link to the license,
  and indicate if changes were made.
* ShareAlike - If you remix, transform, or build upon the material, you must
  distribute your contributions under the same license as the original.
*/