USE [DBS_Maintenance]
GO

/****** Object:  Table [dbo].[node4_backup_query_test]    Script Date: 29/03/2019 10:22:29 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[node4_backup_query_test](
	[MachineName] [varchar](max) NULL,
	[WindowsVersion] [varchar](max) NULL,
	[SQL Version] [varchar](max) NULL,
	[IsClustered] [varchar](1) NULL,
	[InstanceName] [varchar](max) NULL,
	[database_name] [varchar](max) NULL,
	[Size(MB)] [bigint] NULL,
	[is_compressed] [varchar](max) NOT NULL,
	[is_encrypted] [varchar](max) NOT NULL,
	[Full] [varchar](4) NOT NULL,
	[FullSchedule(Days)] [int] NULL,
	[FullTime] [varchar](23) NULL,
	[FullSize(MB)] [bigint] NULL,
	[FullCompressedSize(MB)] [varchar](max) NULL,
	[Diff] [varchar](4) NOT NULL,
	[DiffSchedule(Days)] [int] NULL,
	[DiffTime] [varchar](23) NULL,
	[DiffSize(MB)] [bigint] NULL,
	[DiffCompressedSize(MB)] [varchar](max) NULL,
	[Log] [varchar](3) NOT NULL,
	[LogSchedule(Minutes)] [int] NULL,
	[LogTime] [varchar](23) NULL,
	[LogSize(MB)] [bigint] NULL,
	[LogCompressedSize(MB)] [varchar](max) NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO


