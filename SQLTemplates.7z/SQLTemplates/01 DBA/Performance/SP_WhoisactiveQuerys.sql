select * from
 
  (select cast  (query_plan as varchar(max)) xmltext,
  *
 from [DBSAdmin].[dbo].[WhoIsActive] (NOLOCK) ) a
 where xmltext like '%MissingIndexes%' and a.login_name = 'rs\Maestro'
and start_time between '2017-12-13 20:00:38.677' and '2017-12-20 04:00:38.677' and database_name = 'dw_edw'
 order by 2 desc 
 
 

 select * from
 
  (select cast  (sql_text as varchar(max)) xmltext,
  *
 from [DBSAdmin].[dbo].[WhoIsActive] (NOLOCK) ) a
 where xmltext like '%UPDATE EDW_DBO.DW_BIS_AGREEMENT_TRANSACTION_FACT%' and a.login_name = 'rs\Maestro'
 and start_time between '2017-12-13 20:00:38.677' and '2017-12-20 04:00:38.677' and database_name = 'dw_edw'
 order by start_time asc