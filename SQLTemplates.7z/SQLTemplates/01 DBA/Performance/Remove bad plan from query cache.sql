/*identify the plan_handle of the bad plan*/

select plan_handle, creation_time, last_execution_time, execution_count, qt.text
FROM 
   sys.dm_exec_query_stats qs
   CROSS APPLY sys.dm_exec_sql_text (qs.[sql_handle]) AS qt

/*Remove the bad plan*/

DBCC FREEPROCCACHE (plan_handle_id_goes_here)