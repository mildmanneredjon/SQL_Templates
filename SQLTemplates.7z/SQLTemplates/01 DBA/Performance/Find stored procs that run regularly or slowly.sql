/*
The following query shows stored procedures that have ran over @executions_per_hour_filter times per hour on average in the 1st result set
and stored procedures that take over @average_runtime_secs_filter to run on average in the 2nd result set
*/

declare @database varchar(128) = 'focalpoint'

declare @executions_per_hour_filter int = 0
declare @average_runtime_secs_filter decimal(3,1) = 0.1

declare @server_start_time datetime2
declare @hours_in_operation int

select @server_start_time = create_date from sys.databases
where database_id = 2

declare @ag_name varchar(128)

select @ag_name = AG.name
FROM master.sys.availability_groups AS AG
LEFT OUTER JOIN master.sys.dm_hadr_availability_group_states as agstates
   ON AG.group_id = agstates.group_id
INNER JOIN master.sys.availability_replicas AS AR
   ON AG.group_id = AR.group_id
INNER JOIN master.sys.dm_hadr_availability_replica_states AS arstates
   ON AR.replica_id = arstates.replica_id AND arstates.is_local = 1
INNER JOIN master.sys.dm_hadr_database_replica_cluster_states AS dbcs
   ON arstates.replica_id = dbcs.replica_id
where dbcs.database_name = @database

if @ag_name is not null
begin

declare @xel_path varchar(1024);
declare @utc_adjustment int = datediff(hour, getutcdate(), getdate());

-------------------------------------------------------------------------------
------------------- target event_file path retrieval --------------------------
-------------------------------------------------------------------------------
;with target_data_cte as
(
    select  
        *
    from sys.dm_xe_sessions s
    inner join sys.dm_xe_session_targets st
    on s.address = st.event_session_address
    where s.name = 'alwayson_health'
    and st.target_name = 'event_file'
),
full_path_cte as
(
    select
        full_path = 
            target_data.value('(EventFileTarget/File/@name)[1]', 'varchar(1024)')
    from target_data_cte
)
select
    @xel_path = 
        left(full_path, len(full_path) - charindex('\', reverse(full_path))) + 
        '\AlwaysOn_health*.xel'
from full_path_cte;

-------------------------------------------------------------------------------
------------------- replica state change events -------------------------------
-------------------------------------------------------------------------------
;with state_change_data as
(
    select
        object_name,
        event_data = 
            convert(xml, event_data)
    from sys.fn_xe_file_target_read_file(@xel_path, null, null, null)
)
 ,ag_start_end_times as
 (
select
    event_start = 
        dateadd(hour, @utc_adjustment, event_data.value('(event/@timestamp)[1]', 'datetime')),
	event_end = 
		isnull(LAG(dateadd(hour, @utc_adjustment, event_data.value('(event/@timestamp)[1]', 'datetime')),1) OVER (ORDER BY dateadd(hour, @utc_adjustment, event_data.value('(event/@timestamp)[1]', 'datetime')) desc),getdate()),
    ag_name = 
        event_data.value('(event/data[@name = "availability_group_name"]/value)[1]', 'varchar(64)'),
	node_state =
		event_data.value('(event/data[@name = "current_state"]/text)[1]', 'varchar(64)')
 --	hours_in_primary =
	--	datediff(hour,dateadd(hour, @utc_adjustment, event_data.value('(event/@timestamp)[1]', 'datetime')),isnull(LAG(dateadd(hour, @utc_adjustment, event_data.value('(event/@timestamp)[1]', 'datetime')),1) OVER (ORDER BY dateadd(hour, @utc_adjustment, event_data.value('(event/@timestamp)[1]', 'datetime')) desc),getdate()))
from state_change_data
where object_name = 'availability_replica_state_change'
and event_data.value('(event/data[@name = "current_state"]/text)[1]', 'varchar(64)') in ('primary_normal','secondary_normal')
)
select @hours_in_operation = sum(datediff(hour,event_start,event_end))
from ag_start_end_times
where event_start >= @server_start_time
and node_state = 'primary_normal'
and ag_name = @ag_name
end
else
begin
select @hours_in_operation = datediff(hour,@server_start_time,getdate())
end

/*Display all stored procedures that run on average more than @executions_per_hour_filter times per hour*/
SELECT OBJECT_NAME(object_id, database_id) 'proc name',   
    d.cached_time, d.last_execution_time, d.total_elapsed_time,  
    d.total_elapsed_time/d.execution_count AS [avg_elapsed_time],  
    d.last_elapsed_time, d.execution_count/@hours_in_operation as 'executions_per_hour'  
FROM sys.dm_exec_procedure_stats AS d  
where db_name(database_id) = @database
and d.execution_count/@hours_in_operation >= @executions_per_hour_filter
ORDER BY executions_per_hour DESC;

/*Display all stored procedures with a greater than  @average_runtime_secs_filter average runtime*/
SELECT OBJECT_NAME(object_id, database_id) 'proc name',   
    d.cached_time, d.last_execution_time, d.total_elapsed_time,  
    d.total_elapsed_time/d.execution_count AS [avg_elapsed_time],  
    d.last_elapsed_time, d.execution_count/@hours_in_operation as 'executions_per_hour'  
FROM sys.dm_exec_procedure_stats AS d  
where db_name(database_id) = @database
and d.total_elapsed_time/d.execution_count >= @average_runtime_secs_filter*1000000
ORDER BY executions_per_hour DESC;


