SELECT GETDATE()AS collectionTime
     , OBJECT_NAME(Object_id)
     , cached_time
     , execution_count
     , (execution_count * 1.0) / datediff(minute, cached_time, getdate()) AS [Count_per_min]
     , total_worker_time / 1000 AS total_worker_time_ms
     , total_worker_time / 1000 / execution_count AS avg_worker_time_ms
     , total_logical_reads
     , total_logical_reads / execution_count AS avg_logical_reads
     , total_elapsed_time / 1000 AS total_elapsed_time_ms
     , total_elapsed_time / 1000 / execution_count AS avg_elapsed_time_ms
FROM sys.dm_exec_procedure_stats
WHERE object_id IN(SELECT object_id
	         FROM sys.objects
	         WHERE name IN('<Procedure Name, sysname, up_procedure>'))
	AND execution_count > 0
ORDER BY total_elapsed_time / 1000 / execution_count DESC

