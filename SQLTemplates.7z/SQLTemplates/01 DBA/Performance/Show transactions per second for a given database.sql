DECLARE @duration datetime
SET @duration = '00:00:01'

DECLARE @Database varchar(30) = 'tempdb'
DECLARE @ctr bigint

SELECT @ctr = cntr_value
FROM sys.dm_os_performance_counters 
    WHERE counter_name = 'transactions/sec' 
        AND object_name = 'SQLServer:Databases' 
        AND instance_name = @Database

WAITFOR DELAY @duration

SELECT cntr_value - @ctr 
    FROM sys.dm_os_performance_counters 
    WHERE counter_name = 'transactions/sec' 
        AND object_name = 'SQLServer:Databases' 
       AND instance_name = @Database