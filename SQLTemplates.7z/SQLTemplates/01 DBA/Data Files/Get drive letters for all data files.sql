IF @@version LIKE 'Microsoft SQL Server  2000%'
begin
CREATE table #driveletter (driveletter char(1))
INSERT INTO #driveletter
EXEC    sp_msforeachdb
'use [?] SELECT distinct LEFT(filename,1) from sysfiles'
SELECT distinct * FROM #driveletter
DROP TABLE #driveletter
end
ELSE
begin
SELECT DISTINCT LEFT(filename,1) FROM sys.sysaltfiles
end