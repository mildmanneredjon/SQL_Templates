select *
       , 'DECLARE @StartSize INT; 
DECLARE @TargetSize INT;
DECLARE @msg varchar(50);

SET @StartSize = ' + CONVERT(VARCHAR(50),[FILE_SIZE_MB]) + ';
SET @TargetSize = ' + CONVERT(VARCHAR(50),[SPACE_USED_MB]+512) + ';

WHILE @StartSize > @TargetSize
BEGIN
       SET @StartSize = @StartSize - 128
          SET @msg = ''Starting shrink to: '' + CAST(@startSize AS VARCHAR(10)) + '' Time: ''
              SET @msg = @msg + convert( varchar(8), getdate(),108)
RAISERROR (@msg,10,0) WITH NOWAIT
    DBCC SHRINKFILE (N''' + NAME + ''' , @StartSize)
END;
GO' [Shrink_command]
from 
       (
              select
                     a.FILEID
                     , convert(decimal(12,2),round(a.size/128.000,2)) [FILE_SIZE_MB]
                     , convert(decimal(12,2),round(fileproperty(a.name,'SpaceUsed')/128.000,2)) [SPACE_USED_MB]
                     , convert(decimal(12,2),round((a.size-fileproperty(a.name,'SpaceUsed'))/128.000,2)) [FREE_SPACE_MB]
                     , a.NAME NAME
                     , a.FILENAME FILENAME
              from dbo.sysfiles a 
       ) a
