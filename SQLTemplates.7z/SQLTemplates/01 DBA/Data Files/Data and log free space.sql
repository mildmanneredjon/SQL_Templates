/*
The 1st result shows the aggregated free space for data and log files for the specified database

The 2nd result show the free space for each data and log file for the specified database

Set the value of @database_name as required
*/

declare @database_name varchar(256)

set @database_name = 'copy_nfs'

/*Aggregated file results - the results here should replicate dbcc sqlperf(logspace)*/

exec('use '+@database_name+';
	select 
	db_name(mf.database_id) as database_name, 
	case mf.type 
		when 0 then ''data''
		when 1 then ''log'' 
	end as file_type,
	sum(CAST((mf.SIZE * 8 / 1024.0) AS DECIMAL(18,2))) AS SIZEINMB,
	sum(cast(round(fileproperty(sf.name,''spaceused''),2)/128 as decimal(18,2))) as spaceused,
	cast(round(sum((fileproperty(sf.name,''spaceused'')/128))/sum(mf.SIZE * 8 / 1024.0)*100,2) as decimal(5,2)) as pct_used
from sys.master_files mf
inner join sysfiles sf
on mf.file_id = sf.fileid and db_name(mf.database_id) = '''+@database_name+'''
group by db_name(mf.database_id),case mf.type 
		when 0 then ''data''
		when 1 then ''log''
	end')


/*% used for each file*/

exec('use '+@database_name+'
select 
	mf.name as logical_name, 
	mf.physical_name,
	case mf.type 
		when 0 then ''data''
		when 1 then ''log''
	end as file_type,
	CAST((mf.SIZE * 8 / 1024.0) AS DECIMAL(18,2)) AS SIZEINMB,
	cast(round(fileproperty(sf.name,''spaceused''),2)/128 as decimal(18,2)) as spaceused,
	cast(round((fileproperty(sf.name,''spaceused'')/128)/(mf.SIZE * 8 / 1024.0)*100,2) as decimal(5,2)) as pct_used
from sys.master_files mf
inner join sysfiles sf
on mf.file_id = sf.fileid and db_name(mf.database_id) = '''+@database_name+'''
order by file_type,logical_name')
go
