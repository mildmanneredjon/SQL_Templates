with databasefilegroups (databasename, FilegroupName, DataFileName, Physical_Name, SizeMB, [ApportionedFileSize])
AS
(
select db_name() databasename
	, f.name FilegroupName
	, d.name DataFileName
	, d.physical_name Physical_Name
	, (d.size * 8) [SizeKB] 
	, (d.size * 8) / 8  [ApportionedFileSize] 
from [sys].[filegroups] f
INNER JOIN [sys].[database_files] d
    ON f.[data_space_id] = d.[data_space_id]
INNER JOIN [sys].[data_spaces] s
    ON f.[data_space_id] = s.[data_space_id]
)
select 
	'ALTER DATABASE [' + databasename + '] ADD FILE ( NAME = ''' + DataFileName +  '_2'', FILENAME = N''F:\MSSQL\Data\' + DataFileName + '_2.ndf'', SIZE = ' + CONVERT(VARCHAR(20),[ApportionedFileSize]) + 'KB , FILEGROWTH = 64MB ) TO FILEGROUP ['+FilegroupName+'];'
	+ CHAR(13) + 'ALTER DATABASE [' + databasename + '] ADD FILE ( NAME = ''' + DataFileName +  '_3'', FILENAME = N''I:\MSSQL\Data\' + DataFileName + '_3.ndf'', SIZE = ' + CONVERT(VARCHAR(20),[ApportionedFileSize]) + 'KB , FILEGROWTH = 64MB ) TO FILEGROUP ['+FilegroupName+'];'
	+ CHAR(13) + 'ALTER DATABASE [' + databasename + '] ADD FILE ( NAME = ''' + DataFileName +  '_4'', FILENAME = N''J:\MSSQL\Data\' + DataFileName + '_4.ndf'', SIZE = ' + CONVERT(VARCHAR(20),[ApportionedFileSize]) + 'KB , FILEGROWTH = 64MB ) TO FILEGROUP ['+FilegroupName+'];'
	+ CHAR(13) + 'ALTER DATABASE [' + databasename + '] ADD FILE ( NAME = ''' + DataFileName +  '_5'', FILENAME = N''M:\MSSQL\Data\' + DataFileName + '_5.ndf'', SIZE = ' + CONVERT(VARCHAR(20),[ApportionedFileSize]) + 'KB , FILEGROWTH = 64MB ) TO FILEGROUP ['+FilegroupName+'];'
	+ CHAR(13) + 'ALTER DATABASE [' + databasename + '] ADD FILE ( NAME = ''' + DataFileName +  '_6'', FILENAME = N''N:\MSSQL\Data\' + DataFileName + '_6.ndf'', SIZE = ' + CONVERT(VARCHAR(20),[ApportionedFileSize]) + 'KB , FILEGROWTH = 64MB ) TO FILEGROUP ['+FilegroupName+'];'
	+ CHAR(13) + 'ALTER DATABASE [' + databasename + '] ADD FILE ( NAME = ''' + DataFileName +  '_7'', FILENAME = N''R:\MSSQL\Data\' + DataFileName + '_7.ndf'', SIZE = ' + CONVERT(VARCHAR(20),[ApportionedFileSize]) + 'KB , FILEGROWTH = 64MB ) TO FILEGROUP ['+FilegroupName+'];'
	+ CHAR(13) + 'ALTER DATABASE [' + databasename + '] ADD FILE ( NAME = ''' + DataFileName +  '_8'', FILENAME = N''S:\MSSQL\Data\' + DataFileName + '_8.ndf'', SIZE = ' + CONVERT(VARCHAR(20),[ApportionedFileSize]) + 'KB , FILEGROWTH = 64MB ) TO FILEGROUP ['+FilegroupName+'];'
from databasefilegroups
