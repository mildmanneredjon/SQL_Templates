USE MASTER 

GO 
IF OBJECT_ID('tempdb.dbo.#TMPFIXEDDRIVES', 'U') IS NOT NULL
  DROP TABLE #TMPFIXEDDRIVES; 
CREATE TABLE #TMPFIXEDDRIVES ( 
  DRIVE  CHAR(1), 
  MBFREE INT) 

INSERT INTO #TMPFIXEDDRIVES 
EXEC xp_FIXEDDRIVES 

IF OBJECT_ID('tempdb.dbo.#TMPSPACEUSED', 'U') IS NOT NULL
  DROP TABLE #TMPSPACEUSED; 
CREATE TABLE #TMPSPACEUSED ( 
  DBNAME    VARCHAR(100), 
  FILENME   VARCHAR(100), 
  SPACEUSED FLOAT) 

DECLARE @sql VARCHAR(MAX)
DECLARE @dbname VARCHAR(200)

DECLARE c CURSOR FAST_FORWARD FOR
SELECT name FROM sys.databases WHERE state = 0

OPEN C
FETCH next FROM c INTO @dbname
WHILE @@FETCH_STATUS = 0
begin

SET @sql = 'use [' + @dbname + '];SELECT db_name() dbname, name filename, fileproperty(name,''spaceused'') spaceused from sysfiles'

INSERT INTO #TMPSPACEUSED 
EXEC(@sql) 

FETCH next FROM c INTO @dbname
END
CLOSE C
DEALLOCATE c

SELECT  
		 c.mbfree,		 
		 A.NAME AS DATABASENAME, 
         B.NAME AS FILENAME, 
         B.TYPE ,
		 CAST((B.SIZE * 8 / 1024.0) AS DECIMAL(18,2)) AS SIZEINMB,
         CAST((B.SIZE * 8 / 1024.0) - (D.SPACEUSED / 128.0) AS DECIMAL(15,2)) [SPACE FREE (MB)], 
         B.PHYSICAL_NAME
FROM     SYS.DATABASES A 
         JOIN SYS.MASTER_FILES B 
           ON A.DATABASE_ID = B.DATABASE_ID 
         JOIN #TMPFIXEDDRIVES C 
           ON LEFT(B.PHYSICAL_NAME,1) = C.DRIVE 
         JOIN #TMPSPACEUSED D 
           ON A.NAME = D.DBNAME 
              AND B.NAME = D.FILENME 
			  WHERE b.physical_name like 'd%'	

ORDER BY 5 desc
          
DROP TABLE #TMPFIXEDDRIVES

DROP TABLE #TMPSPACEUSED

--xp_fixeddrives