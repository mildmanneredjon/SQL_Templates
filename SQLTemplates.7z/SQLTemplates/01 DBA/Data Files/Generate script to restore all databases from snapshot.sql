select 'restore database ['+s.name+'] from database_snapshot = '''+ss.name+''';'
from sys.databases ss
inner join sys.databases s
on ss.source_database_id = s.database_id
where ss.source_database_id is not null