select name
	, index_name
	, type_desc
	, allocated_page_file_id
	, GAM_Group
	, total_pages
from
(
	select object_name(si.object_id) name
		, si.name index_name
		, si.type_desc 
		, allocated_page_file_id
		, FLOOR(allocated_page_page_id / 511232.0) GAM_Group
		, SUM(1) total_pages
	from sys.indexes SI
		CROSS APPLY SYS.DM_DB_DATABASE_PAGE_ALLOCATIONS(DB_ID(), si.object_id, si.index_id, si.data_space_id, 'LIMITED')
	where si.object_id > 100
		and is_iam_page = 0
	group by object_name(si.object_id)
		, si.name
		, si.type_desc 
		, allocated_page_file_id
		, FLOOR(allocated_page_page_id / 511232.0)
) as a
ORDER BY GAM_Group