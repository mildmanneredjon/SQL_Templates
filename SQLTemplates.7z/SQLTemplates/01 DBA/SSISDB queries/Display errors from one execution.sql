use ssisdb
SELECT
     
      [message_time]
      ,[message]
      ,[package_name]
      ,[event_name]
      ,[message_source_name]
      ,[subcomponent_name]
      ,[package_path]
      ,[execution_path]
      ,[message_code]
  FROM [SSISDB].[catalog].[event_messages] em
  where operation_id = 20166
  --and event_name in ('onerror','ontastfailed','onwarning')
  order by event_message_id
