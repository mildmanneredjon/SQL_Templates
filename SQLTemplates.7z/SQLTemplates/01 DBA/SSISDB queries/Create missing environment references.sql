/*
Use to create environment_references. Errors can be ignored that relate to existing references.

This will generate the tsql required to run create_environment_reference

Only works for relative referenced environments, i.e. environments in the same folder as the project

*/
select 'DECLARE @reference_id bigint'
		+char(13)+char(10)+
		'EXEC ssisdb.catalog.create_environment_reference @environment_name=N'''+e.name+''',@reference_id=@reference_id OUTPUT,@project_name=N'''+p.name+''', @folder_name=N'''+f.name+''', @reference_type=R'
		+char(13)+char(10)+
		'Select @reference_id'
		+char(13)+char(10)+
		'GO'
from SSISDB.catalog.environments e
inner join SSISDB.catalog.folders f
on e.folder_id = f.folder_id
inner join SSISDB.catalog.projects p
on p.folder_id = f.folder_id 

