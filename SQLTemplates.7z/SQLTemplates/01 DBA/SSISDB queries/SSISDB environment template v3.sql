/* Script to Maintain a single environment */

/* Declare Variables */

DECLARE	@EnvironmentVars TABLE
(
		[Id]					INT IDENTITY (1,1)	NOT NULL PRIMARY KEY
,		[VariableName]			NVARCHAR(128)		NOT NULL
,		[DataType]				NVARCHAR(128)		NOT NULL 
,		[Value]					SQL_VARIANT			NOT NULL
,		[Sensitive]				BIT					NOT NULL
,		[ConnectionManagerName]	NVARCHAR(128)		NOT NULL
,		[object_type]			TINYINT				NOT NULL
)
;

DECLARE
		@Environment	NVARCHAR(128)
,		@Application	NVARCHAR(128)
,		@SSISProject	NVARCHAR(128)
,		@ConName		NVARCHAR(128)
,		@VarName		NVARCHAR(128)
,		@DataType		NVARCHAR(128)
,		@Value			SQL_VARIANT
,		@Sensitive		BIT
,		@SQLStmnt		NVARCHAR(MAX)
,		@Package		NVARCHAR(128)
,		@object_type	TINYINT

/* Maintain this section to define variables */

/* Environment name */
SELECT
		@Environment = 'UAT'
,		@Application = 'AnalyticsMI'
,		@SSISProject = 'EvaluationQuestionExtract_SSIS'
,		@Package = 'EvaluationExtractPackage.dtsx'
;

/* Environment variables */
INSERT INTO @EnvironmentVars (VariableName, DataType, Value, Sensitive, ConnectionManagerName, object_type)                                                                
VALUES
		('VCBedrock_Live_DWConnectionString','String','Data Source=JONEDEN-7490;Initial Catalog=VCBedrock_Live_DW;Provider=SQLNCLI11.1;Integrated Security=SSPI;Auto Translate=False;','False','CM.VM-INT-STG-SQL.VCBedrock_STG.ConnectionString',20)
,		('CSVFlatFile','String','\\fileserver\Home\jon.eden\LMS2\Analytics MI\EvaluationQuestionExtract.csv','False','CM.Flat File Connection Manager.ConnectionString',20)
,		('SMTPServer','String','SmtpServer=VC-Exchange;UseWindowsAuthentication=False;EnableSsl=False;','False','CM.SMTP Connection Manager.ConnectionString',20)
,		('EmailToAddress','String','jon.eden@virtual-college.co.uk','False','ToAddress',20)

/* End of Manual Config */

IF EXISTS (SELECT 1 FROM SSISDB.catalog.folders WHERE name = @Application)
	BEGIN 
		PRINT 'Found SSIS Catalog and Application folder';

		/* Check the environment exists */
		IF EXISTS (SELECT 1 FROM SSISDB.catalog.environments e 
				   INNER JOIN SSISDB.catalog.folders f ON e.folder_id = f.folder_id
				   WHERE f.name = @Application AND e.name = @Environment)
		BEGIN
			PRINT 'Dropping SSIS Catalog Environment "' + @Environment + '" for application "' + @Application+'"'

			/* REMOVE THE ENVIRONMENT HERE */
			EXEC SSISDB.[catalog].[delete_environment]
						@folder_name		= @Application
			,			@environment_name	= @Environment
		END
	
		PRINT 'Creating SSIS Catalog Environment "' + @Environment + '" for application "' + @Application+'"'


		EXEC SSISDB.[catalog].[create_environment]
					@folder_name		= @Application
		,			@environment_name	= @Environment
	
	END 

/* Iterate through variables */

DECLARE vars CURSOR LOCAL
FOR
SELECT
		VariableName
,		DataType
,		Value
,		Sensitive
FROM	@EnvironmentVars

OPEN vars

FETCH NEXT FROM	vars INTO @VarName, @DataType, @Value, @Sensitive

WHILE @@FETCH_STATUS = 0
BEGIN
	SELECT
			@SQLStmnt = 'DECLARE @TypedValue ' + 
			CASE @DataType 
				WHEN 'Boolean'	THEN 'BIT'
				WHEN 'Byte'		THEN 'VARBINARY'
				WHEN 'DateTime' THEN 'DATETIME2'
				WHEN 'Double'	THEN 'DECIMAL'
				WHEN 'Int16'	THEN 'SMALLINT'
				WHEN 'Int32'	THEN 'INT'
				WHEN 'Int64'	THEN 'BIGINT'
				WHEN 'Single'	THEN 'DECIMAL'
				WHEN 'String'	THEN 'NVARCHAR(4000)'
				WHEN 'UInt32'	THEN 'INT'
				WHEN 'UInt64'	THEN 'BIGINT'
			END +
			' = '+
			CASE @DataType 
				WHEN 'Boolean'	THEN '''' + CONVERT(VARCHAR(6),@Value) + ''''
				WHEN 'Byte'		THEN 'VARBINARY'
				WHEN 'DateTime' THEN '''' + CONVERT(VARCHAR(50),@Value) + ''''
				WHEN 'Double'	THEN CONVERT(VARCHAR(50),@Value)
				WHEN 'Int16'	THEN CONVERT(VARCHAR(50),@Value)
				WHEN 'Int32'	THEN CONVERT(VARCHAR(50),@Value)
				WHEN 'Int64'	THEN CONVERT(VARCHAR(50),@Value)
				WHEN 'Single'	THEN CONVERT(VARCHAR(50),@Value)
				WHEN 'String'	THEN '''' + CONVERT(NVARCHAR(4000),@Value) + ''''
				WHEN 'UInt32'	THEN CONVERT(VARCHAR(50),@Value)
				WHEN 'UInt64'	THEN CONVERT(VARCHAR(50),@Value)
			END 
			+ 
			' EXEC SSISDB.[catalog].[create_environment_variable] ' +
			'			 @environment_name = N'''+ @Environment +'''' +
			',@folder_name  = N'''+ @Application +'''' +
			',@variable_name = N''' + @VarName + '''' +
			',@Sensitive = ' + CAST(@Sensitive AS VARCHAR(6)) + 
			',@data_type = N''' + @DataType + '''' +
			',@description = ''''' + -- N''' + @BuildMessage + '''' +
			',@value = @TypedValue'
			
	EXEC sp_executesql @Stmnt =  @SQLStmnt

	FETCH NEXT FROM vars INTO @VarName, @DataType, @Value, @Sensitive

END 

CLOSE vars
DEALLOCATE vars

/* Create project Reference */
IF NOT EXISTS (
				SELECT
						p.* 
				FROM	[SSISDB].[catalog].[projects] p
				JOIN	[SSISDB].[catalog].[environment_references] r
				ON		p.project_ID = r.project_ID
				JOIN	[SSISDB].[catalog].[folders] f
				ON		p.folder_ID = f.folder_ID
				WHERE	p.name = @SSISProject
				AND		r.[environment_name] = @Environment
				AND		f.name = @Application
			  )
		  
BEGIN

	DECLARE @reference_id BIGINT
	
	EXEC [SSISDB].[catalog].[create_environment_reference]
					@environment_name	= @Environment
	,				@reference_id		= @reference_id OUTPUT
	,				@project_name		= @SSISProject
	,				@folder_name		= @Application
	,				@reference_type		= R
END

/* Map connection Managers */

DECLARE vars CURSOR LOCAL
FOR
SELECT
		VariableName
,		ConnectionManagerName
,		object_type
FROM	@EnvironmentVars

OPEN vars

FETCH NEXT FROM vars INTO @VarName, @conName, @object_type

WHILE @@FETCH_STATUS = 0
BEGIN

	IF @object_type = 30
	BEGIN
		SELECT
				@SQLStmnt = 'EXEC [SSISDB].[catalog].[set_object_parameter_value] ' + 
							'@object_type=30, ' + 
							'@parameter_name=N''' + @conName + ''', ' + 
							'@object_name=N''' + @Package + ''', ' + 
							'@folder_name=N''' + @Application + ''', ' + 
							'@project_name=N''' + @SSISProject + ''', ' + 
							'@value_type=R, ' + 
							'@parameter_value=N''' + @VarName + ''''

		EXEC sp_executesql @Stmnt =  @SQLStmnt
	END 

	IF @object_type = 20
	BEGIN
		SELECT
				@SQLStmnt = 'EXEC [SSISDB].[catalog].[set_object_parameter_value] ' + 
							'@object_type=20, ' + 
							'@parameter_name=N''' + @conName + ''', ' + 
							'@object_name=N''' + @SSISProject + ''', ' + 
							'@folder_name=N''' + @Application + ''', ' + 
							'@project_name=N''' + @SSISProject + ''', ' + 
							'@value_type=R, ' + 
							'@parameter_value=N''' + @VarName + ''''

		EXEC sp_executesql @Stmnt =  @SQLStmnt
	END 

	FETCH NEXT FROM vars INTO @VarName, @conName, @object_type

END

CLOSE vars
DEALLOCATE vars
