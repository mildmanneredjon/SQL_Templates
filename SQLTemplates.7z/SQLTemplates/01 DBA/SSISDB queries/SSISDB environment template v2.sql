/* Script to Maintain a single environment */

/* Declare Variables */

DECLARE	@EnvironmentVars TABLE
(
		[Id]					INT IDENTITY (1,1)	NOT NULL PRIMARY KEY
,		[VariableName]			NVARCHAR(128)		NOT NULL
,		[DataType]				NVARCHAR(128)		NOT NULL 
,		[Value]					SQL_VARIANT			NOT NULL
,		[Sensitive]				BIT					NOT NULL
,		[ConnectionManagerName]	NVARCHAR(128)		NOT NULL
)
;

DECLARE
		@Environment	NVARCHAR(128)
,		@Application	NVARCHAR(128)
,		@SSISProject	NVARCHAR(128)
,		@ConName		NVARCHAR(128)
,		@VarName		NVARCHAR(128)
,		@DataType		NVARCHAR(128)
,		@Value			SQL_VARIANT
,		@Sensitive		BIT
,		@SQLStmnt		NVARCHAR(MAX)

/* Maintain this section to define variables */

/* Environment name */
SELECT
		@Environment = 'PSD_SYSTEM'
,		@Application = 'FCA_Mart'
,		@SSISProject = 'FCA_Reports_ETL'
;

/* Environment variables */
INSERT INTO @EnvironmentVars (VariableName, DataType, Value, Sensitive, ConnectionManagerName)                                                                
VALUES
		('FCA_Mart_Build_Connection','String','Data Source=FCAREPDS;Initial Catalog=FCA_Mart_Build;Provider=SQLNCLI11.1;Integrated Security=SSPI;Auto Translate=False;','False','Conn_FCA_Mart_Build')
,		('FCA_Mart_Build_Control_Connection','String','Data Source=FCAREPDS;Initial Catalog=FCA_Mart_Build_Control;Provider=SQLNCLI11.1;Integrated Security=SSPI;Auto Translate=False;','False','Conn_FCA_Mart_Build_Control')
,		('FCA_Mart_Connection','String','Data Source=FCAREPTEST;Initial Catalog=FCA_Mart;Provider=SQLNCLI11.1;Integrated Security=SSPI;Auto Translate=False;','False','Conn_FCA_Mart')
,		('Application_Processing_Connection','String','Data Source=FCAREPDS;Initial Catalog=ApplicationProcessing;Provider=SQLNCLI11.1;Integrated Security=SSPI;Auto Translate=False;','False','Conn_Application_Processing')
,		('Glo_Staging_Connection','String','Data Source=FCAREPDS;Initial Catalog=Glo_Staging;Provider=SQLNCLI11.1;Integrated Security=SSPI;Auto Translate=False;','False','Conn_Glo_Staging')
,		('MailHost_Connection','String','Data Source=FCAREPTEST;Initial Catalog=Master;Provider=SQLNCLI11.1;Integrated Security=SSPI;Auto Translate=False;','False','Conn_MailHost')
,		('Error_Alerts_ConnectionString','String','Data Source=FCASSISNonProd;Initial Catalog=SSISDB;Provider=SQLNCLI11.1;Integrated Security=SSPI;Auto Translate=False;','False','Conn_Error_Alerts')
,		('FCA_Satsuma_Build','String','Data Source=FCAREPDS;Initial Catalog=FCA_Satsuma_Build;Provider=SQLNCLI11.1;Integrated Security=SSPI;Auto Translate=False;','False','Conn_FCA_Satsuma_Build')
,		('FCA_Satsuma_Build_Control','String','Data Source=FCAREPDS;Initial Catalog=FCA_Satsuma_Build_Control;Provider=SQLNCLI11.1;Integrated Security=SSPI;Auto Translate=False;','False','Conn_FCA_Satsuma_Build_Control')
,		('SCHEDULE_NAME','String','PSD_LAND_DATA;PSD_GENERATE_DATA;PSD_GENERATE_XML_DATA;PSD_GENERATE_SUMMARY_REPORTS','False','SCHEDULE_NAME')

/* End of Manual Config */


IF EXISTS (SELECT 1 FROM SSISDB.catalog.folders WHERE name = @Application)
	BEGIN 
		PRINT 'Found SSIS Catalog and Application folder';

		/* Check the environment exists */
		IF EXISTS (SELECT 1 FROM SSISDB.catalog.environments e 
				   INNER JOIN SSISDB.catalog.folders f ON e.folder_id = f.folder_id
				   WHERE f.name = @Application AND e.name = @Environment)
		BEGIN
			PRINT 'Dropping SSIS Catalog Environment "' + @Environment + '" for application "' + @Application+'"'

			/* REMOVE THE ENVIRONMENT HERE */
			EXEC SSISDB.[catalog].[delete_environment]
						@folder_name		= @Application
			,			@environment_name	= @Environment
		END
	
		PRINT 'Creating SSIS Catalog Environment "' + @Environment + '" for application "' + @Application+'"'


		EXEC SSISDB.[catalog].[create_environment]
					@folder_name		= @Application
		,			@environment_name	= @Environment
	
	END 

/* Iterate through variables */

DECLARE vars CURSOR LOCAL
FOR
SELECT
		VariableName
,		DataType
,		Value
,		Sensitive
FROM	@EnvironmentVars

OPEN vars

FETCH NEXT FROM	vars INTO @VarName, @DataType, @Value, @Sensitive

WHILE @@FETCH_STATUS = 0
BEGIN
	SELECT
			@SQLStmnt = 'DECLARE @TypedValue ' + 
			CASE @DataType 
				WHEN 'Boolean'	THEN 'BIT'
				WHEN 'Byte'		THEN 'VARBINARY'
				WHEN 'DateTime' THEN 'DATETIME2'
				WHEN 'Double'	THEN 'DECIMAL'
				WHEN 'Int16'	THEN 'SMALLINT'
				WHEN 'Int32'	THEN 'INT'
				WHEN 'Int64'	THEN 'BIGINT'
				WHEN 'Single'	THEN 'DECIMAL'
				WHEN 'String'	THEN 'NVARCHAR(4000)'
				WHEN 'UInt32'	THEN 'INT'
				WHEN 'UInt64'	THEN 'BIGINT'
			END +
			' = '+
			CASE @DataType 
				WHEN 'Boolean'	THEN '''' + CONVERT(VARCHAR(6),@Value) + ''''
				WHEN 'Byte'		THEN 'VARBINARY'
				WHEN 'DateTime' THEN '''' + CONVERT(VARCHAR(50),@Value) + ''''
				WHEN 'Double'	THEN CONVERT(VARCHAR(50),@Value)
				WHEN 'Int16'	THEN CONVERT(VARCHAR(50),@Value)
				WHEN 'Int32'	THEN CONVERT(VARCHAR(50),@Value)
				WHEN 'Int64'	THEN CONVERT(VARCHAR(50),@Value)
				WHEN 'Single'	THEN CONVERT(VARCHAR(50),@Value)
				WHEN 'String'	THEN '''' + CONVERT(NVARCHAR(4000),@Value) + ''''
				WHEN 'UInt32'	THEN CONVERT(VARCHAR(50),@Value)
				WHEN 'UInt64'	THEN CONVERT(VARCHAR(50),@Value)
			END 
			+ 
			' EXEC SSISDB.[catalog].[create_environment_variable] ' +
			'			 @environment_name = N'''+ @Environment +'''' +
			',@folder_name  = N'''+ @Application +'''' +
			',@variable_name = N''' + @VarName + '''' +
			',@Sensitive = ' + CAST(@Sensitive AS VARCHAR(6)) + 
			',@data_type = N''' + @DataType + '''' +
			',@description = ''''' + -- N''' + @BuildMessage + '''' +
			',@value = @TypedValue'
			
	EXEC sp_executesql @Stmnt =  @SQLStmnt

	FETCH NEXT FROM vars INTO @VarName, @DataType, @Value, @Sensitive

END 

CLOSE vars
DEALLOCATE vars

/* Create project Reference */
IF NOT EXISTS (
				SELECT
						*
				FROM	[SSISDB].[catalog].[projects] p
				JOIN	[SSISDB].[catalog].[environment_references] r
				ON		p.project_ID = r.project_ID
				JOIN	[SSISDB].[catalog].[folders] f
				ON		p.folder_ID = f.folder_ID
				WHERE	p.name = @SSISProject
				AND		r.[environment_name] = @Environment
				AND		f.name = @Application
			  )
			  
BEGIN
	DECLARE @reference_id BIGINT
	
	EXEC [SSISDB].[catalog].[create_environment_reference]
					@environment_name	= @Environment
	,				@reference_id		= @reference_id OUTPUT
	,				@project_name		= @SSISProject
	,				@folder_name		= @Application
	,				@reference_type		= R
END

/* Map connection Managers */

DECLARE vars CURSOR LOCAL
FOR
SELECT
		VariableName
,		ConnectionManagerName
FROM	@EnvironmentVars

OPEN vars

FETCH NEXT FROM vars INTO @VarName, @conName

WHILE @@FETCH_STATUS = 0
BEGIN

	SELECT
			@SQLStmnt = 'EXEC [SSISDB].[catalog].[set_object_parameter_value] ' + 
						'@object_type=20, ' + 
						'@parameter_name=N''' + @conName + ''', ' + 
						'@object_name=N''' + @SSISProject + ''', ' + 
						'@folder_name=N''' + @Application + ''', ' + 
						'@project_name=N''' + @SSISProject + ''', ' + 
						'@value_type=R, ' + 
						'@parameter_value=N''' + @VarName + ''''

	EXEC sp_executesql @Stmnt =  @SQLStmnt

	FETCH NEXT FROM vars INTO @VarName, @conName

END

CLOSE vars
DEALLOCATE vars
