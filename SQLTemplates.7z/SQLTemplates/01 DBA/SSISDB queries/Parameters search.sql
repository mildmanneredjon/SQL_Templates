/*
This query allows you to search through all the parameters and connection manager values against all SSISDB projects

It details whether the parameter is set at the project or package level and whether it is being set via an environment/edited 
in the project or using the default value in the package.

Author: Paul Higgins
Date Created: 9th August 2018
*/

use ssisdb;

declare @search_string varchar(256) = 'rssshadow\lands'; --leave blank to return all entries
declare @folder_name varchar(256) = '';--leave blank to search all folders
declare @project_name varchar(256) = '';--leave blank to search all projects
declare @package_name varchar(256) = '';--leave blank to search all packages
with cte_parameter_info
as
(
select 
	f.name as folder_name,
	pr.name as project_name,
	'PROJECT LEVEL PARAMETER' as package_name,
	op.parameter_name as project_parameter_name,
	'Environment' as parameter_value_in_use,
	ev.value as parameter_value,
	e.name as environment_name,
	ev.name as environment_variable_name
from
	catalog.projects pr
inner join
	catalog.folders f on pr.folder_id = f.folder_id
inner join
	catalog.object_parameters op on pr.project_id = op.project_id and op.object_name = pr.name 
inner join
	catalog.environments e on f.folder_id = e.folder_id
inner join
	catalog.environment_variables ev on e.environment_id = ev.environment_id and op.referenced_variable_name = ev.name
where op.value_type = 'R'
and op.object_type = 20
union
select 
	f.name as folder_name,
	pr.name as project_name,
	pa.name as package_name,
	op.parameter_name as project_parameter_name,
	'Environment' as parameter_value_in_use,
	ev.value as parameter_value,
	e.name,
	ev.name
from
	catalog.packages pa
inner join
	catalog.projects pr on pa.project_id = pr.project_id
inner join
	catalog.folders f on pr.folder_id = f.folder_id
inner join
	catalog.object_parameters op on pr.project_id = op.project_id and op.object_name = pa.name 
inner join
	catalog.environments e on f.folder_id = e.folder_id
inner join
	catalog.environment_variables ev on e.environment_id = ev.environment_id and op.referenced_variable_name = ev.name
where op.value_type = 'R'
and op.object_type = 30
union
select
	f.name,
	pr.name,
	'PROJECT LEVEL PARAMETER',
	op.parameter_name,
	case
		when op.default_value is not null then 'Edited in project'
		else 'default value in package'
	end  as parameter_value_in_use,
	coalesce(op.default_value,op.design_default_value),
	null,
	null
from 
	catalog.projects pr
inner join
	catalog.folders f on pr.folder_id = f.folder_id
inner join
	catalog.object_parameters op on pr.project_id = op.project_id and op.object_name = pr.name
																						
where
	op.value_type <> 'R'
and
	op.object_type = 20
union
select
	f.name,
	pr.name,
	pa.name,
	op.parameter_name,
	case
		when op.default_value is not null then 'Edited in project'
		else 'default value in package'
	end  as parameter_value_in_use,
	coalesce(op.default_value,op.design_default_value),
	null,
	null
from 
	catalog.packages pa
right join
	catalog.projects pr on pa.project_id = pr.project_id
inner join
	catalog.folders f on pr.folder_id = f.folder_id
inner join
	catalog.object_parameters op on pr.project_id = op.project_id and op.object_name = pa.name
																						
where
	op.value_type <> 'R'
and
	op.object_type = 30
)

select 
	* 
from 
	cte_parameter_info
where 
	(cast(parameter_value as varchar(256)) like '%'+@search_string+'%'
	or @search_string = '')
and
	(folder_name = @folder_name
	or @folder_name = '')
and
	(project_name = @project_name
	or @project_name = '')
and
	(package_name = @package_name
	or @package_name = '')
