DECLARE @PROJECT VARCHAR(50) = 'Conversion_UTF8_to_UTF16'
SELECT 
	P.name AS Project_Name
	,P.project_format_version
	,OV.[object_version_lsn]
	,OV.[object_id]
	,OV.[object_type]
	,OV.[description]
	,OV.[created_by]
	,OV.[created_time]
	,OV.[restored_by]
	,OV.[last_restored_time]
	,OV.[object_data]
	,OV.[object_status]
FROM [SSISDB].[internal].[object_versions] OV
JOIN [SSISDB].[internal].[projects] P 
	ON OV.object_id = P.project_id
WHERE P.name = @PROJECT
