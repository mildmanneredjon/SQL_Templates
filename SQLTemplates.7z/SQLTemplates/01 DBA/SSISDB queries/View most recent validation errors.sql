/*
Returns all errors,warnings and failures for the most recent validation ran for every package

Use after running "Generate script to run validation against individual SSIS packages"

In progress - still needs to include context info. and details of the executable that failed
*/
declare @folder nvarchar(256) = 'hc_dwh - post'; --leave blank to check all folders
declare @project nvarchar(256) = ''; --leave blank to check all projects

while exists (select 1 from ssisdb.catalog.operations o
				where operation_type in (300,301) --validate_project,validate_package
				and status in (1,2,5,8)  --created,running,pending,stopping
				)
begin
waitfor delay '00:00:02'
end;


with cte_mostrecentvalidation
as
(
select max(validation_id) as validation_id
from ssisdb.catalog.validations
group by folder_name,project_name,object_name
)
select mrv.validation_id,om.message_time,v.folder_name,v.project_name, v.object_name as package_name,
		case om.message_type
			when 120 then 'error'
			when 110 then 'warning'
			when 130 then 'taskfailed'
		end as message_type,
		om.message
from ssisdb.catalog.operation_messages om
inner join ssisdb.catalog.validations v
on om.operation_id = v.validation_id
inner join cte_mostrecentvalidation mrv
on om.operation_id = mrv.validation_id
where om.message_type in (120,130)
and v.object_type = 30
and (v.folder_name = @folder or @folder = '')
and (v.project_name = @project or @project = '')
order by v.folder_name,v.project_name,package_name,om.message_time;