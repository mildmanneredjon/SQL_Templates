/*
Use to compare the execution time of all executables (tasks/components) of an execution of a ssis package against the average

select * from catalog.executables e
inner join catalog.executable_statistics es
on es.execution_id = e.execution_id and es.executable_id = e.executable_id
--where package_name = 'Interface_Transform_SnapFactApplicationReportingDay.dtsx'
where executable_name = 'EXEC - Interface_usp_Transform_SnapFactApplicationReportingDay'
order by e.execution_id desc

*/
declare @execution_id int = 46484;

use SSISDB;

with cte1
as
(
select 
		e.executable_id,
		e.executable_name,
		e.package_name,
		e.package_path,
		cast(DATEDIFF(second,es.start_time,es.end_time) as numeric (10,2))/60 as duration_in_mins,
		es.start_time,
		es.end_time
	from 
		catalog.executable_statistics es
	inner join catalog.executables e
	on es.execution_id = e.execution_id and es.executable_id = e.executable_id
	where e.execution_id = @execution_id
)
/*select * from cte1 where executable_name = 'Populate factAgreementHistory'
order by start_time desc*/
,cte2
as
(
select 
	e.executable_name, 
	e.package_name, 
	e.package_path,
	avg(cast(DATEDIFF(second,es.start_time,es.end_time) as numeric (10,2))/60) as [avg duration (mins)],
	min(cast(DATEDIFF(second,es.start_time,es.end_time) as numeric (10,2))/60) as [min duration (mins)],
	max(cast(DATEDIFF(second,es.start_time,es.end_time) as numeric (10,2))/60) as [max duration (mins)],
	count(1) as [total executions sampled]
from catalog.executable_statistics es
inner join catalog.executables e
on es.execution_id = e.execution_id and es.executable_id = e.executable_id
--where e.package_name = (select top 1 package_name from cte1/*@ssis_execution_details*/ order by start_time)
group by e.executable_name,e.package_name,e.package_path
)

select 
	cte1.executable_id,
	cte1.start_time,
	cte1.end_time,
	cte1.executable_name,
	cte1.package_name,
	cte1.package_path,
	cte1.duration_in_mins,
	cte2.[avg duration (mins)],
	cte2.[min duration (mins)],
	cte2.[max duration (mins)],
	cte2.[total executions sampled]
from
	cte1
left join
 	cte2
on
	cte1.executable_name = cte2.executable_name 
and 
	cte1.package_name = cte2.package_name 
and 
	cte1.package_path = cte2.package_path
--order by 
--	cte1.duration_in_mins desc
order by (cte1.duration_in_mins - cte2.[avg duration (mins)]) desc
