/*
In order to run this you need to set the following:

1. Set @folder to the SSISDB folder where you want to create the environment - this should always be the same location as the project itself
2. Set @environment to be the name of the environment
3. Set @project to the name of the project
4. Set the values in @VariableNamesAndValues to be 
			- environment variable name
			- environment variable value
			- parameter name (currently only works with project parameters and not package ones),
			  if you are defining connection manager properties prepend this with CM. and append
			  with the property name (e.g. ConnectionString/InitialCatalog/ServerName)
			- parameter type being one of the values from "select distinct ssis_data_type from ssisdb.internal.data_type_mapping"
*/

DECLARE 
	@folder nvarchar(256) = 'HC_DWH',
	@environment nvarchar(256) = 'Live',
	@project nvarchar(256) = 'ODS'

DECLARE
	@VariableNamesAndValues table (name nvarchar(256),[value] nvarchar(512),parameter_name nvarchar(256),parameter_type nvarchar(256)) 
	--parameter_types - select distinct ssis_data_type from internal.data_type_mapping
insert into @VariableNamesAndValues
values
	('ADO_ODSConnection','Data Source=HCDWHLIVE.pfg.com;Initial Catalog=DW_SALES_ODS;Integrated Security=True;','CM.ADO_ODSConnection.ConnectionString','string'),
	('ADO_ODSConnectionInitialCatalog','DW_SALES_ODS','CM.ADO_ODSConnection.InitialCatalog','string'),
	('ADO_ODSConnectionServerName','HCDWHLIVE.pfg.com','CM.ADO_ODSConnection.ServerName','string'),
	('DW_NFS_PES_PAYMENT_SCHEDULE_ADJUSTMENT_TABLE_ODS_SP','EDW_DBO.DWP_DW_NFS_PES_PAYMENT_SCHEDULE_ADJUSTMENT_TABLE_ODS','StoredProc','string')

DECLARE 
    @folder_id bigint,
    @environment_id bigint,
	@environmentvariablename nvarchar(256),
	@environmentvariablevalue nvarchar(512),
	@parametername nvarchar(256),
	@parametertype nvarchar(256)
	--@referenceid bigint
 
IF NOT EXISTS (SELECT 1 FROM [SSISDB].[catalog].[folders] WHERE name = @folder)
    EXEC [SSISDB].[catalog].[create_folder] @folder_name=@folder, @folder_id=@folder_id OUTPUT
ELSE
    SET @folder_id = (SELECT folder_id FROM [SSISDB].[catalog].[folders] WHERE name = @folder)
 
IF NOT EXISTS (SELECT 1 FROM [SSISDB].[catalog].[environments] WHERE folder_id = @folder_id AND name = @environment)
    EXEC [SSISDB].[catalog].[create_environment] @environment_name=@environment, @folder_name= @folder
 
SET @environment_id = (SELECT environment_id FROM [SSISDB].[catalog].[environments] WHERE folder_id = @folder_id and name = @environment)

if exists (SELECT environment_id FROM [SSISDB].[catalog].[environments] WHERE folder_id = @folder_id and name = @environment)
and not exists (
select 1 from ssisdb.catalog.environment_references
where reference_type ='R'
and environment_name = @environment)
begin
Declare @reference_id bigint
EXEC [SSISDB].[catalog].[create_environment_reference] @environment_name=@environment, @reference_id=@reference_id OUTPUT, @project_name=@project, @folder_name=@folder, @reference_type=R
Select @reference_id
end

declare c cursor
for
select name,value,parameter_name,parameter_type
from @VariableNamesAndValues

open c
fetch next from c into @environmentvariablename,@environmentvariablevalue,@parametername,@parametertype
	while @@FETCH_STATUS = 0
	begin
		
		IF NOT EXISTS (SELECT 1 FROM [SSISDB].[catalog].[environment_variables] WHERE environment_id = @environment_id AND name = @environmentvariablename)
			begin
				EXEC [SSISDB].[catalog].[create_environment_variable] @variable_name=@environmentvariablename, @sensitive=0, @description=N'', @environment_name=@environment, @folder_name=@folder, @value=@environmentvariablevalue, @data_type=@parametertype
			end
		
		EXEC [SSISDB].[catalog].[set_object_parameter_value] @object_type=20, @parameter_name=@parametername, @object_name=@project, @folder_name=@folder, @project_name=@project, @value_type=R, @parameter_value=@environmentvariablename

		fetch next from c into @environmentvariablename,@environmentvariablevalue,@parametername,@parametertype
	end
close c
deallocate c
