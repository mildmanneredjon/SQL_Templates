/*
*******STILL IN PROGRESS*******

This query returns the execution times of all control flow tasks.

If the logging level of the package execution is set to performance or verbose 
it will also return details of data flow component times.
*/

DECLARE @execution_id INT = 3111

SELECT *
FROM [SSISDB].[catalog].[executable_statistics]
WHERE stuff(execution_path NOT IN
    (SELECT case when execution_path like '%[1-1000]%'
				then susdfg..
				else SUBSTRING(execution_path,1,LEN(execution_path)-CHARINDEX('\',REVERSE(execution_path)))
     FROM [SSISDB].[catalog].[executable_statistics]
     WHERE execution_id = @execution_id)
  AND execution_id = @execution_id
ORDER BY execution_duration DESC

select execution_path,PATINDEX('%[[1-999]]%',execution_path)
from ssisdb.catalog.executable_statistics
select execution_path
from ssisdb.catalog.executable_statistics
where execution_id = 3111
and execution_path,'l',1) like '%![[1-999]!]%' escape '!'

select REPLACE(execution_path,'%[[1-999]]%','')
from ssisdb.catalog.executable_statistics

select execution_path,PATINDEX('%[[1-999]]%',execution_path),CHARINDEX(']',execution_path,PATINDEX('%[[1-999]]%',execution_path))
from ssisdb.catalog.executable_statistics



DECLARE @execution_id INT = 3111
declare @counter int
declare @retval nvarchar(max) = ''

select @counter = MIN(statistics_id) from #execution_paths

if OBJECT_ID('tempdb..#Execution_Paths') is not null 
begin
	drop table #Execution_paths
end
create table #Execution_Paths 
(statistics_id bigint,
execution_path nvarchar(max))

insert into #Execution_Paths
	select statistics_id, execution_path
	from  SSISDB.catalog.executable_statistics
	where execution_id = @execution_id

while (@counter <= (select MAX(statistics_id) from #Execution_Paths))
begin
	while @retval is not null
	begin
		select @retval = stuff(execution_path,patindex('%[[1-999]]%',execution_path),1,'')
		from #Execution_Paths
		where statistics_id = @counter

		update #Execution_Paths
		set execution_path = @retval
		where statistics_id = @counter

	print @retval
	end

	set @counter = @counter + 1
end

select * from #Execution_Paths
order by 2
