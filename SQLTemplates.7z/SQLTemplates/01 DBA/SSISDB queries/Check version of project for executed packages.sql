  declare @projectname varchar(128) = 'AccelerateMonitoring'
  use SSISDB 

  select project_lsn,start_time,end_time from catalog.executions
  where project_name = @projectname
  order by start_time desc