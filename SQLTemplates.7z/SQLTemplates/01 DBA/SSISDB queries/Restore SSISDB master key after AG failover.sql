/*Restore from the master key backup*/

declare @MK_backup_password varchar(128) = 'tS#0jLa6g[L\' --See "SSISDBEncryption->Database Master Key Backup" folder in the password safe
declare @MK_backup_file varchar(256) = '\\HOSWAKBACKUP1\f$\DatabaseCertAndKeys\PFGLBIPROCAG01\PFGLBIPROCAG01_ssisdb.key' --See Notes in "SSISDBEncryption->Database Master Key Backup" folder in the password safe
declare @MK_Password_To_Encrypt_SSISDB varchar(128) = 'tS#0jLa6g[L\' --This should be set the same on each replica in the AG to keep things simple - See "SSISDB" folder in the password safe

exec('USE SSISDB
 RESTORE MASTER KEY FROM FILE = '''+@MK_backup_file+'''
 DECRYPTION BY PASSWORD = '''+@MK_backup_password+'''
 ENCRYPTION BY PASSWORD = '''+@MK_Password_To_Encrypt_SSISDB+'''
 FORCE')