Declare @operation_id int = 169750

select mc.package_path,mc.context_source_name,mc.property_name,mc.property_value, m.message_time,m.message,m.package_name
from catalog.event_message_context mc
inner join catalog.event_messages m
on mc.event_message_id = m.event_message_id
where mc.package_path like '\Project.Connections%'
and mc.property_name in ('name','initialcatalog','servername','connectionstring')
and m.operation_id = @operation_id
order by context_source_name,property_name
