/*
Use to replace part of an environment name.

This will generate the tsql required to run rename_environment

After doing this you will need to remove the old and create the new environment reference.
*/

declare @find varchar(200) = '_Preprod'
declare @replace varchar(200) = '_Live'

select 'exec ssisdb.catalog.rename_environment @folder_name =N'''+f.name+''', @environment_name =N'''+e.name+''', @new_environment_name =N'''+replace(e.name,''+@find+'',''+@replace+'')+''''
		+char(13)+char(10)+
		'GO'
from ssisdb.catalog.folders f
inner join ssisdb.catalog.environments e
on f.folder_id = e.folder_id
where e.name like '%'+@find+'%'