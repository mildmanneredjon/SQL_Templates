declare @packagename varchar(128) = 'ELP_LoadExtract.dtsx'

use ssisdb

select 
	pa.name as package_name,
	pa.description as package_description,
	pr.name as project_name,
	pr.description as project_description,
	f.name as folder_name,
	f.description as folder_description
from 
	catalog.packages pa
inner join 
	catalog.projects pr on pa.project_id = pr.project_id
inner join
	catalog.folders f on pr.folder_id = f.folder_id
where 
	pa.name = @packagename