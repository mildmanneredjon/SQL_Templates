/*
This will generate a script to run a validation against every project specified either for all projects, all within a folder or a specific project

Ensure the generated script is ran from the server where the packages are executed from as the account that executes them
*/

declare @folder nvarchar(256) = 'hc_dwh - post' --leave blank to check all folders
declare @project nvarchar(256) = '' --leave blank to check all projects
declare @32bitruntime varchar(5) = 'false' --set to true or false


select 'Declare @validation_id bigint'
	+char(13)+char(10)+
	'EXEC SSISDB.catalog.validate_package @package_name=N'''+pack.name+''', @validation_id=@validation_id OUTPUT, @folder_name=N'''+f.name+''', @project_name=N'''+proj.name+''', @use32bitruntime='+@32bitruntime+', @environment_scope=s,@reference_id='+cast(er.reference_id as varchar(5))+''
	+char(13)+char(10)+
	'Select @validation_id'
	+char(13)+char(10)+
	'GO'
from ssisdb.catalog.packages pack
inner join
ssisdb.catalog.projects proj
on pack.project_id = proj.project_id
inner join
ssisdb.catalog.folders f
on proj.folder_id = f.folder_id
inner join
ssisdb.catalog.environment_references er
on proj.project_id = er.project_id
where (f.name = @folder or @folder = '')
and (proj.name = @project or @project = '')

