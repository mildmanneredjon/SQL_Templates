/*
Use to replace part of a environment variable value.

This will generate the tsql required to run set_environment_variable_value

Only currently works with string variables
*/

declare @find varchar(200) = 'HOPINGU'
declare @replace varchar(200) = 'UKSWAKSENTINAL\WAKPENGUIN'

select 'DECLARE @var sql_variant = N'''+replace(cast(value as varchar(500)),''+@find+'',''+@replace+'')+''''
		+char(13)+char(10)+
		'EXEC ssisdb.catalog.set_environment_variable_value @variable_name=N'''+ev.name+''',@environment_name=N'''+e.name+''', @folder_name=N'''+f.name+''', @value=@var'
		+char(13)+char(10)+
		'GO'
from SSISDB.catalog.environment_variables ev
inner join ssisdb.catalog.environments e
on ev.environment_id = e.environment_id
inner join ssisdb.catalog.folders f
on e.folder_id = f.folder_id
where cast(ev.value as varchar(500)) like '%'+@find+'%'
and ev.type = 'string'