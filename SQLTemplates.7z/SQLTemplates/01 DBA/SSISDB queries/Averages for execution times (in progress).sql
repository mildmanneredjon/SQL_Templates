use ssisdb
select [if].name as folder_name, ipr.name as project_name, /*ip.name as package_name,*/ies.execution_id--, sum(ies.execution_duration)/1000
from 
internal.executable_statistics ies
inner join
internal.executables ie
on ies.executable_id = ie.executable_id
inner join internal.projects ipr
on ie.project_id = ipr.project_id
inner join internal.object_versions ov
on ov.[object_id] = ipr.[project_id]
	AND ov.[object_version_lsn] = ipr.[object_version_lsn]
--inner join internal.packages ip
--on ipr.project_id = ip.project_id
inner join internal.folders [if]
on ipr.folder_id = [if].folder_id
where [if].name = 'AccelerateHC'
--group by [if].name,ipr.name,/*ip.name,*/ies.execution_id
order by ies.execution_id




use ssisdb;

declare @ProjectName varchar(256) = 'AccelerateHC'

declare  @Execution_times table (folder_name varchar(256),project_name varchar(256), package_name varchar(256), execution_id int, start_time datetime, end_time datetime, total_time_in_mins decimal(6,2))

insert into @execution_times

select [if].name as folder_name,ip.name as project_name, ipa.name as package_name,ies.execution_id, min(start_time) as start_time,max(end_time) as end_time,sum(cast(execution_duration/60000 as decimal (6,2))) as total_time_in_mins
from 
internal.executable_statistics ies
inner join internal.executables ie
on ies.executable_id = ie.executable_id
inner join internal.projects ip
on ie.project_id = ip.project_id
inner join internal.packages ipa
on ip.project_id = ipa.project_id
inner join internal.folders [if]

on ip.folder_id = [if].folder_id
where [if].name = @ProjectName
group by [if].name,ip.name,ipa.name,ies.execution_id

select * from @Execution_times
order by execution_id

select folder_name,project_name,package_name,avg(total_time_in_mins) as average_project_execution
from @Execution_times
group by folder_name, project_name, package_name