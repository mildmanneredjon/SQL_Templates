DECLARE @SQL NVARCHAR(MAX)
	, @DateFrom DATETIME = '20131201'
	, @DateTo DATETIME = '20140224'
	, @RollupSuffix VARCHAR(200) = ''
	, @RollupLevelID smallint
	, @Param_Definition NVARCHAR(500)
	, @Execute_params NVARCHAR(500)
	, @CounterID INT
	, @Metric VARCHAR(200)

/**
PERCENT_PROCESSOR_TIME

DATA_FILE_TOTAL_SIZE_MB
DATA_FILE_SIZE_USED_MB
LOG_FILE_TOTAL_SIZE_MB
LOG_FILE_SIZE_USED_MB

AVAILABLE_MBYTES

TOTAL_NODE_MEMORY_KB

USER_CONNECTIONS
**/

SET @Metric = 'TRANSACTIONS_PER_SEC'

SELECT @CounterID = ID
FROM [PerformanceAnalysisCounter]
WHERE [CounterResourceName] = @Metric

--pass the to and from dates into the SQLSentry function to determine which (if any)
--the PerformanceAnalysisDataRollup tables we should be using
SELECT @RollupLevelID = dbo.fnRollupLevelForRangeSizeAndCounterInMinutes(DATEDIFF(minute, @DateFrom, @DateTo), (DATEDIFF(second, '20000101 00:00:00', @DateFrom) / 5), @CounterID)

IF (@RollupLevelID > 0)
	BEGIN
		SET @RollupSuffix = 'Rollup' + CAST(@RollupLevelID as varchar(2))
	END

-------------------------------------------------------------------------------
--query for SQL data file usage
	SET @SQL =
	'
	SELECT 
	ESC.ObjectName SQLInstance
		, dateadd(second, PAD.[Timestamp] * 5, ''20000101 00:00:00'') CollectionDateTime
		, PAC.[CounterResourceName]
		, PAD.[Value] [Metric]
		--, PAD.*
	FROM EventSourceConnection ESC
		INNER JOIN PerformanceAnalysisData PAD
			ON PAD.EventSourceConnectionID = ESC.ID
		INNER JOIN [PerformanceAnalysisCounter] PAC
			ON PAC.ID = PAD.PerformanceAnalysisCounterID			
	WHERE PAD.PerformanceAnalysisCounterID IN (@CounterID_IN)
		AND PAD.[Timestamp] >= (DATEDIFF(second, ''20000101 00:00:00'', @DateFrom_IN) / 5)
		AND PAD.[Timestamp] <= (DATEDIFF(second, ''20000101 00:00:00'', @DateTo_IN) / 5)
	'


--if no suffix was provided the replace will essentially do nothing
SET @SQL = REPLACE(@SQL, 'PerformanceAnalysisData', 'PerformanceAnalysisData' + @RollupSuffix)

SET @Param_Definition = '@DateFrom_IN DATETIME, @DateTo_IN DATETIME, @CounterID_IN INT, @Metric_IN VARCHAR(200)'

--execute the query to get the performance results out
EXEC SP_EXECUTESQL @SQL, @Param_Definition, @DateFrom_IN = @DateFrom, @DateTo_IN = @DateTo, @CounterID_IN = @CounterID, @Metric_IN = @Metric
