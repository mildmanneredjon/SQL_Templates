--groups
SELECT TOP 1000 [ID]
      ,[GroupName]
      ,[GroupDisplayName]
      ,[IsDeviceLevel]
      ,[UsesPercentDisplay]
      ,[SetYScaleMax]
      ,[YScaleMax]
  FROM [SQLSentry].[dbo].[ReportPerformanceAnalysisCounterGroups]

--counters
SELECT PACC.id, PACC.CategoryResourceName, PAC.ID, PAC.CounterResourceName
FROM [PerformanceAnalysisCounter] (nolock) PAC
	INNER JOIN PerformanceAnalysisCounterCategory (nolock) PACC
		ON PAC.PerformanceAnalysisCounterCategoryID = PACC.ID
WHERE PAC.PerformanceAnalysisSampleIntervalID > 0