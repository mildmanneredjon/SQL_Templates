--a list of all the available report counter groups

SELECT * 
  FROM [dbo].[ReportPerformanceAnalysisCounterGroups]

-------------------------------------------------------------------------------
DECLARE @DeviceID_IN SMALLINT
DECLARE @ConnectionID_IN SMALLINT

SELECT @DeviceID_IN = DeviceID
, @ConnectionID_IN = ID
FROM EventSourceConnection 
WHERE ObjectName = ''
	AND IsWatched = 1

SELECT @DeviceID_IN 
, @ConnectionID_IN

exec ReportProc_ServerPerformanceGroup 
	@DeviceID=@DeviceID_IN
	,@ConnectionID=@ConnectionID_IN
	,@StartTimeUtc='2014-02-26 09:55:22'
	,@EndTimeUtc='2014-02-26 10:00:22'
	,@ReportCounterGroup=N'SQLTopTransactions'