/*
This script does various checks against the specified database to check for potential issues

Press CTRL-SHIFT-M to set the database name
*/

/*Gives the SCOM account the required permissions*/
declare @databasevalidationresults table (result varchar(256), response varchar(256),action_or_query varchar(8000))
declare @result varchar(max)

/*Check SCOM account is setup*/
USE <database_name, sysname, your_database_name>
if not exists (select name from sys.database_principals 
				where name = 'NT SERVICE\HealthService')
BEGIN
insert into @databasevalidationresults
select 'SCOM account not setup' as result,'Run query' as response,
'CREATE USER [NT SERVICE\HealthService] FOR LOGIN [NT SERVICE\HealthService]
print ''SCOM account added to database for monitoring''' as Query_to_run
END

/*Check default filegroup is not the primary*/
if exists(select 1 from sys.filegroups
			where name = 'primary' and is_default = 1)
BEGIN
insert into @databasevalidationresults
select 'Primary set as default filegroup','Resolve or pass back to developer to resolve',''
END

/*Check all tables have clustered indexes created*/
if exists(select 1 from sys.indexes i
			inner join sys.objects o
			on i.object_id = o.object_id
			where i.index_id = 0
			and o.type = 'U')
BEGIN
insert into @databasevalidationresults
select 'Some tables do not have a clustered index','Run query to get list and get developer to correct','select schema_name(schema_id) as schema_name,o.name as table_name from sys.indexes i
			inner join sys.objects o
			on i.object_id = o.object_id
			where i.index_id = 0
			and o.type = ''U''
			order by 1,2'
END

/*Check non-clustered indexes are created on a separate filegroup*/
if exists(SELECT 1 FROM sys.indexes i
INNER JOIN sys.filegroups f
ON i.data_space_id = f.data_space_id
INNER JOIN sys.all_objects o
ON i.[object_id] = o.[object_id] WHERE i.data_space_id = f.data_space_id
AND o.type = 'U' AND index_id = 2 and f.name not like '%nc%' and f.name not like '%index%')
BEGIN
insert into @databasevalidationresults
select 'Non clustered indexes possibly created in the wrong filegroup','Run query to get filegroup and pass to developer to correct','
SELECT o.[name], o.[type], i.[name], i.[index_id], f.[name] FROM sys.indexes i
INNER JOIN sys.filegroups f
ON i.data_space_id = f.data_space_id
INNER JOIN sys.all_objects o
ON i.[object_id] = o.[object_id] WHERE i.data_space_id = f.data_space_id
AND o.type = ''U'' 
WHERE index_id = 2 and f.name not like ''%nc%'' and f.name not like ''%index%'''
END

/*Check database owner is set to sa*/
if exists (select suser_sname(owner_sid) from sys.databases where name = DB_NAME() and suser_sname(owner_sid) <> 'sa')
BEGIN
insert into @databasevalidationresults
select 'sa account not setup as database owner','run the query','EXEC dbo.sp_changedbowner @loginame = N''sa'', @map = false'
END

/*Check for autogrowth in percent*/
if exists (select * from sys.master_files where database_id = DB_ID() and is_percent_growth = 1)
BEGIN
insert into @databasevalidationresults
select 'autogrowth set to percent','run the query to get the details and then correct','select name from sys.master_files where database_id = DB_ID() and is_percent_growth = 1'
END

/*Check compatibility level matches the server*/
if exists (SELECT 1  
			FROM sys.databases 
			WHERE name = DB_NAME() 
			AND compatibility_level <> (select compatibility_level from sys.databases where name = 'master'))
BEGIN
insert into @databasevalidationresults
select 'old compatibility level set','adjust to the current compatibility level of the server',''
END

/*Check for any deprecated data types*/
if exists (select 1
			from INFORMATION_SCHEMA.COLUMNS c
			inner join INFORMATION_SCHEMA.TABLES t
			on c.TABLE_SCHEMA = t.TABLE_SCHEMA and c.TABLE_NAME = t.TABLE_NAME
			where t.TABLE_TYPE = 'base table' and c.DATA_TYPE in ('ntext','text','image'))
BEGIN
insert into @databasevalidationresults
select 'deprecated datatypes used','run the query to identify the data types', 'select table_schema,table_name,column_name,data_type from INFORMATION_SCHEMA.COLUMNS c on c.TABLE_SCHEMA = t.TABLE_SCHEMA and c.TABLE_NAME = t.TABLE_NAME
			where t.TABLE_TYPE = ''base table''  and DATA_TYPE in (''ntext'',''text'',''image'')'
END

/*Check for any unicode data types*/
if exists (select 1
			from INFORMATION_SCHEMA.COLUMNS c inner join INFORMATION_SCHEMA.TABLES t
			on c.TABLE_SCHEMA = t.TABLE_SCHEMA and c.TABLE_NAME = t.TABLE_NAME
			where t.TABLE_TYPE = 'base table' and  c.DATA_TYPE in ('nvarchar','nchar'))
BEGIN
insert into @databasevalidationresults
select 'unicode datatypes used','run the query to identify the data types', 'select c.table_schema,c.table_name,c.column_name,c.data_type from INFORMATION_SCHEMA.COLUMNS c inner join INFORMATION_SCHEMA.TABLES t on c.TABLE_SCHEMA = t.TABLE_SCHEMA and c.TABLE_NAME = t.TABLE_NAME
			where t.TABLE_TYPE = ''base table'' and c.DATA_TYPE in (''nvarchar'',''nchar'')'
END

/*Check for excessive data types used*/
if exists (select 1
			from INFORMATION_SCHEMA.COLUMNS c inner join INFORMATION_SCHEMA.TABLES t
			on c.TABLE_SCHEMA = t.TABLE_SCHEMA and c.TABLE_NAME = t.TABLE_NAME
			where t.TABLE_TYPE = 'base table' and c.DATA_TYPE = 'bigint' or (DATA_TYPE in ('decimal','numeric') and NUMERIC_PRECISION > 9) or (DATA_TYPE in ('char','varchar','nchar','nvarchar') and CHARACTER_MAXIMUM_LENGTH > 255)) 
BEGIN
insert into @databasevalidationresults
select 'potentially excessive data types used','run the query to identify the columns','select c.table_schema,c.table_name,c.column_name,c.data_type,c.numeric_precision,c.numeric_scale,c.character_maximum_length from INFORMATION_SCHEMA.COLUMNS c inner join INFORMATION_SCHEMA.TABLES t on c.TABLE_SCHEMA = t.TABLE_SCHEMA and c.TABLE_NAME = t.TABLE_NAME
			where t.TABLE_TYPE = ''base table'' and DATA_TYPE = ''bigint'' or (c.DATA_TYPE in (''decimal'',''numeric'') and c.NUMERIC_PRECISION > 9) or (c.DATA_TYPE in (''char'',''varchar'',''nchar'',''nvarchar'') and c.CHARACTER_MAXIMUM_LENGTH > 255) order by table_schema,table_name,column_name'
END

/*Check if auto shrink is enabled*/
if exists (select 1
			from sys.databases
			where is_auto_shrink_on = 1
			and database_id = DB_ID())
BEGIN
insert into @databasevalidationresults
select 'auto shrink is enabled','run the query to switch it off','USE [master]
ALTER DATABASE ['+DB_NAME()+'] SET AUTO_SHRINK OFF WITH NO_WAIT'
END

/*Check if auto close is enabled*/
if exists (select 1
			from sys.databases
			where is_auto_close_on = 1
			and database_id = DB_ID())
BEGIN
insert into @databasevalidationresults
select 'auto close is enabled','run the query to switch it off','USE [master]
ALTER DATABASE ['+DB_NAME()+'] SET AUTO_CLOSE OFF WITH NO_WAIT'
END

/*Check if auto close is enabled*/
if exists (select 1
			from sys.databases
			where is_auto_close_on = 1
			and database_id = DB_ID())
BEGIN
insert into @databasevalidationresults
select 'auto close is enabled','run the query to switch it off','USE [master]
ALTER DATABASE ['+DB_NAME()+'] SET AUTO_CLOSE OFF WITH NO_WAIT'
END

/*Check if checksum page verification is enabled*/
if not exists (select 1
			from sys.databases
			where page_verify_option = 2
			and database_id = DB_ID())
BEGIN
insert into @databasevalidationresults
select 'checksum page verification is not enabled','run the query to switch it on','USE [master]
ALTER DATABASE ['+DB_NAME()+'] SET PAGE_VERIFY CHECKSUM WITH NO_WAIT'
END

/*Check if trustworthy is enabled*/
if exists (select 1
			from sys.databases
			where is_trustworthy_on = 1
			and database_id = DB_ID())
BEGIN
insert into @databasevalidationresults
select 'trustworthy is enabled for this database, this is a security risk, is this definitely required?','switch off if not required',''
END

/*Check user account with db_owner access*/
if exists (select 1
			from sys.database_principals prin
LEFT OUTER JOIN sys.database_role_members mem ON prin.principal_id=mem.member_principal_id
WHERE prin.sid IS NOT NULL and prin.sid NOT IN (0x00) and
prin.is_fixed_role <> 1 AND prin.name NOT LIKE '##%'
and name like left('',10) + '%')
BEGIN
insert into @databasevalidationresults
select 'some users are members of database roles, please verify','run the query to review the results','SELECT 
case prin.name when ''dbo'' then prin.name + '' (''+ (select SUSER_SNAME(owner_sid) from master.sys.databases where name =db_name()) + '')'' else prin.name end AS UserName,
prin.type_desc AS LoginType,
isnull(USER_NAME(mem.role_principal_id),'''') AS AssociatedRole ,create_date,modify_date
FROM sys.database_principals prin
LEFT OUTER JOIN sys.database_role_members mem ON prin.principal_id=mem.member_principal_id
WHERE prin.sid IS NOT NULL and prin.sid NOT IN (0x00) and
prin.is_fixed_role <> 1 AND prin.name NOT LIKE ''##%''
and name like left('',10) + ''%''' 
END

select * from @databasevalidationresults