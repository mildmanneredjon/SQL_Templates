/**********************************
Extract Database default locations
**********************************/ 
DECLARE @TABLE1 TABLE ([Value] CHAR(11), [Data] VARCHAR(50))
DECLARE @DATA_PATH VARCHAR(50)
DECLARE @LOG_PATH VARCHAR(50)

INSERT INTO @TABLE1 
	EXEC xp_instance_regread N'HKEY_LOCAL_MACHINE', N'Software\Microsoft\MSSQLServer\MSSQLServer', N'DefaultData'
INSERT INTO @TABLE1
	EXEC xp_instance_regread N'HKEY_LOCAL_MACHINE', N'Software\Microsoft\MSSQLServer\MSSQLServer', N'DefaultLog'

SELECT @DATA_PATH = Data from @TABLE1 WHERE Value = 'DefaultData'
SELECT @LOG_PATH = Data from @TABLE1 WHERE Value = 'DefaultLog'

/**********************************
Set SQLCMD variables
**********************************/ 
:setvar DataFilePath @DATA_PATH
:setvar LogFilePath @LOG_PATH
:setvar server "hostage\ransom"
:setvar database "Auto_DB_Test"

select $(DataFilePath)
select $(LogFilePath)
SELECT filename = N'$(DataFilePath)'

:connect $(server)

CREATE DATABASE [$(database)]
 ON  PRIMARY 
( NAME = N'$(database)', FILENAME = N'$(DataFilePath)\$(database).mdf' , SIZE = 64MB , MAXSIZE = 1024MB , FILEGROWTH = 64MB ), 
 FILEGROUP [User_Data] 
( NAME = N'$(database)_User_Data_1', FILENAME = N'$(DataFilePath)\$(database)_User_Data_1.ndf' , SIZE = 64MB , MAXSIZE = 10240MB , FILEGROWTH = 256MB ), 
( NAME = N'$(database)_User_Data_2', FILENAME = N'$(DataFilePath)\$(database)_User_Data_2.ndf' , SIZE = 64MB , MAXSIZE = 10240MB , FILEGROWTH = 256MB ), 
( NAME = N'$(database)_User_Data_3', FILENAME = N'$(DataFilePath)\$(database)_User_Data_3.ndf' , SIZE = 64MB , MAXSIZE = 10240MB , FILEGROWTH = 256MB ), 
( NAME = N'$(database)_User_Data_4', FILENAME = N'$(DataFilePath)\$(database)_User_Data_4.ndf' , SIZE = 64MB , MAXSIZE = 10240MB , FILEGROWTH = 256MB ), 
 FILEGROUP [User_Indexes] 
( NAME = N'$(database)_User_Indexes_1', FILENAME = N'$(DataFilePath)\$(database)_User_Indexes_1.ndf' , SIZE = 64MB , MAXSIZE = 10240MB , FILEGROWTH = 256MB ), 
( NAME = N'$(database)_User_Indexes_2', FILENAME = N'$(DataFilePath)\$(database)_User_Indexes_2.ndf' , SIZE = 64MB , MAXSIZE = 10240MB , FILEGROWTH = 256MB ), 
( NAME = N'$(database)_User_Indexes_3', FILENAME = N'$(DataFilePath)\$(database)_User_Indexes_3.ndf' , SIZE = 64MB , MAXSIZE = 10240MB , FILEGROWTH = 256MB ), 
( NAME = N'$(database)_User_Indexes_4', FILENAME = N'$(DataFilePath)\$(database)_User_Indexes_4.ndf' , SIZE = 64MB , MAXSIZE = 10240MB , FILEGROWTH = 256MB )
 LOG ON 
( NAME = N'$(database)_log', FILENAME = N'$(LogFilePath)\$(database)_log.ldf' , SIZE = 2048MB , MAXSIZE = 10240MB , FILEGROWTH = 512MB )
GO
ALTER DATABASE $(database) SET COMPATIBILITY_LEVEL = 100
GO
ALTER DATABASE $(database) SET ANSI_NULL_DEFAULT OFF 
GO
ALTER DATABASE $(database) SET ANSI_NULLS OFF 
GO
ALTER DATABASE $(database) SET ANSI_PADDING OFF 
GO
ALTER DATABASE $(database) SET ANSI_WARNINGS OFF 
GO
ALTER DATABASE $(database) SET ARITHABORT OFF 
GO
ALTER DATABASE $(database) SET AUTO_CLOSE OFF 
GO
ALTER DATABASE $(database) SET AUTO_CREATE_STATISTICS ON 
GO
ALTER DATABASE $(database) SET AUTO_SHRINK OFF 
GO
ALTER DATABASE $(database) SET AUTO_UPDATE_STATISTICS ON 
GO
ALTER DATABASE $(database) SET CURSOR_CLOSE_ON_COMMIT OFF 
GO
ALTER DATABASE $(database) SET CURSOR_DEFAULT  GLOBAL 
GO
ALTER DATABASE $(database) SET CONCAT_NULL_YIELDS_NULL OFF 
GO
ALTER DATABASE $(database) SET NUMERIC_ROUNDABORT OFF 
GO
ALTER DATABASE $(database) SET QUOTED_IDENTIFIER OFF 
GO
ALTER DATABASE $(database) SET RECURSIVE_TRIGGERS OFF 
GO
ALTER DATABASE $(database) SET  DISABLE_BROKER 
GO
ALTER DATABASE $(database) SET AUTO_UPDATE_STATISTICS_ASYNC OFF 
GO
ALTER DATABASE $(database) SET DATE_CORRELATION_OPTIMIZATION OFF 
GO
ALTER DATABASE $(database) SET PARAMETERIZATION SIMPLE 
GO
ALTER DATABASE $(database) SET  READ_WRITE 
GO
ALTER DATABASE $(database) SET RECOVERY SIMPLE 
GO
ALTER DATABASE $(database) SET  MULTI_USER 
GO
ALTER DATABASE $(database) SET PAGE_VERIFY CHECKSUM  
GO
ALTER DATABASE $(database) SET TARGET_RECOVERY_TIME = 0 SECONDS 
GO
USE $(database)
GO
IF NOT EXISTS (SELECT name FROM sys.filegroups WHERE is_default=1 AND name = N'User_Data') ALTER DATABASE $(database) MODIFY FILEGROUP [User_Data] DEFAULT
GO
EXEC dbo.sp_changedbowner @loginame = N'sa', @map = false
GO
