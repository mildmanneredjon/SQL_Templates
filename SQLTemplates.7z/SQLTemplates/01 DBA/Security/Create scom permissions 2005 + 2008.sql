DECLARE @SQL VARCHAR(MAX)
DECLARE @LowPrivGroup VARCHAR(200)
DECLARE @ActionGroup VARCHAR(200) 

SET @sql = ''
SET @LowPrivGroup = 'PFG\SCOM_SQLLowPriv'
SET @ActionGroup = 'PFG\SCOM_SQLAction'

--CREATE ACCOUNTS
SET @SQL = @SQL + 'if not exists (select 1 from master.dbo.syslogins where name = ''' + @LowPrivGroup + ''')' + CHAR(13)
 + 'begin' + CHAR(13)
 + 'CREATE LOGIN ['+ @LowPrivGroup +'] FROM Windows' + CHAR(13)
 + 'end' + CHAR(13)

SET @SQL = @SQL + 'if not exists (select 1 from master.dbo.syslogins where name = ''' + @ActionGroup + ''')' + CHAR(13)
 + 'begin' + CHAR(13)
 + 'CREATE LOGIN ['+ @ActionGroup +'] FROM Windows' + CHAR(13)
 + 'end' + CHAR(13)

-------------------------------------------------------------------------------
--LOW PRIVILEGE ACCOUNT

--GRANT SERVER LEVEL PERMISSIONS
SET @SQL = @SQL + 'use master' + CHAR(13)
 + 'GRANT VIEW ANY DEFINITION TO [' + @LowPrivGroup  + '];'+ char(13)
 + 'GRANT VIEW SERVER STATE TO [' + @LowPrivGroup + '];' + char(13)
 + 'GRANT VIEW ANY DATABASE TO [' + @LowPrivGroup + '];' + char(13) 
 + 'GRANT select on sys.database_mirroring_witnesses to [' + @LowPrivGroup + '];' + char(13)
 + 'GRANT select on msdb.sys.database_mirroring_witnesses to [' + @LowPrivGroup + '];' + CHAR(13)
 
select @SQL = @SQL +
       + 'USE [' + name  + '];'  + CHAR(13) + 
	   + 'IF not exists (select 1 from sys.database_principals dp INNER JOIN sys.sysusers SU ON dp.principal_id = SU.uid where su.name = ''' + @LowPrivGroup + ''' and SU.hasdbaccess = 1)' + CHAR(13)
	   + 'begin' + CHAR(13)
	   + 'CREATE USER [' + @LowPrivGroup + '] FROM LOGIN [' + @LowPrivGroup + '];' + char(13)
	   + 'end' + CHAR(13)
FROM sys.databases
WHERE State_desc = 'ONLINE'
AND is_read_only = 0

--MSDB
SET @SQL = @SQL + 
'USE msdb;
exec sp_addrolemember ''SQLAgentReaderRole'', ''' + @LowPrivGroup + ''';' + CHAR(13)
+ 'IF not exists (select 1 from sys.databases where name = ''msdb'' and compatibility_level = ''90'')' + char(13)
+ 'begin' + CHAR(13)
+ 'exec sp_addrolemember ''PolicyAdministratorRole'', ''' + @LowPrivGroup + ''';' + CHAR(13)
+ 'end' + CHAR(13)

-------------------------------------------------------------------------------
--DEFAULT ACTION ACCOUNT
SET @SQL = @SQL + 'use master;
GRANT VIEW ANY DEFINITION TO [' + @ActionGroup + '];' + char(13) 
+ 'GRANT VIEW SERVER STATE TO [' + @ActionGroup + '];' + char(13) 
+ 'GRANT VIEW ANY DATABASE TO [' + @ActionGroup + '];' + char(13)

--add msdb permissions
SET @SQL = @SQL + 
'USE msdb;
exec sp_addrolemember ''SQLAgentReaderRole'', ''' + @ActionGroup + ''';' + char(13)
+ 'IF not exists (select 1 from sys.databases where name = ''msdb'' and compatibility_level = ''90'')' + char(13)
+ 'begin' + CHAR(13)
+ 'EXEC sp_addrolemember ''PolicyAdministratorRole'', ''' + @ActionGroup + ''';' + CHAR(13) + CHAR(13)
+ 'end'

--PRINT @SQL
exec(@SQL)