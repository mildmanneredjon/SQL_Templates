USE master;

DECLARE @trace_id int, @filename nvarchar(4000); 

SELECT @trace_id = id
 FROM   sys.traces 
WHERE  is_default = 1;

SELECT @filename = CONVERT(NVARCHAR(4000), value) 
FROM   sys.Fn_trace_getinfo(@trace_id) 
WHERE  property = 2;

SELECT *, hostname, 
       loginname, 
       starttime 
FROM   sys.Fn_trace_gettable(@filename, DEFAULT) 
/*WHERE  eventclass = 109 
AND    databasename = N'PDR' 
AND    targetusername = N'HO\cheraks'; */
WHERE loginname = 'NT AUTHORITY\SYSTEM'
AND starttime > '2016-01-23 21:10:00'
AND starttime < '2016-01-23 21:20:00'
AND DATABASEid = DB_ID('business_assurance')

--PRINT @filename
