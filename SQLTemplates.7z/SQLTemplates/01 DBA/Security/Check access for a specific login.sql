EXEC xp_logininfo
USE Work_Shared
EXEC xp_logininfo 'HO\makind', 'all'
EXEC xp_logininfo 'HO\RSSMAMMAL-EDW-ReadOnly', 'members'

use master
execute as login = 'HO\SVC_DV_RO_ACCESS'

select suser_name()

use general_marketing
SELECT * FROM fn_my_permissions (NULL, 'DATABASE');  

SELECT COUNT(*) FROM "GENERAL_MARKETING"."INFORMATION_SCHEMA"."TABLES"

use master
revert