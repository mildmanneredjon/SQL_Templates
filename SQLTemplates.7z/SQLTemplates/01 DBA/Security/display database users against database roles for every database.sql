/*Run to find database level roles for specified user or group
Leave UserOrGroupName blank to search on every user and group*/

declare @UserOrGroupName varchar(128) 
set @userorgroupname = ''

DECLARE @DB_USers TABLE
(DBName sysname, UserName varchar(128), LoginType sysname, AssociatedRole varchar(max),create_date datetime,modify_date datetime)
 
DECLARE @sql varchar(max) 
set @sql = 'use [?]
SELECT db_name() AS DB_Name,
case prin.name when ''dbo'' then prin.name + '' (''+ (select SUSER_SNAME(owner_sid) from master.sys.databases where name =''?'') + '')'' else prin.name end AS UserName,
prin.type_desc AS LoginType,
isnull(USER_NAME(mem.role_principal_id),'''') AS AssociatedRole ,create_date,modify_date
FROM sys.database_principals prin
LEFT OUTER JOIN sys.database_role_members mem ON prin.principal_id=mem.member_principal_id
WHERE prin.sid IS NOT NULL and prin.sid NOT IN (0x00) and
prin.is_fixed_role <> 1 AND prin.name NOT LIKE ''##%''
and name like left('''+@UserOrGroupName+''',10) + ''%'''
print @sql

INSERT @DB_USers
EXEC sp_MSforeachdb @sql
 
SELECT
 
dbname,username ,
 
STUFF(
 
(
 
SELECT ',' + CONVERT(VARCHAR(500),associatedrole)
 
FROM @DB_USers user2
 
WHERE
 
user1.DBName=user2.DBName AND user1.UserName=user2.UserName
 
FOR XML PATH('')
 
)
 
,1,1,'') AS Permissions_user
 
FROM @DB_USers user1
GROUP BY

dbname,username ,logintype ,create_date ,modify_date

ORDER BY username,dbname
