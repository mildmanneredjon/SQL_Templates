DECLARE @db_name VARCHAR(200) 
DECLARE @sql VARCHAR(MAX)
DECLARE @user_name VARCHAR(200)

SET @db_name = 'field'
SET @user_name = 'mcclenagmuk'

IF NOT EXISTS (SELECT 
    1
FROM
    sys.sysprocesses
WHERE 
    dbid = DB_ID(@db_name))
/*GROUP BY 
    dbid, loginame*/
BEGIN

SET @sql = 
'USE [master];
ALTER DATABASE [' + @db_name + '] SET  READ_WRITE WITH NO_WAIT;
use ' + @db_name + ';
CREATE USER [' + @user_name + '] FROM LOGIN [' + @user_name + '];
USE [master];
ALTER DATABASE [' + @db_name + '] SET READ_ONLY WITH NO_WAIT;'
exec(@sql)
END
ELSE
BEGIN
Print 'Unable to take database out of read only mode as there are users connected'
END
