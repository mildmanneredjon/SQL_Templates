/*Script to generate tsql to delete all database users associated with a sql server login

Just set @login_name and then execute. Then copy the output from the SCRIPT column*/

DECLARE @login_name VARCHAR(100)
SET @login_name = 'HO\grg_Hosvader-Gonzo_PanCreditMart_ro'

IF OBJECT_ID ('tempdb..#userlookup', N'U') IS NOT NULL
DROP TABLE #userlookup;

CREATE TABLE #userlookup (
    LoginName nvarchar(max),
    DBname nvarchar(max),
    Username nvarchar(max), 
    AliasName nvarchar(max)
)

INSERT INTO #userlookup 
EXEC master..sp_msloginmappings 

SELECT d.name AS [DATABASE],1 AS N,'use ' + d.name + ';' AS SCRIPT
FROM sys.databases d
INNER JOIN #userlookup t
ON d.name = t.dbname
where		d.name not in ('master','tempdb','model','msdb')
and			d.is_read_only = 0
and			d.[state] = 0
AND t.loginname = @login_name
UNION
SELECT d.name,2,'drop user [' + t.username + '];'
FROM sys.databases d
INNER JOIN #userlookup t
ON d.name = t.dbname
where		d.name not in ('master','tempdb','model','msdb')
and			d.is_read_only = 0
and			d.[state] = 0
AND t.loginname = @login_name
UNION
SELECT NULL, NULL, 'DROP LOGIN [' + @login_name +'];'
FROM sys.server_principals 
WHERE TYPE IN ('U', 'S', 'G')
AND name = @login_name
ORDER BY 1 desc,2