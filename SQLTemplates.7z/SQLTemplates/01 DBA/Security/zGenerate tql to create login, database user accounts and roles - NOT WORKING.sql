/* *************THIS NEEDS sp_addrolemember ADDING IN TO IT*****************

Script to generate tsql to create sql server login and all relevantdatabase users associated with another sql server login

Just set @old_login_name and @new_login_name and then execute. Then copy the output from the SCRIPT column
*/

DECLARE @old_login_name VARCHAR(100)
	,@new_login_name VARCHAR(100)
SET @old_login_name = 'rs\zzsql'
SET @new_login_name = 'HO\lamberta'	




IF OBJECT_ID ('tempdb..#userlookup', N'U') IS NOT NULL
DROP TABLE #userlookup;

CREATE TABLE #userlookup (
    LoginName nvarchar(max),
    DBname nvarchar(max),
    Username nvarchar(max), 
    AliasName nvarchar(max)
)

IF OBJECT_ID ('tempdb..#userrolelinktable', N'U') IS NOT NULL
DROP TABLE #userrolelinktable;

CREATE TABLE #userrolelinktable (
    DBname nvarchar(max),
    RoleName nvarchar(max), 
	UserName nvarchar(max),
)


INSERT INTO #userlookup 
EXEC master..sp_msloginmappings 

INSERT INTO #userrolelinktable
exec sp_MSforeachdb 'use [?];SELECT db_name(),DBRole.NAME as rolename,DBUser.NAME as dbusername 
FROM sys.database_principals DBUser
INNER JOIN sys.database_role_members DBM ON DBM.member_principal_id = DBUser.principal_id
INNER JOIN sys.database_principals DBRole ON DBRole.principal_id = DBM.role_principal_id'

select * from #userrolelinktable

SELECT d.name AS [DATABASE],1 AS N,'use ' + d.name + ';' AS SCRIPT
FROM sys.databases d
INNER JOIN #userlookup t
ON d.name = t.dbname
where		d.name not in ('master','tempdb','model','msdb')
--AND			d.is_read_only = 0
and			d.[state] = 0
AND t.loginname = @old_login_name
UNION
SELECT d.name,2,'create user [' + @new_login_name + '] for login [' + @new_login_name + '];'
FROM sys.databases d
INNER JOIN #userlookup t
ON d.name = t.dbname
where		d.name not in ('master','tempdb','model','msdb')
--AND			d.is_read_only = 0
and			d.[state] = 0
AND t.loginname = @old_login_name
UNION
SELECT urlt.name,3,'EXEC sp_AddRoleMember'''+urlt.rolename+''','''+urlt.username+''''
FROM #userrolelinktable urlt
inner join #userlookup t
on urlt.dbname = t.dbname
where d.name not in ('master','tempdb','model','msdb')
and d.[state] = 0
and
UNION
SELECT NULL, NULL, 'CREATE LOGIN [' + @new_login_name +'] from windows;'
FROM sys.server_principals 
WHERE TYPE IN ('U', 'S', 'G')
AND name = @old_login_name
ORDER BY 1,2
