DECLARE @sqlcommand VARCHAR(MAX), @windows_login VARCHAR(100), @database VARCHAR(100)

SET @windows_login = 'ho\grg_creditportfolio_sql'
SET @database = 'satsumadm'

SET @sqlcommand = '
if not exists (select loginname from master.dbo.syslogins
				where name = ''' + @windows_login + ''')
begin
CREATE LOGIN [' + @windows_login + '] FROM WINDOWS
end
USE ' + @database +'
if not exists (select name from sys.database_principals 
				where name = ''' + @windows_login + ''')
begin
CREATE USER [' + @windows_login + '] FOR LOGIN [' + @windows_login + ']
end
exec sp_addrolemember ''db_datareader'',''' + @windows_login + '''
'

--PRINT @sqlcommand
EXEC(@sqlcommand)
