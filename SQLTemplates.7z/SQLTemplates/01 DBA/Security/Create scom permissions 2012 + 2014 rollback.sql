DECLARE @SQL VARCHAR(MAX)
DECLARE @LowPrivGroup VARCHAR(200)
DECLARE @ActionGroup VARCHAR(200) 

SET @sql = ''
SET @LowPrivGroup = 'PFG\SCOM_SQLLowPriv'
SET @ActionGroup = 'PFG\SCOM_SQLAction'

SELECT @SQL = @SQL 
       + 'USE [' + name  + '];'  + CHAR(13)
	   + 'IF exists (select 1 from sys.schemas where name = '''+@LowPrivGroup+''')' + CHAR(13)
	   + 'DROP SCHEMA ['+@LowPrivGroup+']' + CHAR(13)
	   + 'IF exists (select 1 from sys.database_principals dp INNER JOIN sys.sysusers SU ON dp.principal_id = SU.uid where su.name = ''' + @LowPrivGroup + ''' and SU.hasdbaccess = 1)' + CHAR(13)
	   + 'begin' + CHAR(13)
	   + 'DROP USER [' + @LowPrivGroup + '];' + char(13)
	   + 'END' + CHAR(13)
FROM sys.databases
WHERE State_desc = 'ONLINE'
AND is_read_only = 0
and (replica_id is null --for databases not in an availability group
		or replica_id in (select replica_id from sys.dm_hadr_availability_replica_states where role = 1) -- for databases that in the primary ag replica
	)
	
SELECT @SQL = @SQL + 'IF EXISTS (select 1 from sys.syslogins where loginname = '''+@LowPrivGroup+''')' + char(13)
					+ 'DROP LOGIN ['+@LowPrivGroup+'];' + char(13)
					+ 'IF EXISTS (select 1 from sys.syslogins where loginname = '''+@ActionGroup+''')' + char(13)
					+ 'DROP LOGIN ['+@ActionGroup+'];'

--print @sql
exec(@sql)

