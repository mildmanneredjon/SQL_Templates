/*Generates script to generate a script to create users with db_owner permissions in work db's based on previous work db's
appended with ryan
e.g. work_mm db_owner accounts are created from work_mm_ryan*/

DECLARE 
	@sourcedb VARCHAR(100),
	@destinationdb VARCHAR(100),
	@sql VARCHAR(MAX)

DECLARE c CURSOR FAST_FORWARD
FOR
SELECT name FROM sys.databases
WHERE name = 'vma_Sales_List'
ORDER BY name

OPEN C
FETCH next FROM c INTO @sourcedb
WHILE @@FETCH_STATUS = 0
BEGIN
SET @destinationdb = LEFT(@sourcedb,LEN(@sourcedb)-5)
SET @sql = 'USE ' + @sourcedb + '
 select 1,''USE ' +@destinationdb+ '''
 union
 select 2,(''CREATE USER ['' +mp.name+''] FOR LOGIN ['' +mp.name+'']'')
from sys.database_role_members drm
join sys.database_principals rp on (drm.role_principal_id = rp.principal_id)
join sys.database_principals mp on (drm.member_principal_id = mp.principal_id)
where rp.name = ''db_owner''
and mp.name like ''ho%''
 union
 select 3,(''alter role [db_owner] add member ['' +mp.name+'']'')
from sys.database_role_members drm
join sys.database_principals rp on (drm.role_principal_id = rp.principal_id)
join sys.database_principals mp on (drm.member_principal_id = mp.principal_id)
where rp.name = ''db_owner''
and mp.name like ''ho%''
order by 1'
print @sql
FETCH NEXT FROM c INTO @sourcedb
END
DEALLOCATE c

