/*Finds orphaned windows user accounts and generates to tsql create the logins*/
WITH cte
as
(SELECT NAME,SID 
FROM SYS.DATABASE_PRINCIPALS
WHERE
TYPE in ('U','G') -- Windows users and groups only
AND NAME NOT LIKE 'DBO'
EXCEPT
(SELECT DP.NAME, DP.SID FROM SYS.DATABASE_PRINCIPALS DP
INNER JOIN SYS.SERVER_PRINCIPALS SP ON DP.SID = SP.SID 
WHERE DP.TYPE in ('U','G'))
)

SELECT *,'create login ['+name+'] from windows'
FROM cte

