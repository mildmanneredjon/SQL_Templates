USE master;

SELECT 
	name,
	SUSER_NAME(owner_sid) AS ExistingOwner,
	N'ALTER AUTHORIZATION ON DATABASE::'
	+QUOTENAME(name) + ' TO '
	+QUOTENAME((SELECT name
				FROM sys.sql_logins
				WHERE sid = 0x01
				))AS ScriptToChangeDBOwner
FROM sys.databases
WHERE database_id > 4
AND owner_sid <> 0x01
AND state_desc = 'ONLINE';