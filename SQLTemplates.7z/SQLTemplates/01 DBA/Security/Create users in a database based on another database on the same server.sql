/*Create users in database based on another database on the same server and map to the logins*/

DECLARE @olddbname VARCHAR(128)
DECLARE @newdbname VARCHAR(128)
SET @olddbname = 'HRProEmployee_Old'
SET @newdbname = 'HRProEmployee'

CREATE TABLE #tempww (
    LoginName nvarchar(max),
    DBname nvarchar(max),
    Username nvarchar(max), 
    AliasName nvarchar(max)
)

INSERT INTO #tempww 
EXEC master..sp_msloginmappings 

-- display results
SELECT 
'use '+@newdbname+' 
 IF not Exists (select * from sys.database_principals 
    where name = '''+username+''') 
	begin
	create user ['+loginname+'] for login ['+loginname+']
	end'
FROM   #tempww
WHERE dbname = @olddbname
ORDER BY dbname, username

-- cleanup
DROP TABLE #tempww
