/*
Connect to howaktivsql01

The following query shows which job streams on dependent on the completion of the job_stream you specify.

It also tells you which job stream the one you specify is dependent on
*/
use Tivoli_Extract
declare @job_stream varchar(32) = 'sd2rduc_etlstg_1';

with CTE_DependentOn
as
(
select 
	jsdv.dep_job_stream_name as job_stream,
	jsdv.job_stream_name as job_stream_dependent_on,
	0 as [level]
from mdl.JOB_STREAM_DEPS_V jsdv
where dep_job_stream_name = @job_stream
union all
select 
	js.dep_job_stream_name,
	js.job_stream_name as job_stream_dependent_on,
	cte.[level] + 1 as [level]
from 
	mdl.JOB_STREAM_DEPS_V js
inner join
	CTE_DependentOn cte
on
	js.job_stream_name = cte.job_stream
)
select job_stream,job_stream_dependent_on,[level]
 from cte_dependenton cte
 inner join [MDL].[AJS_ABSTRACT_JOB_STREAMS] AAJS
on cte.job_stream = aajs.AJS_NAME
inner join mdl.JST_JOB_STREAMS JS
on AAJS.[AJS_ID] = JS.[AJS_ID]
inner join [MDL].[RCY_RUN_CYCLES] rrc
on js.JST_ID = rrc.JST_ID
 order by [level]
