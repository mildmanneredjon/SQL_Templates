/*Average runtime for any job*/

declare 
	@job_name varchar(256) = 'JAGREEMENT_DIM', --leave blank to search on all jobs
	@stream_name varchar(256) = '' --leave blank to search on all job_streams

select 
	ajb_name as job,
	ajs_name as job_stream,
	count(1) as number_of_samples,
	avg(jhr_total_elapsed_time/60000) as avg_time_in_mins
from Tivoli_Extract.MDL.JHR_JOB_HISTORY_RUNS
where (AJS_NAME = @stream_name or @stream_name = '')
and (AJB_NAME = @job_name or @job_name = '')
group by AJS_NAME,AJB_NAME


/*average runtime for etl*/

SELECT 
	ajs_name as [job_stream],
	ajb_name as [job],
	case when wkc_name <> 'RSDEVDW03' then 'Production'
	else 'Preprod'
	end as environment,
	avg(jhr_total_elapsed_time/60000) as [average time in minutes]
FROM 
	[Tivoli_Extract].[MDL].[JHR_JOB_HISTORY_RUNS]
WHERE ajs_name like 'setl%'
group by ajs_name,ajb_name,case when wkc_name <> 'RSDEVDW03' then 'Production'
	else 'Preprod'
	end
order by 1,2 

/*Average runtime of JACCELERATE_CONTINUOUS on a Sunday*/

select
	ajs_name as job_stream,
	ajb_name as job,
	--jhr_total_elapsed_time/60000 as time_in_mins
	avg(jhr_total_elapsed_time/60000) as avg_time_in_mins
from
	[Tivoli_Extract].[MDL].[JHR_JOB_HISTORY_RUNS]
where ajs_name = 'SW3RMUI_ACCELCON'
and ajb_name = 'Jaccelerate_continuous'
and datepart(weekday,JHR_START_TIME) = 1
group by ajs_name,ajb_name