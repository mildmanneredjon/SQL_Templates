declare @run_cycle varchar(128) = 'etl_wknd'

select stream_name,job_name,job_task,stream_wks,JOB_WKS from tivoli_extract.dbo.main_query
where cal_name = @run_cycle
order by stream_name,job_name