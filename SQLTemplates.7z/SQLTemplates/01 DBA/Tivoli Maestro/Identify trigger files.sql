use Tivoli_Extract
SELECT 
                JJD.JOD_NAME AS JOB_NAME
                ,WW_J.WKS_NAME AS JOB_WKS
                ,JJD.JOD_DESCRIPTION AS JOB_DESC
                ,JJD.JOD_USER_LOGIN AS JOB_USER
                ,JJD.JOD_TASK_STRING AS JOB_TASK
                ,AAJS.AJS_NAME AS STREAM_NAME
                ,WW_S.WKS_NAME AS STREAM_WKS
                ,JJS.[JST_DESCRIPTION] AS STREAM_DESC
                ,RRC.RCY_ICALENDAR
                ,RRC.RCY_VALID_TO
                ,CC.[CAL_ICALENDAR]
                , Res.Res_name

FROM [Tivoli_Extract].[MDL].[JOB_JOBS] JJ
--******* Join Jobs *******--
LEFT JOIN [MDL].[JOD_JOB_DEFINITIONS] JJD
ON JJ.[JOD_ID] = JJD.[JOD_ID]
LEFT JOIN [MDL].[WKS_WORKSTATIONS] WW_J
                ON JJD.WKC_ID = WW_J.WKC_ID

--******* Join Streams *******--
LEFT JOIN [MDL].[AJB_ABSTRACT_JOBS] AAJ
                ON JJ.[AJB_ID] = AAJ.[AJB_ID]
LEFT JOIN [MDL].[AJS_ABSTRACT_JOB_STREAMS] AAJS
                ON AAJ.AJS_ID = AAJS.AJS_ID
LEFT JOIN [MDL].[WKS_WORKSTATIONS] WW_S
                ON AAJS.WKC_ID = WW_S.WKC_ID
LEFT JOIN [MDL].[JST_JOB_STREAMS] JJS
                ON JJ.[JST_ID] = JJS.[JST_ID]
                
--******* Join RunCycles *******--
LEFT JOIN [MDL].[RCY_RUN_CYCLES] RRC
                ON RRC.JST_ID = JJ.JST_ID

LEFT JOIN [MDL].[CAL_CALENDARS] CC
                ON RRC.[CAL_ID] = CC.[CAL_ID]
left join MDL.RDP_RESOURCE_DEPS deps             on           jj.JOB_ID = deps.Job_ID
left join MDL.RES_ABSTRACT_RESOURCES res on deps.RES_ID = Res.RES_ID
--where   AAJS.AJS_NAME = 'SAGENTCOMMISSION'