/*average runtime for etl*/
declare @num_of_jobs int

select @num_of_jobs = count(distinct ajb_name)
from Tivoli_Extract.MDL.JHR_JOB_HISTORY_RUNS
where ajs_name like '%etl%'
and wkc_name <> 'RSDEVDW03';

with prod_cte
as
(
SELECT 
	ajs_name as [prod_job_stream],
	ajb_name as [prod_job],
	avg(jhr_total_elapsed_time/60000) as [prod average time in minutes]
FROM Tivoli_Extract.MDL.JHR_JOB_HISTORY_RUNS
WHERE ajs_name like '%etl%'
and wkc_name <> 'RSDEVDW03'
and JHR_RETURN_CODE = 0
GROUP BY ajs_name,ajb_name),

preprod_cte
as
(SELECT 
	ajs_name as [preprod_job_stream],
	ajb_name as [preprod_job],
	avg(jhr_total_elapsed_time/60000) as [preprod average time in minutes]
FROM Tivoli_Extract.MDL.JHR_JOB_HISTORY_RUNS
WHERE ajs_name like '%etl%'
and wkc_name = 'RSDEVDW03'
and JHR_RETURN_CODE = 0
GROUP BY ajs_name,ajb_name)

select prod_cte.prod_job_stream,
		preprod_cte.preprod_job_stream,
		prod_cte.prod_job as job,
		prod_cte.[prod average time in minutes],
		preprod_cte.[preprod average time in minutes]
from prod_cte
inner join preprod_cte
on prod_cte.prod_job = preprod_cte.preprod_job



if @compared <> @num_of_jobs
	declare @message varchar(200)
	set @message = 'There are '+cast(@num_of_jobs as varchar(4))+', but only '+cast(@compared as varchar(4))' have been compared
	raiserror('number of jobs differs',16,1)