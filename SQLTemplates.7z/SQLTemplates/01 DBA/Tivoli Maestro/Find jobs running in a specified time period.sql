/*
Find all jobs that were running between a specified time period

Results are returned in UK time

Note - The data available for this is up to only available up to 6am for the current day.
		If you need data after this then you need to wait until the following day or look in tivoli.
*/

DECLARE 
	@TimeRangeStart datetime2 = '2019-01-27 02:00',
	@TimeRangeEnd datetime2 = '2019-01-27 02:01'

IF (SELECT RIGHT(SYSDATETIMEOFFSET ( ) ,6)) = '+01:00' --records are stored in UST so this checks if it's british summer time
BEGIN
	SELECT
		ajs_name AS Job_Stream,
		ajb_name AS Job_Name,
		DATEADD(MINUTE,-60,jhr_run_date) AS Start_Time,
		DATEADD(MINUTE,jhr_total_elapsed_time/60000,DATEADD(MINUTE,-60,jhr_run_date)) AS Finish_Time,
		Case JHR_Status
			WHEN 'S' THEN 'Success'
			WHEN 'A' THEN 'Abend'
			ELSE 'Unknown'
		End AS Job_Status
	FROM 
		Tivoli_Extract.MDL.JHR_JOB_HISTORY_RUNS
	WHERE 
		jhr_run_date <= DATEADD(MINUTE,-60,@TimeRangeEnd)
	AND 
		DATEADD(MINUTE,jhr_total_elapsed_time/60000,jhr_run_date) >= DATEADD(MINUTE,-60,@TimeRangeStart)
	ORDER BY 
		jhr_run_date ASC
END
ELSE
BEGIN
	SELECT 
		ajs_name AS Job_Stream,
		ajb_name AS Job_Name,
		jhr_run_date AS Start_Time,
		DATEADD(MINUTE,jhr_total_elapsed_time/60000,jhr_run_date) AS Finish_Time,
		Case JHR_Status
			WHEN 'S' THEN 'Success'
			WHEN 'A' THEN 'Abend'
			ELSE 'Unknown'
		End AS Job_Status
	FROM 
		[Tivoli_Extract].[MDL].[JHR_JOB_HISTORY_RUNS]
	WHERE 
		jhr_run_date < @TimeRangeEnd
	AND 
		DATEADD(MINUTE,jhr_total_elapsed_time/60000,jhr_run_date) >= @TimeRangeStart
	ORDER BY 
		jhr_run_date ASC
END
