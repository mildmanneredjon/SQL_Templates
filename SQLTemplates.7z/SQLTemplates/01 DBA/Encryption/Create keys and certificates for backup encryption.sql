/*
See the following document for details:
G:\DBA\002 Documentation\003 System Documentation\Backup Encryption\Create keys and certificates for backup encryption.docx

Set the values for passwords and the backup location. 
If backing up locally ensure the master key backup, certificate backup and private key file are moved to the appropriate backup server.
Ensure any new passwords are saved to the password vault.

select * from sys.symmetric_keys
select * from sys.certificates

*/
DECLARE @sql VARCHAR(max)

DECLARE @smkbackuppassword VARCHAR(100) = 'xxxxxxxxxxxx' --ServiceMasterKeyBackup --Only required if the service master key hasn't already been backed up or if you don't have a copy of the password
DECLARE @masterkeypassword VARCHAR(100) = 'xxxxxxxxxxxx' --DatabaseMasterKeys --Only required if the master key hasn't already been setup
DECLARE @certificatebackuppassword VARCHAR(100) = 'xxxxxxxxxxx' --DatabaseCertBackup
DECLARE @mkbackuppassword VARCHAR(100) = 'xxxxxxxxxxxx' --DatabaseMasterKeyBackup
DECLARE @backuplocation VARCHAR(100) = 'C:\temp' --don't put a slash at the end

SET @sql = 
'
/*Ensure you are in the master database*/
USE master

/*Backup the service master key - this is only required if you don''t already have an existing backup of this available*/

BACKUP SERVICE MASTER KEY
TO FILE = '''+@backuplocation+'\'+replace(@@servername,'\','#')+'_SMK.key''
ENCRYPTION BY PASSWORD = '''+@smkbackuppassword+'''

/*Check if Certificate exists with expiry date of 31/12/9999 and exit if it does*/
IF EXISTS(SELECT 1 FROM sys.certificates WHERE name = '''+replace(@@servername,'\','#')+'_BackupCert'' AND expiry_date >= ''9999-12-31'')
BEGIN
	PRINT ''Certificate with expiry date of 31/12/9999 already exists''
	RETURN
END

/*Check for the existence of a master key and create it if it doesn''t already exist*/
IF NOT EXISTS (SELECT 1 FROM sys.symmetric_keys WHERE name LIKE ''%DatabaseMasterKey%'')
BEGIN
	CREATE MASTER KEY ENCRYPTION BY PASSWORD = '''+@masterkeypassword+'''

	BACKUP MASTER KEY
	TO FILE = '''+@backuplocation+'\'+replace(@@servername,'\','#')+'_DMK.key''
	ENCRYPTION BY PASSWORD = '''+@mkbackuppassword+'''
END

/*Backup, drop and restore existing certificate with the name appended with the current date if it already exists*/
IF EXISTS (SELECT 1 FROM sys.certificates WHERE name = '''+replace(@@servername,'\','#')+'_BackupCert'')
BEGIN
	BACKUP CERTIFICATE '+replace(@@servername,'\','#')+'_BackupCert
	TO FILE = '''+@backuplocation+'\'+replace(@@servername,'\','#')+'Old_BackupCert_'+cast(YEAR(getdate())*10000+MONTH(getdate())*100+DAY(getdate()) as varchar(8))+'.cer''
	WITH PRIVATE KEY
        (
		    FILE = '''+@backuplocation+'\'+replace(@@servername,'\','#')+'_BackupCert_'+cast(YEAR(getdate())*10000+MONTH(getdate())*100+DAY(getdate()) as varchar(8))+'.key''
			, ENCRYPTION BY PASSWORD = '''+@certificatebackuppassword+'''
        );

	DROP CERTIFICATE '+replace(@@servername,'\','#')+'_BackupCert

	CREATE CERTIFICATE '+replace(@@servername,'\','#')+'_BackupCert_'+cast(YEAR(getdate())*10000+MONTH(getdate())*100+DAY(getdate()) as varchar(8))+'
	FROM FILE = '''+@backuplocation+'\'+replace(@@servername,'\','#')+'_BackupCert_'+cast(YEAR(getdate())*10000+MONTH(getdate())*100+DAY(getdate()) as varchar(8))+'.cer''
	WITH PRIVATE KEY 
		(
			FILE = '''+@backuplocation+'\'+replace(@@servername,'\','#')+'_BackupCert_'+cast(YEAR(getdate())*10000+MONTH(getdate())*100+DAY(getdate()) as varchar(8))+'.key'',
			DECRYPTION BY PASSWORD = '''+@certificatebackuppassword+'''
		)
END

/*Create a new certificate with an expiry date of 31/12/9999*/

CREATE CERTIFICATE '+replace(@@servername,'\','#')+'_BackupCert
WITH SUBJECT = ''Backup certificate for '+replace(@@servername,'\','#')+''', EXPIRY_DATE = ''9999-12-31''

BACKUP CERTIFICATE '+replace(@@servername,'\','#')+'_BackupCert
TO FILE = '''+@backuplocation+'\'+replace(@@servername,'\','#')+'_BackupCert.cer''
WITH PRIVATE KEY
        (
                FILE = '''+@backuplocation+'\'+replace(@@servername,'\','#')+'_BackupCert.key''
                , ENCRYPTION BY PASSWORD = '''+@certificatebackuppassword+'''
        );'

print(@sql)
