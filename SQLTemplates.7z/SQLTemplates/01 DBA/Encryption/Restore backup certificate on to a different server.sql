/*To restore an encrypted backup on to another server you need to create the certificate 1st from the backups of the source server*/

declare 
	@sql varchar(5000),
	@certificate_name varchar(128) = 'HOEVADB01_BackupCert', --this can be set to anything as long as a certificate with the same name doesn't already exist on the destination server 
	@path_to_encrypted_backups varchar(128) = 'c:\temp', --copy the certificate backup file and private key backup file into here
	@CertificateBackupFile varchar(128) = 'HOEVADB01_BackupCert.cer', --this will be located on the backup server 'HOEVADB01_BackupCertOld.bak'
	@PrivateKeyBackupFile varchar(128) = 'HOEVADB01_BackupCert.key',  --this will be located on the backup server 'HOEVADB01_BackupCertKeyOld.bak'
	@PrivateKeyPassword varchar(128) = '*H0I5bK2o=0?' --the password is stored in the password safe under DatabaseCertBackup


set @sql =
'use master
	create certificate '+@certificate_name+' 
	from file = '''+@path_to_encrypted_backups+'\'+@CertificateBackupFile+'''
	with private key (file = '''+@path_to_encrypted_backups+'\'+@PrivateKeyBackupFile+''',
	decryption by password = '''+@PrivateKeyPassword+''');'

print @sql