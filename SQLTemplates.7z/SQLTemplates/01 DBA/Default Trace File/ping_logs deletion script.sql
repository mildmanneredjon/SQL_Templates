DECLARE @sql VARCHAR(1000);
DECLARE @databasename VARCHAR(20);
DECLARE @count INT;

DECLARE database_cursor CURSOR FAST_FORWARD FOR
SELECT name FROM sys.databases
WHERE name LIKE 'PingLogs_Jobs_%'

OPEN database_cursor
FETCH next FROM database_cursor INTO @databasename
WHILE @@FETCH_STATUS = 0
BEGIN
	SET @sql = 'USE @databasename'
	EXEC(@sql)

	DECLARE @tablename VARCHAR(10)
	DECLARE table_cursor CURSOR FAST_FORWARD FOR
	SELECT name FROM sys.tables
	WHERE name LIKE 'Job_%'
	AND type = 'U'

	OPEN table_cursor
	FETCH next FROM table_cursor INTO @tablename
	WHILE @@FETCH_STATUS = 0
	BEGIN
		SET @count = 1
		WHILE(@count > 0)
		BEGIN 
			BEGIN TRANSACTION TDelete
    
				SET @sql = 'WITH CTE AS
				(
				SELECT TOP(10000) *
				FROM '+@tablename+'
				WHERE PingTime < CURRENT_TIMESTAMP - 365
				)
    
				DELETE FROM CTE'
				PRINT @sql

			rollback TRANSACTION TDelete
 
		--	SELECT @count = COUNT(1) 
		--	FROM @tablename
		--	WHERE PingTime < CURRENT_TIMESTAMP - 365
 
		--	PRINT 'DELETED 10 000 -> '+ CONVERT(VARCHAR(10),@count) + ' REMAINING'
		FETCH NEXT FROM table_cursor INTO @tablename
		END;
	END;
	CLOSE table_cursor;
	DEALLOCATE table_cursor;
	FETCH NEXT FROM database_cursor INTO @databasename
END;
CLOSE database_cursor;
DEALLOCATE database_cursor;