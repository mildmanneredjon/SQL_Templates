/***Query all default trace files - add your search criteria into the where clause inside the cursor loop 
and change the order by as required***/

DECLARE @trace_file_directory VARCHAR(255)
DECLARE @file_list TABLE (subdirectory VARCHAR(255),depth int,[FILE] int)
DECLARE @trace_file VARCHAR(255)

/*Get the directory containing the trace files*/

SET @trace_file_directory = (SELECT LEFT(path,LEN(path) - CHARINDEX('\',REVERSE(path)) + 1) FROM   sys.traces WHERE id = 1)

/*Insert all files in the directory into a table variable*/

INSERT INTO @file_list
EXEC Master.dbo.xp_DirTree @trace_file_directory,1,1

/*Create temporary table to store all the data*/

IF OBJECT_ID('tempdb..#TraceFileResult') IS NOT NULL
    DROP TABLE #TraceFileResults

CREATE TABLE #TraceFileResults
(
StartTime DATETIME,
EndTime DATETIME,
applicationname VARCHAR(255),
textdata VARCHAR(MAX),
clientprocessid INT,
spid INT,
databasename VARCHAR(255),
ntusername VARCHAR(255),
hostname VARCHAR(255),
duration INT,
reads INT,
writes INT,
cpu INT,
objectName VARCHAR(255)
)

/*Loop through all the trace files in the directory based on the where clause*/

DECLARE c CURSOR FAST_FORWARD
FOR
SELECT subdirectory FROM @file_list
WHERE subdirectory LIKE 'log_%'

OPEN c
FETCH NEXT FROM c INTO @trace_file
WHILE @@FETCH_STATUS = 0
BEGIN
INSERT INTO #TraceFileResults
SELECT StartTime,EndTime,ApplicationName,TextData,ClientProcessID,SPID,databasename,ntusername,hostname,duration,reads,writes,cpu,objectname from
sys.Fn_trace_gettable(@trace_file_directory + @trace_file, DEFAULT)
WHERE starttime < '2016-12-08' --modify this line as required
and starttime > '2016-12-08'
AND EventClass 
      in (102,103,104,105,106,108,109,110,111)*/
--	  textdata LIKE '%batchuser%'
FETCH NEXT FROM c INTO @trace_file
END

/*Return all the entries and order by as required*/

SELECT * FROM #TraceFileResults
ORDER BY StartTime --modify this line as required

/*Clean up afterwards*/

DROP TABLE #TraceFileResults