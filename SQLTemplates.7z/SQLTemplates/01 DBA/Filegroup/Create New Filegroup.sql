SELECT * FROM sys.filegroups

ALTER DATABASE DBSMaintenance ADD FILEGROUP DATA

ALTER DATABASE DBSMaintenance
ADD FILE
(
NAME='DBSMaintenance_Data',
FILENAME = 'V:\SQL\MSSQL13.MSSQLSERVER\MSSQL\DATA\DBSMaintenance_Data.mdf'
)
TO FILEGROUP DATA


IF NOT EXISTS (SELECT name FROM sys.filegroups WHERE is_default=1 AND name = N'DATA') 
    ALTER DATABASE [DBSMaintenance] MODIFY FILEGROUP [DATA] DEFAULT

SELECT o.[name] AS TableName, i.[name] AS IndexName, fg.[name] AS FileGroupName
FROM sys.indexes i
INNER JOIN sys.filegroups fg ON i.data_space_id = fg.data_space_id
INNER JOIN sys.all_objects o ON i.[object_id] = o.[object_id]
WHERE i.data_space_id = fg.data_space_id AND o.type = 'U'