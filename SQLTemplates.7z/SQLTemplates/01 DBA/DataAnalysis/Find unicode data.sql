/*
This generates a script that will do a union to find all unicode data in every table for the specified
database

You need to then copy all lines and delete "union" from the last line.

Obviously only run in test as it will have a long runtime.
*/

use FCA_Mart
select 'select '''+table_schema+''' as [schema],'''+table_name+''' as [table],'''+column_name+''' as [column], '+column_name+' from '+TABLE_SCHEMA+'.'+TABLE_NAME+' where '+COLUMN_NAME+' <> cast('+COLUMN_NAME+' as varchar(500)) union '
from information_schema.columns
where data_type in ('nchar','nvarchar','ntext')