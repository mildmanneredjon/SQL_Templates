/*
Run this against the database to find the most recent date value.

Do not run this against large databases on live servers.
*/

create table #mostrecentvalue (table_schema varchar(128),table_name varchar(128),column_name varchar(128), most_recent_date datetime)

declare @table_schema varchar(128), @table_name varchar(128), @column_name varchar(128)

declare c cursor fast_forward
for
select table_schema,table_name,column_name
from INFORMATION_SCHEMA.columns
where data_type like 'date%'

open c
fetch next from c into @table_schema,@table_name,@column_name

while @@FETCH_STATUS = 0
begin
	exec('insert into #mostrecentvalue
			select '''+@table_schema+''','''+@table_name+''','''+@column_name+''',max(['+@column_name+']) 
			from ['+@table_schema+'].['+@table_name+']')
	fetch next from c into @table_schema,@table_name,@column_name
end

close c
deallocate c

select * from #mostrecentvalue
order by most_recent_date desc

drop table #mostrecentvalue
