/************** Mark Ma 2017-06-27 
	Find the sensitive data columns
*****************/

DECLARE @SensitiveWords varchar(max) = 'Person, Custom, Last%name, surname, birth, address, gender, salary, name'
DECLARE @Separador CHAR(1) = ','

Declare @t TABLE(
    ID  INT IDENTITY PRIMARY KEY,
    WordStemp VARCHAR(MAX)
)


;WITH Entrada AS(
    SELECT
        CAST(1 AS Int) As Inicio,
        CHARINDEX(@Separador, @SensitiveWords) As Fim
    UNION ALL
    SELECT
        CAST(Fim + LEN(@Separador) AS Int) As Inicio,
        CHARINDEX(@Separador, @SensitiveWords, Fim + 1) As Fim
    FROM Entrada
    WHERE CHARINDEX(@Separador, @SensitiveWords, Fim + 1) > 0
)

INSERT @t(WordStemp)
SELECT 
    SUBSTRING(@SensitiveWords, Inicio, Fim - Inicio)
FROM Entrada
WHERE (Fim - Inicio) > 0

---------------------
select * from @t

select OBJECT_SCHEMA_NAME(a.object_id) + '.' + a.name  + '.' +  b.name as Cname from sys.tables a
JOIN sys.columns b
ON a.object_id = b.object_id
JOIN @T AS c
on (a.name like '%' + c.WordStemp + '%' and b.name like '%' + c.WordStemp + '%')
OR b.name like '%' + c.WordStemp + '%'


