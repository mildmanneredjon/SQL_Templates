declare @SPsWithLinkedServersTOHOEAVDB01 table (dbname varchar(128), sp varchar(256),sp_detail varchar(max))

insert into @SPsWithLinkedServersTOHOEAVDB01
execute sp_msforeachdb 'use [?]
SELECT db_name(),ROUTINE_NAME, ROUTINE_DEFINITION
FROM INFORMATION_SCHEMA.ROUTINES 
WHERE (ROUTINE_DEFINITION LIKE ''%hosrocky\balboa%''
or ROUTINE_DEFINITION LIKE ''%hosbangkok\greenback%''
or ROUTINE_DEFINITION LIKE ''%hosgiggsy\ryan%''
or ROUTINE_DEFINITION LIKE ''%hosrooney\marge%''
or ROUTINE_DEFINITION LIKE ''%hossolway\wicker%''
or ROUTINE_DEFINITION LIKE ''%hosvader\gonzo%'')
AND ROUTINE_TYPE=''PROCEDURE'''

select * from @SPsWithLinkedServersTOHOEAVDB01