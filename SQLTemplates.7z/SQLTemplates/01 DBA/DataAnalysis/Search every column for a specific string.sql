--Identifying a specific string in the database, such as trigger file name:

Declare @table_name varchar(128), @table_Schema varchar(128), @column_name varchar(128), @SQL varchar(8000), @string varchar(255)

Select    @string = 'LoadCardPaymentsMIData.trig'
--Select @string = '79EEC6AF7CCE3DD2AED50FF6622A784E'

Declare field cursor  local
for
Select table_name, table_Schema, column_name
from      information_schema.columns
where data_type in ('char', 'varchar')

Open     field


Fetch next from field into @table_name, @table_Schema, @column_name

While @@Fetch_Status = 0
begin
                Select @SQL = 
                'If exists (Select * from ' + @table_Schema + '.' + @table_name + ' where ' + @column_name + ' like ''%' + @string + '%'')
                begin
                                Select    ''' + @table_Schema + ''',''' + @table_name + '''
                                Select * from ' + @table_Schema + '.' + @table_name + ' where ' + @column_name + ' like ''%' + @string + '%''

                end'

                print @SQL
                ;

                exec (@SQL)
                ;

                Fetch next from field into @table_name, @table_Schema, @column_name

end