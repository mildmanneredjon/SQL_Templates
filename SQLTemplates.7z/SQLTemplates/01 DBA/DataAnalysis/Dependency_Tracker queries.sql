/*Find cross database queries for the database in question*/
declare @databasetocheck varchar(128) = 'accelerate'

SELECT [Referencing_DatabaseName]
      ,[Referencing_SchemaName]
      ,[Referencing_ObjectName]
      ,[Referencing_ObjectType]
      ,[Referenced_DatabaseName]
      ,[Referenced_SchemaName]
      ,[Referenced_ObjectName]
      ,[Referenced_ObjectType]
      ,[CrossDatabase]
  FROM [DBSAdmin].[Tracker].[vw_DirectDependencies]
  where crossdatabase is not null
  and (referencing_databasename = @databasetocheck or referenced_databasename = @databasetocheck)
  