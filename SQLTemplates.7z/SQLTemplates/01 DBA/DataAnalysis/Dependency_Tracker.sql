-- Servers that script is to be run on
	:setvar ServerName1 "HOEVADB01"

-- Connect to server
	:connect $(ServerName1)

	Set Nocount On
	go

	Use DBSAdmin
	go

-- Create table to hold objects	
	
	if not exists (Select * from information_Schema.schemata where schema_name = 'Tracker')
	begin
		exec('Create Schema Tracker')
	end

	if not exists (select * from information_Schema.tables where table_name = 'Objects' and table_Schema = 'Tracker')
	begin
		Create  table Tracker.Objects
		(
		Object_ID int,
		DatabaseName sysname,
		SchemaName sysname,
		ObjectName sysname,
		Type_Desc sysname
		)
		WITH (DATA_COMPRESSION = PAGE) 
	end
	else 
	begin
		Truncate table Tracker.Objects
	end
	go

	if not exists (select * from information_Schema.tables where table_name = 'ObjectLinks' and table_Schema = 'Tracker')
	begin
		Create  table Tracker.ObjectLinks
		(
		referencing_object int,
		referencing_object_Database sysname,
		referenced_object int,
		referenced_object_Database sysname
		)
		WITH (DATA_COMPRESSION = PAGE)
	end
	else 
	begin
		Truncate table Tracker.ObjectLinks
	end
	go

	if not exists (select * from information_Schema.tables where table_name = 'CataloguedDatabases' and table_Schema = 'Tracker')
	begin
		Create  table Tracker.CataloguedDatabases
		(
		DatabaseName sysname
		)
		WITH (DATA_COMPRESSION = PAGE)
	end
	else 
	begin
		Truncate table Tracker.CataloguedDatabases
	end
	go

	if not exists (select * from information_Schema.tables where table_name = 'UncataloguedDatabases' and table_Schema = 'Tracker')
	begin
		Create  table Tracker.UncataloguedDatabases
		(
		DatabaseName sysname
		)
		WITH (DATA_COMPRESSION = PAGE)
	end
	else 
	begin
		Truncate table Tracker.UncataloguedDatabases
	end
	go

	if not exists (select * from information_Schema.tables where table_name = 'vw_DirectDependencies' and table_Schema = 'Tracker')
	begin
		exec('
		Create View Tracker.vw_DirectDependencies
		as
			Select	op.DatabaseName Referencing_DatabaseName,
				op.SchemaNAme Referencing_SchemaName,
				op.ObjectName Referencing_ObjectName,
				op.Type_Desc Referencing_ObjectType,
				oc.DatabaseName Referenced_DatabaseName,
				oc.SchemaNAme Referenced_SchemaName,
				oc.ObjectName Referenced_ObjectName,
				oc.Type_Desc Referenced_ObjectType,
				case when op.DatabaseName <> oc.DatabaseName then ''Y'' else null end CrossDatabase
			from	[Tracker].[ObjectLinks] l
			join	[Tracker].[Objects] op	on	op.Object_ID = l.referencing_object
						and	op.DatabaseName = l.referencing_object_Database
			join	[Tracker].[Objects] oc	on	oc.Object_ID = l.referenced_object
						and	oc.DatabaseName = l.referenced_object_Database')
	end
	go

	if not exists (Select * from information_Schema.routines where routine_schema = 'Tracker' and routine_name = 'ufn_TrackReferencedItems')
	begin
		exec ('
		CREATE FUNCTION Tracker.ufn_TrackReferencedItems (@ReferencingObject varchar(500))

		RETURNS TABLE 
		AS
		RETURN 
		(
			With Dependencies as
		(
		Select	oc.DatabaseName Referenced_DatabaseName,
			oc.SchemaNAme Referenced_SchemaName,
			oc.ObjectName Referenced_ObjectName,
			oc.Object_ID Referenced_ObjectID,
			oc.Type_Desc Referenced_ObjectType,
			1 Level
		from	[Tracker].[ObjectLinks] l
		join	[Tracker].[Objects] op	on	op.Object_ID = l.referencing_object
					and	op.DatabaseName = l.referencing_object_Database
		join	[Tracker].[Objects] oc	on	oc.Object_ID = l.referenced_object
					and	oc.DatabaseName = l.referenced_object_Database
		where	op.DatabaseName = parsename(@ReferencingObject, 3)
		and	op.SchemaNAme = isnull(parsename(@ReferencingObject, 2), ''dbo'')
		and	op.ObjectName = parsename(@ReferencingObject, 1)
		union	all
		SELECT	oc.DatabaseName Referenced_DatabaseName,
			oc.SchemaNAme Referenced_SchemaName,
			oc.ObjectName Referenced_ObjectName,
			oc.Object_ID Referenced_ObjectID,
			oc.Type_Desc Referenced_ObjectType,
			Level + 1
		FROM Dependencies d
		join	[Tracker].[ObjectLinks] l	on	d.Referenced_DatabaseName = l.referencing_object_Database
						and	d.Referenced_ObjectID = l.[referencing_object]
		join	[Tracker].[Objects] op	on	op.Object_ID = l.referencing_object
					and	op.DatabaseName = l.referencing_object_Database
		join	[Tracker].[Objects] oc	on	oc.Object_ID = l.referenced_object
					and	oc.DatabaseName = l.referenced_object_Database
		)
		Select	distinct Referenced_DatabaseName,
			Referenced_SchemaName,
			Referenced_ObjectName,
			Referenced_ObjectType,
			1 Level
		from	Dependencies
		)')
	end
	go

	if not exists (Select * from information_Schema.routines where routine_schema = 'Tracker' and routine_name = 'ufn_TrackReferencingItems')
	begin
		exec ('
		CREATE FUNCTION Tracker.ufn_TrackReferencingItems (@ReferencedObject varchar(500))

		RETURNS TABLE 
		AS
		RETURN 
		(
			With Dependencies as
			(
			Select	op.DatabaseName Referencing_DatabaseName,
				op.SchemaNAme Referencing_SchemaName,
				op.ObjectName Referencing_ObjectName,
				op.Object_ID Referencing_ObjectID,
				op.Type_Desc Referencing_ObjectType,
				1 Level
			from	[Tracker].[ObjectLinks] l
			join	[Tracker].[Objects] op	on	op.Object_ID = l.referencing_object
						and	op.DatabaseName = l.referencing_object_Database
			join	[Tracker].[Objects] oc	on	oc.Object_ID = l.referenced_object
						and	oc.DatabaseName = l.referenced_object_Database
			where	oc.DatabaseName = parsename(@ReferencedObject, 3)
			and	oc.SchemaNAme = isnull(parsename(@ReferencedObject, 2), ''dbo'')
			and	oc.ObjectName = parsename(@ReferencedObject, 1)
			union	all
			SELECT	op.DatabaseName Referenced_DatabaseName,
				op.SchemaNAme Referenced_SchemaName,
				op.ObjectName Referenced_ObjectName,
				op.Object_ID Referenced_ObjectID,
				op.Type_Desc Referenced_ObjectType,
				Level + 1
			FROM Dependencies d
			join	[Tracker].[ObjectLinks] l	on	d.Referencing_DatabaseName = l.referenced_object_Database
							and	d.Referencing_ObjectID = l.[referenced_object]
			join	[Tracker].[Objects] op	on	op.Object_ID = l.referencing_object
						and	op.DatabaseName = l.referencing_object_Database
			join	[Tracker].[Objects] oc	on	oc.Object_ID = l.referenced_object
						and	oc.DatabaseName = l.referenced_object_Database
			)
		Select	distinct Referencing_DatabaseName,
			Referencing_SchemaName,
			Referencing_ObjectName,
			Referencing_ObjectType,
			1 Level
		from	Dependencies
		)')
	end
	go

-- Catalogue objects

	insert	Tracker.Objects
	exec sp_MSForEachdb '
	Select	o.Object_ID Object_ID,
		''?'' DatabaseName,
		s.name SchemaName,
		o.name ObjectName,
		o.Type_Desc
	from	[?].sys.objects o
	join	[?].sys.schemas s	on	o.schema_ID = s.schema_ID
	where	o.type_Desc <> ''SYSTEM_TABLE''
	'
	go 


-- Catalogue links

	Declare	@CurDB sysname
	Declare	@SQL varchar(8000)

	Declare dbs Cursor local forward_only
	for
	Select	name
	from	sys.databases

	Open dbs
	Fetch next from dbs into @CurDB

	while @@Fetch_Status = 0
	begin
		begin try

		
			Select	@SQL = '	SELECT  referencing_id,
						''' + @CurDB + ''',
						object_ID(isnull(referenced_database_name,''' + @CurDB + ''') + ''.'' + isnull(referenced_schema_name,''dbo'') + ''.'' + referenced_entity_name) Referenced_Object_ID,
						isnull(referenced_database_name,''' + @CurDB + ''') 
					from	[' + @CurDB + '].sys.sql_expression_dependencies d
			'
		
			insert	 Tracker.ObjectLinks
			exec (@SQL)
			;

			insert  Tracker.CataloguedDatabases
			Select	@CurDB
			;
		end try
		begin catch
			insert  Tracker.UnCataloguedDatabases
			Select	@CurDB
			;
		End Catch

		Fetch next from dbs into @CurDB
	end

	close dbs
	deallocate dbs
