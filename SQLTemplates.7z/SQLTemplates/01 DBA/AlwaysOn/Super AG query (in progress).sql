select 
	ag.name as AG,
	ag.name as replica
	ags.primary_replica, 
	case ags.primary_recovery_health 
		when 0 then 'in progress'
		when 1 then 'Online'
		else 'not the primary replica'
	end as primary_status,

									ags.* 
from sys.dm_hadr_availability_group_states ags
inner join sys.availability_groups ag
on ags.group_id = ag.group_id
inner join sys.dm_hadr_availability_replica_states ars
on ag.group_id = ars.group_id
where ag.name = 'SVC-PROD'

select * from sys.availability_replicas
select * from sys.availability_groups
select * from sys.dm_hadr_availability_replica_states 
select * from sys.dm_hadr_cluster_members
select * from sys.dm_hadr_availability_group_states ags


select 
	ag.name as AG,
	ar.replica_server_name,
	ags.primary_replica,
	ar.failover_mode_desc,
	cm.number_of_quorum_votes,
	case ags.primary_recovery_health 
		when 0 then 'in progress'
		when 1 then 'Online'
		else 'not the primary replica'
	end as primary_status,
	case ags.synchronization_health
		when 0 then 'not healthy'
		when 1 then 'partially healthy - some nodes aren''t synchronized'
		when 2 then 'healthy'
	end as synchronisation_health
from
	sys.availability_replicas ar
inner join
	sys.dm_hadr_availability_replica_states ars
on
	ar.replica_id = ars.replica_id
inner join 
	sys.availability_groups ag
on
	ars.group_id = ag.group_id
inner join
	sys.dm_hadr_availability_group_states ags
on
	ag.group_id = ags.group_id
inner join
	sys.dm_hadr_cluster_members cm
on
	ar.replica_server_name = cm.member_name
where
	ag.name = 'SVC-PROD'
