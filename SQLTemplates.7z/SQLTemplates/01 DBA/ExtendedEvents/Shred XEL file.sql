/*
Set the value of the trace file and execute
Once it completes query #finalresults as required. Remember to drop #queryresults when you have finished.

Please be aware that this can take a long time to run, so copy the .xel file to a development server before running

One 50mb can take 

*/
set nocount on

IF OBJECT_ID('tempdb..##myxml') IS NOT NULL
    DROP TABLE ##myxml
CREATE TABLE ##myxml
    (
      id INT IDENTITY
    , actual_xml XML
    )

INSERT  INTO ##myxml
        SELECT CAST(event_data AS XML)
        FROM    sys.fn_xe_file_target_read_file('d:\trace\traceconnectionstoaccelerateandacceleratecontrol.xel', null, null, null)

IF OBJECT_ID('tempdb..##ParsedData') IS NOT NULL
    DROP TABLE ##ParsedData
CREATE TABLE ##ParsedData
    (
      id INT
    , Actual_Time DATETIME
    , EventType sysname
    , ParsedName sysname
    , NodeValue VARCHAR(MAX)
    )

INSERT  INTO ##ParsedData 

        SELECT  id
              , DATEADD(MINUTE, DATEPART(TZoffset, SYSDATETIMEOFFSET()),
                        UTC_Time) AS Actual_Time
              , EventType
              , ParsedName
              , NodeValue
        FROM    ( SELECT    id
                          , A.B.value('@name[1]', 'varchar(128)') AS EventType
                          , A.B.value('./@timestamp[1]', 'datetime') AS UTC_Time
                          , X.N.value('local-name(.)', 'varchar(128)') AS NodeName
                          , X.N.value('../@name[1]', 'varchar(128)') AS ParsedName
                          , X.N.value('./text()[1]', 'varchar(max)') AS NodeValue
                  FROM      [##myxml]
                            CROSS APPLY actual_xml.nodes('/*') AS A ( B )
                            CROSS APPLY actual_xml.nodes('//*') AS X ( N )
                ) T
        WHERE   NodeName = 'value'

--select * from ##ParsedData
DECLARE @SQL AS VARCHAR(MAX)

DECLARE @TableColumns AS VARCHAR(MAX)
DECLARE @Columns AS VARCHAR(MAX)

SELECT  
	@TableColumns = COALESCE(@TableColumns + ' varchar(1024),', '') + QUOTENAME(ParsedName),
	@Columns = COALESCE(@Columns + ',', '') + QUOTENAME(ParsedName)

FROM    ( SELECT DISTINCT
                    ParsedName
          FROM      ##ParsedData
	          WHERE     ParsedName <> 'tsql_stack'
        ) AS B
-- ORDER BY B.ParsedName

Set @TableColumns += ' varchar(1024)'
--print @tablecolumns
--print @columns

SET @SQL = '
IF OBJECT_ID(''dbsadmin..finalresults'') IS NOT NULL
    DROP TABLE dbsadmin..finalresults
create table dbsadmin..finalresults
	(actual_time datetime,
	eventtype varchar(255),
	'+ @TableColumns + ')

insert into dbsadmin..finalresults
SELECT Actual_Time, EventType,' + @Columns + ' FROM
(
SELECT id, EventType, Actual_Time, ParsedName, NodeValue FROM
##ParsedData ) AS source
PIVOT
(max(NodeValue) FOR source.ParsedName IN (' + @columns + ')
)AS pvt order by actual_time, id'

--EXEC (@sql) 
print @sql

--select top 10 * from dbsadmin..finalresults

