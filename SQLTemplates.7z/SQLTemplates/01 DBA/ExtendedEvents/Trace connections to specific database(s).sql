DECLARE @destination_directory varchar(256) = 'l:\Microsoft SQL Server\MSSQL11.MSSQLSERVER\MSSQL\trace'

CREATE EVENT SESSION [AuditDatabaseUsage] ON SERVER 
ADD EVENT sqlserver.lock_acquired(
    ACTION(sqlserver.client_app_name,sqlserver.client_hostname,sqlserver.database_id,sqlserver.nt_username,sqlserver.session_nt_username,sqlserver.sql_text,sqlserver.username)
    WHERE (([sqlserver].[like_i_sql_unicode_string]([sqlserver].[database_name],N'ProvidentHomeCreditCMS%') 
			or [sqlserver].[like_i_sql_unicode_string]([sqlserver].[database_name],N'ProvidentROI_Live%'))
) AND [sqlserver].[not_equal_i_sql_unicode_string]([sqlserver].[client_app_name],N'Spotlight Diagnostic Server (Monitoring)')))
ADD TARGET package0.event_file(SET filename=N''+@destination_directory+'''\AuditDatabaseUsage.xel',max_file_size=(100),max_rollover_files=(10))
WITH (MAX_MEMORY=4096 KB,EVENT_RETENTION_MODE=ALLOW_SINGLE_EVENT_LOSS,MAX_DISPATCH_LATENCY=30 SECONDS,MAX_EVENT_SIZE=0 KB,MEMORY_PARTITION_MODE=NONE,TRACK_CAUSALITY=OFF,STARTUP_STATE=ON)
GO


