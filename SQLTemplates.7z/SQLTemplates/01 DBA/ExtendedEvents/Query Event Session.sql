DECLARE @SessionName VARCHAR(200)
SET @SessionName = 'AllQueries'

-------------------------------------------------------------------------------
--memory ring events

DECLARE @XMLLongRunning XML
SELECT  @XMLLongRunning = CAST(dt.target_data AS XML)
FROM    sys.dm_xe_session_targets dt
        JOIN sys.dm_xe_sessions ds ON ds.Address = dt.event_session_address
        JOIN sys.server_event_sessions ss ON ds.Name = ss.Name
WHERE   dt.target_name = 'ring_buffer'
        AND ds.Name = 'LongRunningQuery'
 
SELECT  T.N.value('local-name(.)', 'varchar(max)') AS Name
      , T.N.value('.', 'varchar(max)') AS Value
FROM    @XMLLongRunning.nodes('/*/@*') AS T ( N )



-------------------------------------------------------------------------------
--file stored events
--pull into temp table for speed and to make sure the ID works right
IF OBJECT_ID('tempdb..#myxml') IS NOT NULL
    DROP TABLE #myxml
CREATE TABLE #myxml
    (
      id INT IDENTITY
    , actual_xml XML
    )
INSERT  INTO #myxml
        SELECT  CAST(event_data AS XML)
        FROM    sys.fn_xe_file_target_read_file('c:\sql_log\LongRunningQuery*.xet',
                                                'c:\sql_log\LongRunningQuery*.xem',
                                                NULL, NULL)
 
 
--Now toss into temp table, generically shredded
IF OBJECT_ID('tempdb..#ParsedData') IS NOT NULL
    DROP TABLE #ParsedData
CREATE TABLE #ParsedData
    (
      id INT
    , Actual_Time DATETIME
    , EventType sysname
    , ParsedName sysname
    , NodeValue VARCHAR(MAX)
    )
INSERT  INTO #ParsedData --(id, ParsedName, NodeValue)
--doing the DATEADD because @timestamp is stored with timezone detail, if not on UTC off by HOURS.
        SELECT  id
              , DATEADD(MINUTE, DATEPART(TZoffset, SYSDATETIMEOFFSET()),
                        UTC_Time) AS Actual_Time
              , EventType
              , ParsedName
              , NodeValue
        FROM    ( SELECT    id
                          , A.B.value('@name[1]', 'varchar(128)') AS EventType
                          , A.B.value('./@timestamp[1]', 'datetime') AS UTC_Time
                          , X.N.value('local-name(.)', 'varchar(128)') AS NodeName
                          , X.N.value('../@name[1]', 'varchar(128)') AS ParsedName
                          , X.N.value('./text()[1]', 'varchar(max)') AS NodeValue
                  FROM      [#myxml]
                            CROSS APPLY actual_xml.nodes('/*') AS A ( B )
                            CROSS APPLY actual_xml.nodes('//*') AS X ( N )
                ) T
        WHERE   NodeName = 'value'
--could also use "X.N.value(''./text()[1]'', ''varchar(max)'') is not null" inside
 
--And now use the standard dynamic pivot to shred.
-- Because of the way the pivot works, the fields are alphabetical; not a big deal, but fixable
DECLARE @SQL AS VARCHAR(MAX)
DECLARE @Columns AS VARCHAR(MAX)
SELECT  @Columns = COALESCE(@Columns + ',', '') + QUOTENAME(ParsedName)
FROM    ( SELECT DISTINCT
                    ParsedName
          FROM      #ParsedData
		 --excluded it here, but the tsql_stack can be used to get the exact statement from the plan cache
--see http://blogs.msdn.com/b/extended_events/archive/2010/05/07/making-a-statement-how-to-retrieve-the-t-sql-statement-that-caused-an-event.aspx
          WHERE     ParsedName <> 'tsql_stack'
        ) AS B
-- ORDER BY B.ParsedName
SET @SQL = '
SELECT Actual_Time, EventType,' + @Columns + ' FROM
(
SELECT id, EventType, Actual_Time, ParsedName, NodeValue FROM
#ParsedData ) AS source
PIVOT
(max(NodeValue) FOR source.ParsedName IN (' + @columns + ')
)AS pvt order by actual_time, attach_activity_id'
EXEC (@sql) 