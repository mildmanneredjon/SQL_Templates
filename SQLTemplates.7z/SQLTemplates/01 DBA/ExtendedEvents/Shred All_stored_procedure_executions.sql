/*
Copy the trace file on to a test environment.

Set the value of the trace file and execute.

Once it completes run "Get stats on Stored procedure executions" to analyse the results.

Please be aware that this can take a long time to run, so copy the .xel file to a development server before running

One 100mb file will take approximately 20 minutes to process.

Ensure that you run this on a non-prod environment by copying the xel file from the prod server.

If you are shredding more than one file then you will need to adjust the last bit to just do an insert (not drop and create the table)
*/

/*Load the xel file into ##myxml*/
set nocount on
use dbsadmin
IF OBJECT_ID('tempdb..##myxml') IS NOT NULL
    DROP table ##myxml
CREATE TABLE ##myxml
    (
      id INT IDENTITY primary key clustered
    , actual_xml XML
    )

INSERT  INTO ##myxml
        SELECT CAST(event_data AS XML)
        FROM    sys.fn_xe_file_target_read_file('l:\mssql\trace\all_stored_procedure_executions_0_131659414146150000.xel', null, null, null)

CREATE primary XML INDEX idx_xCol on ##myxml (actual_xml)  

/*Parse the xml and write the results to ##ParsedData*/
IF OBJECT_ID('tempdb..##ParsedData') IS NOT NULL
    DROP TABLE ##ParsedData

CREATE TABLE ##ParsedData
    (
      id INT identity primary key clustered
    , Actual_Time DATETIME
    , EventType sysname
    , ParsedName sysname
    , NodeValue VARCHAR(8000)
    )

INSERT  INTO ##ParsedData 

        SELECT DATEADD(MINUTE, DATEPART(TZoffset, SYSDATETIMEOFFSET()),
                        UTC_Time) AS Actual_Time
              , EventType
              , ParsedName
              , NodeValue
        FROM    ( SELECT    id
                          , A.B.value('@name[1]', 'varchar(128)') AS EventType
                          , A.B.value('./@timestamp[1]', 'datetime') AS UTC_Time
                          , X.N.value('local-name(.)', 'varchar(128)') AS NodeName
                          , X.N.value('../@name[1]', 'varchar(128)') AS ParsedName
                          , X.N.value('./text()[1]', 'varchar(max)') AS NodeValue
                  FROM      [##myxml]
                            CROSS APPLY actual_xml.nodes('/*') AS A ( B )
                            CROSS APPLY actual_xml.nodes('//*') AS X ( N )
                ) T
        WHERE   NodeName = 'value'

create index ix_ParsedName_incNodeValue on ##parseddata (parsedname) include (nodevalue)

/*Pivot the results to display in a table format and load them into dbsadmin..tbl_storedproc_usage
If you want to keep the result set replace tbl_storedproc_usage with a table name of your choice*/
IF OBJECT_ID('dbsadmin..tbl_storedproc_usage') IS NOT NULL
    DROP TABLE dbsadmin..tbl_storedproc_usage
create table dbsadmin..tbl_storedproc_usage
	(actual_time datetime,
	[query_plan_hash] varchar(24),[cpu_time] int,[object_name] varchar(128),[database_name] varchar(128),[duration] int,[query_hash] varchar(24),[logical_reads] int,[writes] int)

insert into dbsadmin..tbl_storedproc_usage
SELECT Actual_Time, [query_plan_hash],[cpu_time],[object_name],[database_name],[duration],[query_hash],[logical_reads],[writes] 
FROM
(
SELECT id,Actual_Time, ParsedName, NodeValue FROM
##ParsedData ) AS source
PIVOT
(max(NodeValue) FOR source.ParsedName IN ([query_plan_hash],[cpu_time],[object_name],[database_name],[duration],[query_hash],[logical_reads],[writes])
)AS pvt order by actual_time, id

/*Clean up afterwards*/
IF OBJECT_ID('tempdb..##myxml') IS NOT NULL
BEGIN
    DROP TABLE ##myxml
END

IF OBJECT_ID('tempdb..##ParsedData') IS NOT NULL
BEGIN
    DROP TABLE ##ParsedData
END