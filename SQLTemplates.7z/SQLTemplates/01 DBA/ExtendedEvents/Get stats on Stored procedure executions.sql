/*
This query analyses the results of the "All_stored_procedure_executions" extended events trace

Before running this you need to run "Shred All_stored_procedure_executions"

Ensure you are in the context of the database you are analysing.

Threshold values still to be decided.
*/

select 
	database_name,
	object_name,
	min(actual_time) as first_run, 
	max(actual_time) as last_run,
	count(1) as num_of_executions,
	sum(duration)/(count(1)*1000) as avg_duration_in_millisecs,
	sum(cpu_time)/(count(1)*1000) as avg_cpu_time_in_millisecs,
	sum(logical_reads)/count(1) as avg_logical_reads,
	sum(writes)/count(1) as avg_writes
from dbsadmin..tbl_storedproc_usage
group by database_name,object_name
order by num_of_executions desc
