/*
Other stuff to check for

ssisdb - retention
tempdb - correct drive
tempdb - correct number of files
tempdb - correctly sized files
ssisdb - master key backed up
backup encryption - created, stored in password safe and backed up?
backup jobs setup
database integrity checks setup
index maintenance job setup
cycle error log setup
number of error logs to keep set to max
*/

/*2014 setup checks - run from a remote server*/
set nocount on

DECLARE @ResultsTable table (Information varchar(max),Correction_Query varchar(max))

/*Check the SA account is disabled*/
if exists (select 1 from sys.server_principals where name = 'sa' and is_disabled = 0)
begin
insert into @ResultsTable
select 'SA account is not disabled','ALTER LOGIN [sa] DISABLE'
end

/*Check MSA account is setup for db engine on sql server agent*/

DECLARE       @DBEngineLogin       VARCHAR(100)
DECLARE       @AgentLogin          VARCHAR(100)

EXECUTE       master.dbo.xp_instance_regread
              @rootkey      = N'HKEY_LOCAL_MACHINE',
              @key          = N'SYSTEM\CurrentControlSet\Services\MSSQLServer',
              @value_name   = N'ObjectName',
              @value        = @DBEngineLogin OUTPUT
 
EXECUTE       master.dbo.xp_instance_regread
              @rootkey      = N'HKEY_LOCAL_MACHINE',
              @key          = N'SYSTEM\CurrentControlSet\Services\SQLServerAgent',
              @value_name   = N'ObjectName',
              @value        = @AgentLogin OUTPUT

if @DBEngineLogin not like '%$'
begin
insert into @ResultsTable
select 'MSA account not setup for DB Engine, raise SR with Wintel for this to be created',''
end

if @AgentLogin not like '%$'
begin
insert into @ResultsTable
select 'MSA account not setup for SQL Server Agent, raise SR with Wintel for this to be created',''
end

/*Check SPN is setup*/

if exists (SELECT 1 FROM sys.dm_exec_connections  WHERE session_id = @@spid and auth_scheme = 'ntlm')
begin
insert into @ResultsTable
select 'No kerberos connection, please investigate if SPN is setup and raise with Wintel',''
end

/*Check backup checksum is the default setting*/

if exists (SELECT 1 FROM [sys].[configurations] WHERE name = 'backup checksum default' and value = 0)
begin
insert into @ResultsTable
select 'Backup checksum not switched on by default','EXEC sp_configure ''backup checksum default'', 1; RECONFIGURE WITH OVERRIDE;'
end

/*Check backup compression is switched on by default*/

if exists (SELECT 1 FROM [sys].[configurations] WHERE name = 'backup compression default' and value = 0)
begin
insert into @ResultsTable
select 'Backup compression not switched on by default','EXEC sp_configure ''backup compression default'', 1; RECONFIGURE WITH OVERRIDE;'
end

/*Check DBS_Maintenance database is setup*/

if not exists (select 1 from sys.databases where name = 'dbs_maintenance')
begin
insert into @ResultsTable
select 'DBS_Maintenance database not setup. Please setup from a 2014 backup',''
end

/*Check authentication mode is set to Windows Authentication mode and not mixed*/
DECLARE @AuthenticationMode INT  
EXEC master.dbo.xp_instance_regread N'HKEY_LOCAL_MACHINE', 
N'Software\Microsoft\MSSQLServer\MSSQLServer',   
N'LoginMode', @AuthenticationMode OUTPUT  

if @AuthenticationMode = 2
begin
insert into @ResultsTable
select 'Mixed mode authentication enabled, change to Windows only then restart the SQL Server service','EXEC xp_instance_regwrite N''HKEY_LOCAL_MACHINE'', N''Software\Microsoft\MSSQLServer\MSSQLServer'', N''LoginMode'', REG_DWORD, 1'
end

/*Display memory of the OS and the amount used by SQL to ensure it is set appropriately*/

declare @OS_Memory decimal(8,2)
declare @SQL_Max_Memory decimal(8,2)

select @OS_Memory = total_physical_memory_kb/1024
from sys.dm_os_sys_memory

select @SQL_Max_Memory = cast(value as decimal(8,2))
from sys.configurations 
where name = 'max server memory (MB)'

insert into @ResultsTable
select 'SQL Server currently set to use '+cast(@SQL_Max_Memory as varchar(9))+'mb of '+cast(@OS_Memory as varchar(9))+'mb. Please set this accordingly based on what else is installed on the server.',''

/*Check MAXDOP setting and number of CPUs configured*/
declare @NumOfCPUsOnServer int
declare @MAXDopSetting int

select @NumOfCPUsOnServer = cpu_count
FROM sys.dm_os_sys_info
select @MAXDopSetting = cast(value as int)
from sys.configurations
where name = 'max degree of parallelism'

insert into @ResultsTable
select 'SQL Server currently set to maxdop of '+cast(@MaxDopSetting as varchar(2))+'. The server has '+cast(@NumOfCPUsOnServer as varchar(2))+' CPUs.','https://support.microsoft.com/en-us/help/2806535/recommendations-and-guidelines-for-the-max-degree-of-parallelism-confi'

/*Check if cost threshold for parallelism is set to 50*/
if exists (select 1 from sys.configurations where name = 'cost threshold for parallelism' and value <> 50)
begin
insert into @ResultsTable
select 'Cost threshold for parallelism set to to '+cast(value as varchar(4))+'. This should be 50.','EXEC sys.sp_configure N''show advanced options'', N''1''  RECONFIGURE WITH OVERRIDE
GO
EXEC sys.sp_configure N''cost threshold for parallelism'', N''50''
GO
RECONFIGURE WITH OVERRIDE
GO
EXEC sys.sp_configure N''show advanced options'', N''0''  RECONFIGURE WITH OVERRIDE
GO'
from sys.configurations
where name = 'cost threshold for parallelism'
end

/*Check default language is set to English*/
if exists (select 1 from sys.configurations where name = 'default language' and value <> 0)
BEGIN
insert into @ResultsTable
select 'Default language not set to English', 'exec sp_configure ''default language'', 0; go reconfigure ; go'
END

/*Check DAC Connection is enabled*/
IF EXISTS (select 1 from sys.configurations where name = 'remote admin connections' and value <> 1)
Begin 
Insert into @ResultsTable
Select 'Remote Admin Connection set to '+cast(value as varchar(4))+'. This should be set to 1',
'EXEC sp_configure ''remote admin connections'', 1 
GO
RECONFIGURE
GO'
from sys.configurations
where name = 'remote admin connections'
End

select * from @ResultsTable