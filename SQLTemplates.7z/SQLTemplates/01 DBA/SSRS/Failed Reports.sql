use reportserver 
go   

select * 
from executionLog el 
	inner join catalog c 
		on c.itemID=el.reportID   
where status !='rsSuccess'
order by timestart desc 
--and el.timestart between dateadd(d,-2,getdate()) and getdate() 
--group by day(el.timestart),month(el.timestart) 
--order by month(el.timestart) desc, day(el.timestart)desc

