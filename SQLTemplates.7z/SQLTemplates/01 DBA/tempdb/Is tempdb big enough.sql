/*Query to find any errors relating to tempdb size*/

declare @numoflogs int = 6 --set this to the number of logs you want to look through

declare @logid int = 0

IF OBJECT_ID('tempdb..#ErrorLog') IS Not Null
 BEGIN
 DROP TABLE #ErrorLog
 END

CREATE TABLE #ErrorLog (Id int IDENTITY (1, 1) NOT NULL, 
logdate DATETIME, procInfo VARCHAR(10), ERRORLOG VARCHAR(MAX))

set @logid = 0

while @logid <= @numoflogs - 1
begin
insert into #ErrorLog
exec sp_readerrorlog  @logid

set @logid += 1
end;
with cte
as
(
select 
id,
	logdate,
	procInfo,
	errorlog as [error code],
	LEAD(errorlog,1) OVER (ORDER BY ID) as [error message]
from #ErrorLog
)
select * from cte
where [error code] like '%error: 9002%'
or [error code] like '%error: 3967%'
or [error code] like '%error: 3958%'
or [error code] like '%error:3966%'
or [error code] like '%error:1105%'
order by logdate desc

/*Display the current amount of free space in all files combined*/
use tempdb
SELECT SUM(unallocated_extent_page_count) AS [free pages], 
(SUM(unallocated_extent_page_count)*1.0/128) AS [free space in MB]
FROM sys.dm_db_file_space_usage;

