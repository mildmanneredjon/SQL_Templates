 
 /**
*-----------------------------------------------------------------------------*
|							Standard Support Script	                          |
|                                                                             |
|         Version 1         Dale Stewart             13/11/2014               |
|                                                                             |
*-----------------------------------------------------------------------------*

COMPATIBLITY
------------
2008 upwards

*-----------------------------------------------------------------------------*
BACKGROUND
----------


*-----------------------------------------------------------------------------*
USAGE
-----

*-----------------------------------------------------------------------------*
VERSION 1
---------

*-----------------------------------------------------------------------------*
REFERENCES
----------

*-----------------------------------------------------------------------------*
PARAMETERS
----------


*-----------------------------------------------------------------------------*
DEPENDENCIES
----------

**/

-------------------------------------------------------------------------------
:setvar checkSQLCMD "checkSQLCMD" 
GO 
IF ('$(checkSQLCMD)' = '$' + '(checkSQLCMD)') RAISERROR ('This script must be run in SQLCMD mode.', 20, 1) WITH LOG 
GO 
SELECT 'This part executes only in SQLCMD mode!'

-------------------------------------------------------------------------------
:setvar ServerName "RSSODIE\IRMA,3340"
:setvar DatabaseName "MI_Report_Access"
:setvar CR "5521"

:connect $(ServerName)
USE $(DatabaseName)

------------------------------------------------------------------------------- 
------------------------------------------------------------------------------
go
ALTER PROCEDURE [dbo].[usp_Merge_ReportSecurity]
AS
BEGIN TRY
SET NOCOUNT ON;
SET XACT_ABORT ON;

/*This procedure handles complete report refreshes on the destination server. All records for the report
  are removed from User_Access_Level and new records inserted. */

DELETE  dbo.User_Access_Level
WHERE	ReportID IN(SELECT DISTINCT ReportID FROM Landing_Security.ReportSecurity)

INSERT	dbo.User_Access_Level
SELECT	a.sys_user,
		a.ReportID,
		a.Access_Level,
		a.Division,
		a.Region,
		a.Area,
		a.Section,
		a.iPadStatusID,
		a.RAM_ID
FROM	Landing_Security.ReportSecurity a
LEFT JOIN
		dbo.User_Access_Level b
ON		a.RAM_ID = b.RAM_ID
WHERE	b.RAM_ID IS NULL

END TRY
BEGIN CATCH
EXEC usp_RethrowError @@Procid;
END Catch

		BEGIN
			RAISERROR ('Row count mismatch', 19, 1);
		END;