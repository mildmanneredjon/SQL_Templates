
use master
go
sp_configure 'show advanced options',1
go
reconfigure with override
go
sp_configure 'Database Mail XPs',1
--go
--sp_configure 'SQL Mail XPs',0
go
reconfigure
go

--#################################################################################################
-- BEGIN Mail Settings DBS
--#################################################################################################
IF NOT EXISTS(SELECT * FROM msdb.dbo.sysmail_profile WHERE  name = 'DBS') 
  BEGIN
    --CREATE Profile [DBS]
    EXECUTE msdb.dbo.sysmail_add_profile_sp
      @profile_name = 'DBS',
      @description  = '';
  END --IF EXISTS profile
  
  IF NOT EXISTS(SELECT * FROM msdb.dbo.sysmail_account WHERE  name = 'DBS')
  BEGIN
    --CREATE Account [DBS]
    EXECUTE msdb.dbo.sysmail_add_account_sp
    @account_name            = 'DBS',
    @email_address           = 'DBSAlerts@Provident.co.uk',
    @display_name            = 'DBS Alerts',
    @replyto_address         =  NULL ,
    @description             =  NULL ,
    @mailserver_name         = 'mailhost.ho.pfgroup.provfin.com',
    @mailserver_type         = 'SMTP',
    @port                    = '25',
    @username                =  NULL ,
    @password                =  NULL , 
    @use_default_credentials =  0 ,
    @enable_ssl              =  0 ;
  END --IF EXISTS  account
  
IF NOT EXISTS(SELECT *
              FROM msdb.dbo.sysmail_profileaccount pa
                INNER JOIN msdb.dbo.sysmail_profile p ON pa.profile_id = p.profile_id
                INNER JOIN msdb.dbo.sysmail_account a ON pa.account_id = a.account_id  
              WHERE p.name = 'DBS'
                AND a.name = 'DBS') 
  BEGIN
    -- Associate Account [DBS] to Profile [DBS]
    EXECUTE msdb.dbo.sysmail_add_profileaccount_sp
      @profile_name = 'DBS',
      @account_name = 'DBS',
      @sequence_number = 1 ;
  END --IF EXISTS associate accounts to profiles
--#################################################################################################
-- Drop Settings For DBS
--#################################################################################################
/*
IF EXISTS(SELECT *
            FROM msdb.dbo.sysmail_profileaccount pa
              INNER JOIN msdb.dbo.sysmail_profile p ON pa.profile_id = p.profile_id
              INNER JOIN msdb.dbo.sysmail_account a ON pa.account_id = a.account_id  
            WHERE p.name = 'DBS'
              AND a.name = 'DBS')
  BEGIN
    EXECUTE msdb.dbo.sysmail_delete_profileaccount_sp @profile_name = 'DBS',@account_name = 'DBS'
  END 
IF EXISTS(SELECT * FROM msdb.dbo.sysmail_account WHERE  name = 'DBS')
  BEGIN
    EXECUTE msdb.dbo.sysmail_delete_account_sp @account_name = 'DBS'
  END
IF EXISTS(SELECT * FROM msdb.dbo.sysmail_profile WHERE  name = 'DBS') 
  BEGIN
    EXECUTE msdb.dbo.sysmail_delete_profile_sp @profile_name = 'DBS'
  END
*/
  
--#################################################################################################
-- BEGIN Mail Settings BI
--#################################################################################################
IF NOT EXISTS(SELECT * FROM msdb.dbo.sysmail_profile WHERE  name = 'BI') 
  BEGIN
    --CREATE Profile [BI]
    EXECUTE msdb.dbo.sysmail_add_profile_sp
      @profile_name = 'BI',
      @description  = '';
  END --IF EXISTS profile
  
  IF NOT EXISTS(SELECT * FROM msdb.dbo.sysmail_account WHERE  name = 'BI')
  BEGIN
    --CREATE Account [BI]
    EXECUTE msdb.dbo.sysmail_add_account_sp
    @account_name            = 'BI',
    @email_address           = 'DataStrategy@provident.co.uk',
    @display_name            = 'Data Strategy',
    @replyto_address         = '',
    @description             = '',
    @mailserver_name         = 'mailhost.ho.pfgroup.provfin.com',
    @mailserver_type         = 'SMTP',
    @port                    = '25',
    @username                =  NULL ,
    @password                =  NULL , 
    @use_default_credentials =  1 ,
    @enable_ssl              =  0 ;
  END --IF EXISTS  account
  
IF NOT EXISTS(SELECT *
              FROM msdb.dbo.sysmail_profileaccount pa
                INNER JOIN msdb.dbo.sysmail_profile p ON pa.profile_id = p.profile_id
                INNER JOIN msdb.dbo.sysmail_account a ON pa.account_id = a.account_id  
              WHERE p.name = 'BI'
                AND a.name = 'BI') 
  BEGIN
    -- Associate Account [BI] to Profile [BI]
    EXECUTE msdb.dbo.sysmail_add_profileaccount_sp
      @profile_name = 'BI',
      @account_name = 'BI',
      @sequence_number = 1 ;
  END --IF EXISTS associate accounts to profiles
--#################################################################################################
-- Drop Settings For BI
--#################################################################################################
/*
IF EXISTS(SELECT *
            FROM msdb.dbo.sysmail_profileaccount pa
              INNER JOIN msdb.dbo.sysmail_profile p ON pa.profile_id = p.profile_id
              INNER JOIN msdb.dbo.sysmail_account a ON pa.account_id = a.account_id  
            WHERE p.name = 'BI'
              AND a.name = 'BI')
  BEGIN
    EXECUTE msdb.dbo.sysmail_delete_profileaccount_sp @profile_name = 'BI',@account_name = 'BI'
  END 
IF EXISTS(SELECT * FROM msdb.dbo.sysmail_account WHERE  name = 'BI')
  BEGIN
    EXECUTE msdb.dbo.sysmail_delete_account_sp @account_name = 'BI'
  END
IF EXISTS(SELECT * FROM msdb.dbo.sysmail_profile WHERE  name = 'BI') 
  BEGIN
    EXECUTE msdb.dbo.sysmail_delete_profile_sp @profile_name = 'BI'
  END
*/
  