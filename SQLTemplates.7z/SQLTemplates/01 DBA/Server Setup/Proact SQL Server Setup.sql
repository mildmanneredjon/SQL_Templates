/****** Object:  Login [PFG-PROACT\Glo_Live]    Script Date: 06/22/2015 15:35:13 ******/
CREATE LOGIN [PFG-PROACT\Glo_Live] FROM WINDOWS WITH DEFAULT_DATABASE=[master], DEFAULT_LANGUAGE=[us_english]
GO
/****** Object:  Login [PFG-PROACT\HCWM_Live]    Script Date: 06/22/2015 15:35:17 ******/
CREATE LOGIN [PFG-PROACT\HCWM_Live] FROM WINDOWS WITH DEFAULT_DATABASE=[HomeCreditWebsiteMobile_LIVE], DEFAULT_LANGUAGE=[us_english]
GO
/****** Object:  Login [PFG-PROACT\HCWM_Staging]    Script Date: 06/22/2015 15:35:22 ******/
CREATE LOGIN [PFG-PROACT\HCWM_Staging] FROM WINDOWS WITH DEFAULT_DATABASE=[HomeCreditWebsiteMobile_STAGING], DEFAULT_LANGUAGE=[us_english]
GO
/****** Object:  Login [PFG-PROACT\ProvidentGPC_Live]    Script Date: 06/22/2015 15:36:01 ******/
CREATE LOGIN [PFG-PROACT\ProvidentGPC_Live] FROM WINDOWS WITH DEFAULT_DATABASE=[ProvidentGPC_LIVE], DEFAULT_LANGUAGE=[us_english]
GO
/****** Object:  Login [PFG-PROACT\ProvidentGPC_Staging]    Script Date: 06/22/2015 15:36:05 ******/
CREATE LOGIN [PFG-PROACT\ProvidentGPC_Staging] FROM WINDOWS WITH DEFAULT_DATABASE=[ProvidentGPC_STAGING], DEFAULT_LANGUAGE=[us_english]
GO
/****** Object:  Login [PFG-PROACT\ProvidentPPC_Live]    Script Date: 06/22/2015 15:36:10 ******/
CREATE LOGIN [PFG-PROACT\ProvidentPPC_Live] FROM WINDOWS WITH DEFAULT_DATABASE=[ProvidentPPC_LIVE], DEFAULT_LANGUAGE=[us_english]
GO
/****** Object:  Login [PFG-PROACT\ProvidentPPC_Staging]    Script Date: 06/22/2015 15:36:38 ******/
CREATE LOGIN [PFG-PROACT\ProvidentPPC_Staging] FROM WINDOWS WITH DEFAULT_DATABASE=[ProvidentPPC_STAGING], DEFAULT_LANGUAGE=[us_english]
GO
/****** Object:  Login [PFG-PROACT\ProvidentROI_Live]    Script Date: 06/22/2015 15:36:43 ******/
CREATE LOGIN [PFG-PROACT\ProvidentROI_Live] FROM WINDOWS WITH DEFAULT_DATABASE=[ProvidentROI_LIVE], DEFAULT_LANGUAGE=[us_english]
GO
/****** Object:  Login [PFG-PROACT\ProvidentROI_Staging]    Script Date: 06/22/2015 15:36:48 ******/
CREATE LOGIN [PFG-PROACT\ProvidentROI_Staging] FROM WINDOWS WITH DEFAULT_DATABASE=[ProvidentROI_STAGING], DEFAULT_LANGUAGE=[us_english]
GO
/****** Object:  Login [PFG-PROACT\SatsumaLoans_live]    Script Date: 06/22/2015 15:36:52 ******/
CREATE LOGIN [PFG-PROACT\SatsumaLoans_live] FROM WINDOWS WITH DEFAULT_DATABASE=[master], DEFAULT_LANGUAGE=[us_english]
GO
/****** Object:  Login [PFG-PROACT\SatsumaLoans_Staging]    Script Date: 06/22/2015 15:36:57 ******/
CREATE LOGIN [PFG-PROACT\SatsumaLoans_Staging] FROM WINDOWS WITH DEFAULT_DATABASE=[master], DEFAULT_LANGUAGE=[us_english]
GO
/****** Object:  Login [PFG-PROACT\SVC_UmbWeb_Live]    Script Date: 06/22/2015 15:37:01 ******/
CREATE LOGIN [PFG-PROACT\SVC_UmbWeb_Live] FROM WINDOWS WITH DEFAULT_DATABASE=[master], DEFAULT_LANGUAGE=[us_english]
GO
/****** Object:  Login [PFG-PROACT\SVC_UmbWeb_Stage]    Script Date: 06/22/2015 15:37:06 ******/
CREATE LOGIN [PFG-PROACT\SVC_UmbWeb_Stage] FROM WINDOWS WITH DEFAULT_DATABASE=[master], DEFAULT_LANGUAGE=[us_english]
GO
/****** Object:  Login [PFG-PROACT\ggITOperationsDelivery]    Script Date: 22/06/2015 15:44:46 ******/
CREATE LOGIN [PFG-PROACT\ggITOperationsDelivery] FROM WINDOWS WITH DEFAULT_DATABASE=[master], DEFAULT_LANGUAGE=[us_english]
GO

ALTER SERVER ROLE [sysadmin] ADD MEMBER [PFG-PROACT\ggITOperationsDelivery]
GO

EXEC sys.sp_configure N'show advanced options', N'1'  RECONFIGURE WITH OVERRIDE
GO
EXEC sys.sp_configure N'max server memory (MB)', N'2048'
GO
RECONFIGURE WITH OVERRIDE
GO
EXEC sys.sp_configure N'show advanced options', N'0'  RECONFIGURE WITH OVERRIDE
GO
EXEC sys.sp_configure N'show advanced options', N'1'  RECONFIGURE WITH OVERRIDE
GO
EXEC sys.sp_configure N'cost threshold for parallelism', N'25'
GO
EXEC sys.sp_configure N'max degree of parallelism', N'4'
GO
RECONFIGURE WITH OVERRIDE
GO
EXEC sys.sp_configure N'show advanced options', N'0'  RECONFIGURE WITH OVERRIDE
GO


USE [msdb]
GO

/****** Object:  Job [Backup Provident Databases]    Script Date: 06/22/2015 15:46:58 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]]    Script Date: 06/22/2015 15:46:58 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'Backup Provident Databases', 
		@enabled=0, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'sa', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Backup Provident Databases]    Script Date: 06/22/2015 15:46:58 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Backup Provident Databases', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'USE  MASTER
GO

DECLARE @TABLE1 TABLE (id int IDENTITY(1,1),dbname VARCHAR(MAX))
DECLARE @dbname VARCHAR(MAX)
DECLARE @NOW CHAR(13) = (SELECT CONVERT(CHAR(2),DATEPART(dd,GETDATE())) + CONVERT(CHAR(2),DATEPART(mm,GETDATE())) + CONVERT(CHAR(4),DATEPART(yy,GETDATE())) + ''_''+ CONVERT(CHAR(2),DATEPART(hh,GETDATE()))+CONVERT(CHAR(2),DATEPART(mi,GETDATE())))

INSERT INTO @TABLE1 (dbname)
SELECT name FROM master.dbo.sysdatabases where dbid > 4

DECLARE @item_counter INT
DECLARE @loop_counter INT

SET @loop_counter = (SELECT COUNT(1) FROM @TABLE1)
SET @item_counter = 1

WHILE @loop_counter > 0 AND @item_counter <= @loop_counter
	BEGIN
	
	SELECT 
		@dbname = dbname
	FROM @TABLE1
	WHERE id = @item_counter

	EXECUTE (N''BACKUP DATABASE ['' + @dbname + ''] TO
			DISK = N''''U:\Backup\'' +@dbname + ''_''+@NOW+''.bak'''' WITH
			NOFORMAT, 
			NOINIT ,
			NAME = '''''' + @dbname + '' Database Backup'''' ,
			SKIP, 
			NOREWIND, 
			NOUNLOAD ,
			COMPRESSION,  
			STATS = 10, 
			CHECKSUM,
			DESCRIPTION = N''''Backup of DBYPFGPROSQLVIP '' + @dbname + ''''''
			'')
	  
       SET @item_counter = @item_counter + 1
END
', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Delete Backups over 7 days]    Script Date: 06/22/2015 15:46:58 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Delete Backups over 7 days', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'DECLARE @DeleteDateTime DATETIME =  DATEADD(dd, -7, GETDATE())
DECLARE @DeleteDate NVARCHAR(50) = (SELECT REPLACE(CONVERT(NVARCHAR, @DeleteDateTime, 111), ''/'', ''-'') + ''T'' + CONVERT(NVARCHAR, @DeleteDateTime, 108))

EXECUTE master.dbo.xp_delete_file 0,N''U:\Backup'',N''bak'',@DeleteDate,1', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Copy Backups to DR]    Script Date: 06/22/2015 15:46:58 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Copy Backups to DR', 
		@step_id=3, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'DECLARE @ROBO VARCHAR(100) = ''ROBOCOPY U:\Backup \\CHFPFGSECSQL001\RemoteBackups *.bak /MIR /W:5 /R:2 /IPG:0''

EXECUTE master.dbo.xp_cmdshell @ROBO', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Backup Schedule', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20121023, 
		@active_end_date=99991231, 
		@active_start_time=10000, 
		@active_end_time=235959
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO


USE [msdb]
GO

/****** Object:  Job [ASPState_Job_DeleteExpiredSessions]    Script Date: 06/22/2015 15:48:28 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]]    Script Date: 06/22/2015 15:48:28 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'ASPState_Job_DeleteExpiredSessions', 
		@enabled=0, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'Deletes expired sessions from the session state database.', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'PFG-PROACT\hayness', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [ASPState_JobStep_DeleteExpiredSessions]    Script Date: 06/22/2015 15:48:28 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'ASPState_JobStep_DeleteExpiredSessions', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=1, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'EXECUTE DeleteExpiredSessions', 
		@database_name=N'ASPState', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'ASPState_JobSchedule_DeleteExpiredSessions', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=4, 
		@freq_subday_interval=1, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20001016, 
		@active_end_date=99991231, 
		@active_start_time=0, 
		@active_end_time=235959
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO


USE [msdb]
GO

/****** Object:  Job [GloASPState_Job_DeleteExpiredSessions]    Script Date: 06/22/2015 15:49:20 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]]    Script Date: 06/22/2015 15:49:20 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'GloASPState_Job_DeleteExpiredSessions', 
		@enabled=0, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'Deletes expired sessions from the session state database.', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'PFG-PROACT\hakima', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [GloASPState_JobStep_DeleteExpiredSessions]    Script Date: 06/22/2015 15:49:20 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'GloASPState_JobStep_DeleteExpiredSessions', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=1, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'EXECUTE DeleteExpiredSessions', 
		@database_name=N'GloASPState', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'GloASPState_JobSchedule_DeleteExpiredSessions', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=4, 
		@freq_subday_interval=1, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20001016, 
		@active_end_date=99991231, 
		@active_start_time=0, 
		@active_end_time=235959
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

USE [msdb]
GO

/****** Object:  Job [SatsumaLIVEASPState_Job_DeleteExpiredSessions]    Script Date: 06/22/2015 15:49:43 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]]    Script Date: 06/22/2015 15:49:43 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'SatsumaLIVEASPState_Job_DeleteExpiredSessions', 
		@enabled=0, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'Deletes expired sessions from the session state database.', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'PFG-PROACT\hakima', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [SatsumaLIVEASPState_JobStep_DeleteExpiredSessions]    Script Date: 06/22/2015 15:49:44 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'SatsumaLIVEASPState_JobStep_DeleteExpiredSessions', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=1, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'EXECUTE DeleteExpiredSessions', 
		@database_name=N'SatsumaLIVEASPState', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'SatsumaLIVEASPState_JobSchedule_DeleteExpiredSessions', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=4, 
		@freq_subday_interval=1, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20001016, 
		@active_end_date=99991231, 
		@active_start_time=0, 
		@active_end_time=235959
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

USE [msdb]
GO

/****** Object:  Job [SatsumaSTAGEASPState_Job_DeleteExpiredSessions]    Script Date: 06/22/2015 15:49:59 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]]    Script Date: 06/22/2015 15:49:59 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'SatsumaSTAGEASPState_Job_DeleteExpiredSessions', 
		@enabled=0, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'Deletes expired sessions from the session state database.', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'PFG-PROACT\hakima', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [SatsumaSTAGEASPState_JobStep_DeleteExpiredSessions]    Script Date: 06/22/2015 15:49:59 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'SatsumaSTAGEASPState_JobStep_DeleteExpiredSessions', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=1, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'EXECUTE DeleteExpiredSessions', 
		@database_name=N'SatsumaSTAGEASPState', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'SatsumaSTAGEASPState_JobSchedule_DeleteExpiredSessions', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=4, 
		@freq_subday_interval=1, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20001016, 
		@active_end_date=99991231, 
		@active_start_time=0, 
		@active_end_time=235959
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO


USE [msdb]
GO

/****** Object:  Job [Trim  ELMAH_Error Tables]    Script Date: 06/22/2015 15:50:24 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]]    Script Date: 06/22/2015 15:50:24 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'Trim  ELMAH_Error Tables', 
		@enabled=0, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'This Job trims the ELMAH_Error table for all environemnts', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'PFG-PROACT\placejadm', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Trim  ELMAH_Error]    Script Date: 06/22/2015 15:50:24 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Trim  ELMAH_Error', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'USE ProvidentPPC_LIVE
GO
DELETE ELMAH_Error
WHERE TimeUtc < DATEADD(DD,-3,GETDATE())
GO

USE ProvidentPPC_STAGING
GO
DELETE ELMAH_Error
WHERE TimeUtc < DATEADD(DD,-3,GETDATE())', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Daily2300', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20121023, 
		@active_end_date=99991231, 
		@active_start_time=230000, 
		@active_end_time=235959
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

