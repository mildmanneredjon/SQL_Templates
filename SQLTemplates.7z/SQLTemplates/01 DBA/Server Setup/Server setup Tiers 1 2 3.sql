DECLARE @Drives TABLE
(
	DriveLetter VARCHAR(5)
	, MBFree INT
)
DECLARE @Label VARCHAR(200)
DECLARE @Result INT
, @objFSO INT
, @Drv INT 
, @cDrive VARCHAR(13) 
, @Size VARCHAR(50) 
, @Free VARCHAR(50)

--get the drive letters available plus labels
INSERT INTO @Drives
EXEC xp_fixeddrives

--EXEC @Result = sp_OACreate 'Scripting.FileSystemObject', @objFSO OUTPUT
--EXEC sp_OAGetProperty 'D','VolumeName', @Label OUTPUT
--SELECT @Label

-------------------------------------------------------------------------------
--get the memory available on the server
DECLARE @ServerMem_MB INT
	, @SQLServerMem_MB INT
select @ServerMem_MB = total_physical_memory_kb / 1024 
from sys.dm_os_sys_memory

IF (@ServerMem_MB * .85) < 4096
BEGIN
	SET @SQLServerMem_MB = @ServerMem_MB - 4096
END
ELSE
BEGIN
	SET @SQLServerMem_MB = @ServerMem_MB * .85
END
--enabled configuration options
EXEC sp_configure 'show advanced options', 1
RECONFIGURE
EXEC sp_configure 'max degree of parallelism', 4
EXEC sp_configure 'max server memory (MB)', @SQLServerMem_MB
EXEC sp_configure 'fill factor (%)', 80
EXEC sp_configure 'remote admin connections', 1 
EXEC sp_configure 'show advanced options', 0
EXEC sp_configure 'cost threshold for parallelism', 25
EXEC sp_configure 'optimize for ad hoc workloads', 1
EXEC sp_configure 'Agent XPs', 1;
EXEC sp_configure 'Database Mail XPs',1
EXEC sp_configure 'xp_cmdshell', 0
EXEC sp_configure 'backup compression default', 1
EXEC sp_configure 'Ole Automation Procedures', 0
EXEC sp_configure 'xp_cmdshell', 0
EXEC sp_configure 'min server memory (MB)', N'1024'
EXEC sp_configure 'max server memory (MB)', N'2048'
RECONFIGURE
EXEC sp_configure 'show advanced options', 0
RECONFIGURE

-------------------------------------------------------------------------------
--check tempdb has all the requisite files
IF NOT EXISTS (SELECT 1 FROM tempdb.sys.sysfiles WHERE name = 'tempdev2')
BEGIN
	ALTER DATABASE tempdb
	ADD FILE (NAME = 'tempdev2', FILENAME='T:\MSSQL\Data\tempdev2.ndf', SIZE=512MB, FILEGROWTH=128MB)
END
ELSE
BEGIN
	ALTER DATABASE tempdb
	MODIFY FILE (NAME = 'tempdev2', FILENAME='T:\MSSQL\Data\tempdev2.ndf', SIZE=512MB, FILEGROWTH=128MB)
END

IF NOT EXISTS (SELECT 1 FROM tempdb.sys.sysfiles WHERE name = 'tempdev3')
BEGIN
	ALTER DATABASE tempdb
	ADD FILE (NAME = 'tempdev3', FILENAME='T:\MSSQL\Data\tempdev3.ndf', SIZE=512MB, FILEGROWTH=128MB)
END
ELSE
BEGIN
	ALTER DATABASE tempdb
	MODIFY FILE (NAME = 'tempdev3', FILENAME='T:\MSSQL\Data\tempdev3.ndf', SIZE=512MB, FILEGROWTH=128MB)
END

IF NOT EXISTS (SELECT 1 FROM tempdb.sys.sysfiles WHERE name = 'tempdev4')
BEGIN
	ALTER DATABASE tempdb
	ADD FILE (NAME = 'tempdev4', FILENAME='T:\MSSQL\Data\tempdev4.ndf', SIZE=512MB, FILEGROWTH=128MB)
END
ELSE
BEGIN
	ALTER DATABASE tempdb
	MODIFY FILE (NAME = 'tempdev4', FILENAME='T:\MSSQL\Data\tempdev4.ndf', SIZE=512MB, FILEGROWTH=128MB)
END

ALTER DATABASE tempdb
MODIFY FILE (NAME = 'tempdev', FILENAME='T:\MSSQL\Data\tempdev.mdf', SIZE=512MB, FILEGROWTH=128MB)

ALTER DATABASE tempdb
MODIFY FILE (NAME = 'templog', FILENAME='L:\MSSQL\Logs\templog.ldf', SIZE=512MB, FILEGROWTH=128MB)

-------------------------------------------------------------------------------
--
ALTER DATABASE msdb
MODIFY FILE (NAME = 'MSDBData', SIZE=64MB, FILEGROWTH=64MB)

ALTER DATABASE msdb
MODIFY FILE (NAME = 'MSDBLog', SIZE=64MB, FILEGROWTH=64MB)

-------------------------------------------------------------------------------
--
USE [master]
GO
EXEC xp_instance_regwrite N'HKEY_LOCAL_MACHINE', N'Software\Microsoft\MSSQLServer\MSSQLServer', N'NumErrorLogs', REG_DWORD, 20
GO

-------------------------------------------------------------------------------
--
USE [master]
GO
EXEC xp_instance_regwrite N'HKEY_LOCAL_MACHINE', N'Software\Microsoft\MSSQLServer\MSSQLServer', N'LoginMode', REG_DWORD, 1
GO

-------------------------------------------------------------------------------
--setup SSISDB retention window
IF EXISTS (SELECT 1 FROM sys.databases WHERE name = 'SSISDB')
BEGIN
	EXEC SSISDB.catalog.configure_catalog RETENTION_WINDOW, 45
	EXEC SSISDB.catalog.configure_catalog MAX_PROJECT_VERSIONS, 15
	EXEC SSISDB.catalog.configure_catalog SERVER_LOGGING_LEVEL, 2
END


-------------------------------------------------------------------------------
--setup operators
EXEC msdb.dbo.sp_add_operator @name=N'DBA', 
		@enabled=1, 
		@weekday_pager_start_time=90000, 
		@weekday_pager_end_time=180000, 
		@saturday_pager_start_time=90000, 
		@saturday_pager_end_time=180000, 
		@sunday_pager_start_time=90000, 
		@sunday_pager_end_time=180000, 
		@pager_days=0, 
		@email_address=N'DBSAlerts@provident,co,uk', 
		@category_name=N'[Uncategorized]'

USE [msdb]
GO
EXEC msdb.dbo.sp_add_operator @name=N'DBA', 
		@enabled=1, 
		@pager_days=0, 
		@email_address=N'DBSalerts@Provident.co.uk'
GO

-------------------------------------------------------------------------------
--set SQL agent job history limit

USE [msdb]
GO
EXEC msdb.dbo.sp_set_sqlagent_properties @jobhistory_max_rows=1000, 
		@jobhistory_max_rows_per_job=50
GO


-------------------------------------------------------------------------------


USE [msdb]
GO

/****** Object:  Job [DBS  Cycle Error Log]    Script Date: 02/12/2015 12:15:39 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [DBA]    Script Date: 02/12/2015 12:15:39 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'DBA' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'DBA'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'DBS - Cycle Error Log', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'DBA', 
		@owner_login_name=N'sa', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Cycle Error log]    Script Date: 02/12/2015 12:15:39 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Cycle Error log', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'EXEC sp_cycle_errorlog ;
		EXEC sp_cycle_agenterrorlog ;
GO', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Cycle Error log schedule', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20151125, 
		@active_end_date=99991231, 
		@active_start_time=233500, 
		@active_end_time=235959
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

-------------------------------------------------------------------------------
USE [master]
GO

/****** Object:  Login [PFG\DBS - Global]    Script Date: 02/12/2015 14:10:12 ******/
CREATE LOGIN [PFG\DBS - Global] FROM WINDOWS WITH DEFAULT_DATABASE=[master], DEFAULT_LANGUAGE=[us_english]
GO

ALTER SERVER ROLE [sysadmin] ADD MEMBER [PFG\DBS - Global]
GO

-------------------------------------------------------------------------------
GO
EXEC msdb.dbo.sp_set_sqlagent_properties 
@errorlog_file=N'L:\Program Files\Microsoft SQL Server\MSSQL12.MSSQLSERVER\MSSQL\Data\SQLAGENT.OUT'
GO

/******************************************************/
/* Disable sa login and remove BUILTIN\Administrators */
/******************************************************/
USE MASTER
ALTER LOGIN sa DISABLE;
GO
USE MASTER
IF EXISTS (SELECT * FROM sys.server_principals
WHERE name = 'BUILTIN\Administrators')
DROP LOGIN [BUILTIN\Administrators]
GO

/***************************/
/* Create DBS mail profile */
/***************************/
DECLARE @profile_name sysname,
        @account_name sysname,
        @SMTP_servername sysname,
        @email_address NVARCHAR(128),
        @display_name NVARCHAR(128);

-- Profile name. Replace with the name for your profile
SET @profile_name = 'DBS';

-- Account information. Replace with the information for your account.
SET @account_name = 'DBS';
IF @@SERVERNAME LIKE 'UKS%'
	SET @SMTP_servername = '10.128.201.210';
ELSE
	SET @SMTP_servername = 'mailhost.ho.pfgroup.provfin.com';
	SET @email_address = 'DBSAlerts@Provident.co.uk';
	SET @display_name = 'DBS Alerts';


-- Verify the specified account and profile do not already exist.
IF EXISTS (SELECT * FROM msdb.dbo.sysmail_profile WHERE name = @profile_name)
BEGIN
	RAISERROR('The specified Database Mail profile (DBS) already exists.', 16, 1);
	GOTO done;
END;

IF EXISTS (SELECT * FROM msdb.dbo.sysmail_account WHERE name = @account_name )
BEGIN
	RAISERROR('The specified Database Mail account (DBS) already exists.', 16, 1) ;
	GOTO done;
END;

-- Start a transaction before adding the account and the profile
BEGIN TRANSACTION ;

DECLARE @rv INT;

-- Add the account
EXECUTE @rv=msdb.dbo.sysmail_add_account_sp
		@account_name = @account_name,
		@email_address = @email_address,
		@display_name = @display_name,
		@mailserver_name = @SMTP_servername;

IF @rv<>0
BEGIN
    RAISERROR('Failed to create the specified Database Mail account (DBS).', 16, 1) ;
    GOTO done;
END

-- Add the profile
EXECUTE @rv=msdb.dbo.sysmail_add_profile_sp
    @profile_name = @profile_name ;

IF @rv<>0
BEGIN
	RAISERROR('Failed to create the specified Database Mail profile (DBS).', 16, 1);
	ROLLBACK TRANSACTION;
	GOTO done;
END;

-- Associate the account with the profile.
EXECUTE @rv=msdb.dbo.sysmail_add_profileaccount_sp
		@profile_name = @profile_name,
		@account_name = @account_name,
		@sequence_number = 1 ;

IF @rv<>0
BEGIN
	RAISERROR('Failed to associate the speficied profile with the specified account (DBS).', 16, 1) ;
	ROLLBACK TRANSACTION;
	GOTO done;
END;

COMMIT TRANSACTION;
done:
GO

/***************/
/* Trace Flags */
/***************/

--Enable trace flags 272,610,1117,1118 through SQL Server Configuration Manager
--Check trace flags
DBCC TRACESTATUS(-1)