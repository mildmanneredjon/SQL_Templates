
SELECT *
FROM    sys.xml_schema_collections XSC JOIN sys.xml_schema_namespaces XSN
    ON (XSC.xml_collection_id = XSN.xml_collection_id)
WHERE    XSC.name = 'myCollection' 


SELECT XML_SCHEMA_NAMESPACE (N'dbo', N'SystemItemConfigurationSC')

ALTER TABLE SystemItem ALTER COLUMN [Configuration] VARCHAR(MAX)

EXEC SP_REFRESHVIEW 'vw_BuildPatterns'
EXEC SP_REFRESHVIEW 'vw_PotentialBuildPatterns'

DROP XML SCHEMA COLLECTION dbo.SystemItemConfigurationSC

CREATE XML SCHEMA COLLECTION dbo.SystemItemConfigurationSC
as
N'
<xsd:schema xmlns:xsd="http://www.w3.org/2001/XMLSchema" elementFormDefault="qualified">
	<xsd:element name="DiskConfig">
		<xsd:complexType>
			<xsd:complexContent>
				<xsd:restriction base="xsd:anyType">
					<xsd:sequence>
						<xsd:element name="DataStore" type="xsd:string" />
						<xsd:element name="Size_GB" type="xsd:short" />
						<xsd:element name="IOLimit" type="xsd:short" />
						<xsd:element name="PreferredDriveLetter" type="xsd:string" />
						<xsd:element name="SCSIChannel" type="xsd:byte" />
					</xsd:sequence>
				</xsd:restriction>
			</xsd:complexContent>
		</xsd:complexType>
	</xsd:element>
	<xsd:element name="Folder">
		<xsd:complexType>
			<xsd:complexContent>
				<xsd:restriction base="xsd:anyType">
					<xsd:sequence>
						<xsd:element name="Path" type="xsd:string" />
						<xsd:element name="Security">
							<xsd:complexType>
								<xsd:complexContent>
									<xsd:restriction base="xsd:anyType">
										<xsd:sequence>
											<xsd:element name="ACL" maxOccurs="unbounded">
												<xsd:complexType>
													<xsd:complexContent>
														<xsd:restriction base="xsd:anyType">
															<xsd:sequence>
																<xsd:element name="Account" type="xsd:string" />
																<xsd:element name="FileSystemRights" type="xsd:string" />
																<xsd:element name="AccessControlType" type="xsd:string" />
															</xsd:sequence>
														</xsd:restriction>
													</xsd:complexContent>
												</xsd:complexType>
											</xsd:element>
										</xsd:sequence>
									</xsd:restriction>
								</xsd:complexContent>
							</xsd:complexType>
						</xsd:element>
					</xsd:sequence>
				</xsd:restriction>
			</xsd:complexContent>
		</xsd:complexType>
	</xsd:element>
	<xsd:element name="RestoreConfig">
		<xsd:complexType>
			<xsd:complexContent>
				<xsd:restriction base="xsd:anyType">
					<xsd:sequence>
						<xsd:element name="NewName" type="xsd:string" />
						<xsd:element name="MoveFiles" minOccurs="0" maxOccurs="unbounded">
							<xsd:complexType>
								<xsd:complexContent>
									<xsd:restriction base="xsd:anyType">
										<xsd:sequence>
											<xsd:element name="LogicalFileName" type="xsd:string" />
											<xsd:element name="NewPath" type="xsd:string" />
										</xsd:sequence>
									</xsd:restriction>
								</xsd:complexContent>
							</xsd:complexType>
						</xsd:element>
					</xsd:sequence>
				</xsd:restriction>
			</xsd:complexContent>
		</xsd:complexType>
	</xsd:element>
	<xsd:element name="Script">
		<xsd:complexType>
			<xsd:complexContent>
				<xsd:restriction base="xsd:anyType">
					<xsd:sequence>
						<xsd:element name="Command" type="xsd:string" minOccurs="0" />
						<xsd:element name="TargetDatabase" type="xsd:string" minOccurs="0" />
					</xsd:sequence>
				</xsd:restriction>
			</xsd:complexContent>
		</xsd:complexType>
	</xsd:element>
	<xsd:element name="ServerConfig">
        <xsd:complexType>
                <xsd:sequence>
                    <xsd:element name="DataFilePath"></xsd:element>
                    <xsd:element name="LogFilePath"></xsd:element>
                </xsd:sequence>
            </xsd:complexType>
    </xsd:element>
</xsd:schema>
'


ALTER TABLE SystemItem ALTER COLUMN [Configuration] XML(dbo.SystemItemConfigurationSC)


