/*Execute in the context of the database that the tables are in*/

declare @audit_name varchar(256) = 'satsuma_staging_v2_tables' --set this to the value used in step 1
declare @schema_name_search varchar(256) = '%' --leave as % if you want your search to include every schema
declare @table_name_search varchar(256) = '%_v1' --use to return the tables you want to check for access against

declare @schema_name varchar(128)
declare @table_name varchar(128)
declare @sql varchar(max) 

set @sql = '
		declare c cursor global 
		for
		select s.name, t.name
		from sys.tables t
		JOIN sys.schemas s
		on s.schema_id = t.schema_id
		where s.name like '''+@schema_name_search+'''
		and t.name like '''+@table_name_search+''''

exec(@sql)

		open c
		fetch next from c into @schema_name, @table_name
		while @@fetch_status = 0
		begin
		set @sql = '
			alter database audit specification '+@audit_name+'_database_audit_specification
				for server audit '+@audit_name+'_server_audit
				add (select on object::['+@schema_name+'].['+@table_name+'] by public),
				add (insert on object::['+@schema_name+'].['+@table_name+'] by public),
				add (update on object::['+@schema_name+'].['+@table_name+'] by public),
				add (delete on object::['+@schema_name+'].['+@table_name+'] by public)'

		print @sql
		fetch next from c into @schema_name, @table_name
		end
close c
deallocate c