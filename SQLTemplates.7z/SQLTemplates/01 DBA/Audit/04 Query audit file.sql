Select top 1000 event_time,action_id,succeeded,server_principal_name,server_instance_name,database_name, schema_name, object_name,statement,CAST(additional_information as xml) as additional_information
from fn_get_audit_file ( 'd:\sql_audit\satsuma_staging_v2_tables_server_audit_B06B59B5-4644-4E53-B740-4057D2E6E12B_0_131511789692130000.sqlaudit',default,default)
