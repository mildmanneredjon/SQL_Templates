/*Check the location of the audit file so it can be removed after completing this process*/

declare @audit_name varchar(128) = 'satsuma_staging_v2_tables'
declare @database_being_audited varchar(128) = 'satsuma_staging'

exec('use '+@database_being_audited+'
		alter database audit specification ['+@audit_name+'_database_audit_specification]
		with (state = off)
		drop database audit specification ['+@audit_name+'_database_audit_specification]
		use master
		alter server audit ['+@audit_name+'_server_audit]
		with (state = off)
		drop server audit ['+@audit_name+'_server_audit]')