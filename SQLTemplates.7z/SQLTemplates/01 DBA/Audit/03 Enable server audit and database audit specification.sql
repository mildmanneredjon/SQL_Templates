declare @audit_name varchar(128) = 'satsuma_staging_v2_tables' --set this to the value used in step 1
declare @database_to_audit varchar(256) = 'satsuma_staging' --set this to the database that contains the tables to be audited
use master
exec('alter server audit '+@audit_name+'_server_audit with (state = on);
		use '+@database_to_audit+'
		alter database audit specification '+@audit_name+'_database_audit_specification with (state = on);')

