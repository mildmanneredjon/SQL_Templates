set nocount on

declare @file_destination varchar(256) = 'd:\sql_audit' --ensure folder exists first
--declare @audit_name varchar(256) = 'hrproemployee_old1' --set this value to whatever name you want
declare @database_to_audit varchar(256) = 'hrproemployee_old1' --set this to the database that contains the tables to be audited

/*Generate t-sql for the audit file and configure the settings*/
use master
exec('CREATE SERVER AUDIT '+@database_to_audit+'_server_audit
TO FILE 
(	FILEPATH = '''+@file_destination+'''
	,MAXSIZE = 2000 MB
	,MAX_FILES = 1
	,RESERVE_DISK_SPACE = ON
)
WITH
(	QUEUE_DELAY = 1000
	,ON_FAILURE = CONTINUE
)')

/*Generate t-sql for the database audit specification without configuration*/
exec('use '+@database_to_audit+'
		CREATE DATABASE AUDIT SPECIFICATION '+@database_to_audit+'_database_audit_specification
		FOR SERVER AUDIT '+@database_to_audit+'_server_audit')