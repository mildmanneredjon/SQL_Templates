------------------------------------------------------------------------------- 

SET XACT_ABORT ON;

 DECLARE @ExpectedRowCount int = 0
	, @ActualRowCount int = 1
	, @TotalRecordsToRemove int = 0
	, @TotalRecordsRemoved int = 0
	, @Counter int = 0
	, @Increment int = 1;


WHILE (@ActualRowCount <> 0 AND @@ERROR = 0)
BEGIN

	UPDATE TOP (1000) [SQLServer].[SQL_Server_Wait_Stats]
	SET [Unique_Key_Hash] = dbo.GetHash('MD5',[dbo].[ConvertSQLTodotNetString]([wait_type])
				+[dbo].[ConvertSQLTodotNetString]([MonitoredItem_GUID]))
	WHERE [Unique_Key_Hash] IS NULL

	SET @ActualRowCount = @@ROWCOUNT
	SET @TotalRecordsRemoved = @TotalRecordsRemoved + @ActualRowCount;
	SET @Counter = @Counter + @Increment;

END
          
SELECT @TotalRecordsRemoved, @Counter


