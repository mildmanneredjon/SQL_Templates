-- ========================================================================================
-- Drop Database Role template for Azure SQL Database and Azure SQL Data Warehouse Database
-- ========================================================================================

-- Drop the role
DROP ROLE <role_name, sysname, Production_Owner>;
GO
