-- ===================================================================================
-- Create Schema Template for Azure SQL Database and Azure SQL Data Warehouse Database
-- ===================================================================================

CREATE SCHEMA <sample_schema, sysname, sample_schema>
AUTHORIZATION <owner_name, sysname, owner_name>
