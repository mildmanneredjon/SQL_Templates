-- ===========================================================
-- Drop User-defined Data Type template for Azure SQL Database
-- ===========================================================

-- Drop the data type - this will fail if it is being used
DROP TYPE <schema_name,sysname,dbo>.<type_name,sysname,Phone>
GO
