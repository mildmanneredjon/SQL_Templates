-- ====================================================================================
-- Drop SQL Login template for Azure SQL Database and Azure SQL Data Warehouse Database
-- ====================================================================================

DROP LOGIN <login_name, sysname, login_name>
Go
