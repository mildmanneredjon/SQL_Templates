-- ===================================================================================
-- Drop database template for Azure SQL Database and Azure SQL Data Warehouse Database
-- ===================================================================================
DROP DATABASE <Database_Name, sysname, Database_Name>
GO
