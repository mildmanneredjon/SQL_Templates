-- ======================================================
-- Query for All Changes With a Wrapper Function Template
-- ======================================================
USE <Database_Name,sysname,Database_Name>
GO

SELECT * FROM fn_all_changes_<capture_instance,sysname,capture_instance>
  (NULL, NULL, N'all')
GO
