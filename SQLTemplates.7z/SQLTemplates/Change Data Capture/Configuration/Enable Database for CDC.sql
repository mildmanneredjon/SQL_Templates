-- ================================
-- Enable Database for CDC Template
-- ================================
USE <Database_Name,sysname,Database_Name>
GO

EXEC sys.sp_cdc_enable_db
GO
