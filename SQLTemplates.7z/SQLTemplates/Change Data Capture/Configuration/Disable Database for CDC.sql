-- =================================
-- Disable Database for CDC Template
-- =================================
USE <Database_Name,sysname,Database_Name>
GO

EXEC sys.sp_cdc_disable_db
GO
