-- ========================
-- Drop Default template
-- ========================
-- This feature is marked for deprecation

DROP DEFAULT <schema_name, sysname, dbo>.<default_name, , today>
GO
