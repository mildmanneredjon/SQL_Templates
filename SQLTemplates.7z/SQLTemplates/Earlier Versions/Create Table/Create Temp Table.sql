-- =============================================
-- Create temp table
-- =============================================
CREATE TABLE #<temp_table_name, sysname, test_table> (
<column_1, sysname, c1> <datatype_for_column_1, , char> NULL, 
<column_2, sysname, c2> <datatype_for_column_2, , int> NOT NULL)
GO

