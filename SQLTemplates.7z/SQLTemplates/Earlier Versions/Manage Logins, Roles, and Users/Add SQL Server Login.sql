-- =============================================
-- Add Sql Server login
-- =============================================
sp_addlogin @loginame    = N'<Sql_Server_login, sysname, test_login>',
	    @passwd      = '<password, sysname, 123#$>',
	    @defdb       = N'<database, sysname, pubs>',
	    @deflanguage = N'<language, sysname, German>',
	    @sid         = <sid, varbinary(16), NULL>,
	    @encryptopt  = <encryption_option, varchar(20), NULL>
GO

