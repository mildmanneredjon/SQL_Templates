-- =======================================
-- Update Statistics One Index Template
-- =======================================
UPDATE STATISTICS <schema_name, sysname, schema_name>.<table_name, sysname, table_name>(<index_name, sysname, index_name>); 
GO
