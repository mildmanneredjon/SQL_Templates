-- =====================
-- Drop User template
-- =====================
USE <database_name, sysname, AdventureWorks>
GO

DROP USER <user_name, sysname, user_name>
GO