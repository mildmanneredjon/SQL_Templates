-- ================================
-- Create User-defined Data Type
-- ================================
USE <database_name,sysname,AdventureWorks>
GO

-- Drop the data type - this will fail if it is being used
DROP TYPE <schema_name,sysname,dbo>.<type_name,sysname,Phone>
GO
