/*Execute on the source server to generate the tsql then copy and run the tsql on the destination

If you're running on a different server then you will need to correct the path if it is a local backup*/

DECLARE @SourceDatabase varchar(128) = 'SatsumaCMS_Live'

DECLARE @DestinationServer varchar(128) = 'DBYPFGLILSQL01' --Ensure this is set correctly so you don't accidentally overwrite the source!
DECLARE @DestinationDatabase varchar(128) = 'SatsumaCMS_Staging'


SELECT distinct 'if (select @@servername) <> '''+@destinationserver+'''
begin
print ''incorrect destination server''
end
else
begin
use master
ALTER DATABASE ['+@DestinationDatabase+'] SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
ALTER DATABASE ['+@DestinationDatabase+'] SET MULTI_USER WITH NO_WAIT;
EXECUTE master..sqlbackup ''-SQL "RESTORE DATABASE ['+@DestinationDatabase+'] FROM DISK = '''''+bmf.physical_device_name+''''' WITH RECOVERY,REPLACE"''
end'
FROM msdb.dbo.backupmediafamily bmf
     INNER JOIN msdb.dbo.backupset bs
         ON bmf.media_set_id = bs.media_set_id
WHERE bs.media_set_id in (select max(media_set_id) from msdb.dbo.backupset where database_name = @SourceDatabase and type = 'D')

select * from msdb.dbo.backupset