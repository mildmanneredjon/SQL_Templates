-- =============================================
-- Drop Server Audit Specification Template
-- =============================================

-- =============================================
-- Author:		<Author,,>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
DROP SERVER AUDIT SPECIFICATION <audit_specification_name,nVarchar,audit_specification_name>
