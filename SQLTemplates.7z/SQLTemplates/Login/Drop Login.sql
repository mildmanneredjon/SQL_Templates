-- ======================
-- Drop Login template
-- ======================

DROP LOGIN <login_name, sysname, login_name>
GO