USE [EntitySearch]
GO
/****** Object:  UserDefinedFunction [dbo].[fn_MatchKey]    Script Date: 28/10/2014 14:46:48 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER FUNCTION [dbo].[fn_MatchKey]
(
  @string nvarchar(50)
)
RETURNS nvarchar(50)
With SchemaBinding
AS
BEGIN
	DECLARE @Key VARCHAR(50)
	DECLARE	@numbers table (rn tinyint, pr tinyint, nx tinyint)
	DECLARE	@Curnumber tinyint

	Select	@Curnumber = 1
	
	while	@Curnumber <= 50
	begin
		insert	@numbers
		Select	@Curnumber, @Curnumber - 1, @Curnumber + 1;
		Select	@Curnumber = @Curnumber + 1;
	end;


	SELECT	@Key = CAST((Select
		CASE WHEN rn = 1 THEN
			CASE WHEN SUBSTRING(@string,rn,1) = 'p' AND SUBSTRING(@string,nx,1) like '[h]' THEN 'f' -- change ph to f
				 WHEN SUBSTRING(@string,rn,1) = 'c' AND SUBSTRING(@string,nx,1) <> 'h' THEN 'k' -- change c to k
				 WHEN SUBSTRING(@string,rn,1) like '[AEIOUQRTPSDFGJKLZXCVBNMWHY]' THEN SUBSTRING(@string,rn,1) ELSE '' end 
		ELSE
			CASE WHEN SUBSTRING(@string,rn,1) = SUBSTRING(@string,pr,1) THEN '' -- remove double letters
				 WHEN SUBSTRING(@string,rn,1) like '[CK]' AND SUBSTRING(@string,pr,1) like '[CK]' THEN '' --remove c or k if preceeded by c or k
				 WHEN SUBSTRING(@string,rn,1) = 'c' AND SUBSTRING(@string,nx,1) <> 'h' THEN 'k' -- change c to k 
				 WHEN SUBSTRING(@string,rn,1) = 'p' AND SUBSTRING(@string,nx,1) like '[h]' THEN 'f' -- replace ph with f
				 WHEN SUBSTRING(@string,rn,1) = 'h' AND SUBSTRING(@string,pr,1) like '[SC]' THEN 'h' -- keep h if sh or ch. Allow h in position 2 to go as likely to be silent
				 WHEN SUBSTRING(@string,rn,1) like '[QRTPSDFGJKLZXCVBNMW]' THEN SUBSTRING(@string,rn,1) 
				 ELSE '' 
			END
		END	
	FROM @numbers
	ORDER BY rn
	FOR XML PATH ('') )
	AS VARCHAR(50)) 

	RETURN Upper(@Key)
END
