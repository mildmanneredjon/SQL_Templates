DECLARE @MaxCTId BIGINT = 7800320, 
@CurrentCTId BIGINT = 10000000, @StartRow INT = 0

       SELECT @StartRow + ROW_NUMBER() OVER(order by chain_id, chain_n )                 AS record_id ,
              *
              FROM (
                     SELECT DISTINCT

                           (CAST(appx.pf_ProvidentApplicationId AS INT)*10) + appx.pf_GuarantorCount                AS chain_id ,        
                           CASE WHEN TelTyp = 'MobilePhone' THEN 1 ELSE 2 END                         AS chain_n 


                     FROM dbo.pf_eventExtensionBase ev
                           INNER JOIN CHANGETABLE(CHANGES dbo.pf_eventExtensionBase, @MaxCTId) AS ct
                                  ON ev.pf_EventId = ct.pf_EventId
                                         AND ct.SYS_CHANGE_OPERATION IN ('I','U')
                           INNER JOIN dbo.pf_applicationBase app on app.pf_applicationId = ev.pf_ApplicationEventId
                           INNER JOIN dbo.pf_applicationExtensionBase appx on appx.pf_applicationId = ev.pf_ApplicationEventId
                           INNER JOIN [pf_guarantorstatusExtensionBase] GSEB ON GSEB.pf_Application = app.pf_applicationId 
                           INNER JOIN (SELECT ContactId, Salutation, FirstName, LastName, BirthDate, TelNo, TelTyp
                                                       FROM dbo.ContactBase 
                                                              UNPIVOT (TelNo FOR TelTyp IN (MobilePhone, Telephone2)) u
                                                ) con on con.ContactId = GSEB.pf_Guarantor AND con.ContactId = pf_Contact
                           INNER JOIN dbo.ContactExtensionBase cone on cone.ContactId = con.ContactId
                           INNER JOIN dbo.CustomerAddressBase ca ON ca.ParentId = con.ContactId
                           INNER JOIN (select ParentId, Max(AddressNumber) AS MaxAddNo
                                                       from dbo.CustomerAddressBase 
                                                       group by ParentId
                                                ) mc ON mc.ParentId = ca.ParentId and mc.MaxAddNo = ca.AddressNumber
                           LEFT JOIN dbo.StringMapBase as SMBT on cone.pf_title = SMBT.AttributeValue AND SMBT.AttributeName = 'pf_title'
                           INNER JOIN dbo.StringMapBase as SMBA on appx.[pf_GLApplicantBorrowerStatus] = SMBA.AttributeValue AND SMBA.AttributeName = 'pf_glapplicantborrowerstatus'
                           LEFT JOIN dbo.StringMapBase as SMBG on GSEB.[pf_GuarantorStatus] = SMBG.AttributeValue AND SMBG.AttributeName = 'pf_guarantorstatus'

                     WHERE ct.SYS_CHANGE_VERSION <= @CurrentCTId
                           AND SMBA.Value = 'Accepted'
                           AND SMBG.Value = 'Completing Application'
                           AND ev.pf_name = 'OutboundApplication'
                           AND GSEB.pf_GuarantorTo IS NULL
                           AND ISNUMERIC(appx.pf_ProvidentApplicationId) = 1
              ) res
