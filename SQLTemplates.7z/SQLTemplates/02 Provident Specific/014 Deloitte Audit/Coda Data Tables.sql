/*
Restore CFNLIVE database from hosstake\holder on to test environment on Hostage\Release

drop and create cfn_audit database on test environment and script out the following tables for creation from the CFNLIVE database:

oas_dochead
oas_docline
oas_document
oas_element

Set the @Year, @FromPeriod, and @ToPeriod to requested periods

*/
use cfn_audit

Declare @year int 
Declare @fromperiod int 
Declare @toperiod int 

set @year = 2017 -- financial year

set @fromperiod = 0
set @toperiod = 8

/*oas_dochead*/
INSERT INTO dbo.oas_dochead(cmpcode, cmpcode_cs, doccode, doccode_cs, docnum, docnum_cs, tstamp, moddate, usrname, 
status, status_cs, batch, yr, yr_cs, period, period_cs, curdoc, curdoc_cs, docdate, inpdate, inptime, xref, authuser, 
regdate, icstatus, origin, flags, descr, origdoccode, origdocnum, origcmpcode, workflowstat, templatecode, attachfile) 

SELECT 
     cmpcode, cmpcode_cs, doccode, doccode_cs, docnum, docnum_cs, tstamp, moddate, usrname, status, status_cs, batch, yr, yr_cs, period, period_cs, curdoc, curdoc_cs, docdate, inpdate, inptime, xref, authuser, regdate, icstatus, origin, flags, descr, origdoccode, origdocnum, origcmpcode, workflowstat, templatecode, attachfile 
  FROM [CFNLIVE].[dbo].[oas_dochead]
  where cmpcode in ('PFMS', 
'PPC', 
'GPC', 
'PPCROI' , 
'CEL', 
'LPFG')
and yr = @year
and period between @fromperiod and @toperiod

/*oas_docline*/
INSERT INTO dbo.oas_docline(cmpcode, doccode, docnum, doclinenum, 
tstamp, moddate, usrname, el1, el2, el3, el4, el5, el6, el7, el8, 
duedate, valdate, valuehome, valuehome_dp, valuedoc, valuedoc_dp, 
docrate, valuedual, valuedual_dp, dualrate, statuser, statuserint,
statrec, statrecint, statpay, statpayint, descr, ref1, ref2, ref3, 
 linetype, deb_cred_ind, taxlinecode, doctaxturn, doctaxturn_dp, 
 hometaxturn, hometaxturn_dp, docsumtax, docsumtax_dp, homesumtax,
  homesumtax_dp, custsupp, paydate, statrem, remdate, severity,
   lettersev, matchlevel, flags, ref4, ref5, ref6, temporaryid, docflags, dualflags, ival) 


SELECT 
     dcl.cmpcode, dcl.doccode, dcl.docnum, dcl.doclinenum, dcl.tstamp, dcl.moddate, dcl.usrname, dcl.el1, dcl.el2, dcl.el3, dcl.el4, dcl.el5, dcl.el6, dcl.el7, dcl.el8, dcl.duedate, dcl.valdate, dcl.valuehome, dcl.valuehome_dp, dcl.valuedoc, dcl.valuedoc_dp, dcl.docrate, dcl.valuedual, dcl.valuedual_dp, dcl.dualrate, dcl.statuser, dcl.statuserint, dcl.statrec, dcl.statrecint, dcl.statpay, dcl.statpayint, dcl.descr, dcl.ref1, dcl.ref2, dcl.ref3, dcl.linetype, dcl.deb_cred_ind, dcl.taxlinecode, dcl.doctaxturn, dcl.doctaxturn_dp, dcl.hometaxturn, dcl.hometaxturn_dp, dcl.docsumtax, dcl.docsumtax_dp, dcl.homesumtax, dcl.homesumtax_dp, dcl.custsupp, dcl.paydate, dcl.statrem, dcl.remdate, dcl.severity, dcl.lettersev, dcl.matchlevel, dcl.flags, dcl.ref4, dcl.ref5, dcl.ref6, dcl.temporaryid, dcl.docflags, dcl.dualflags, dcl.ival
  FROM [CFNLIVE].[dbo].[oas_docline] dcl
  INNER JOIN
  [CFNLIVE].[dbo].[oas_dochead] DH
  ON dcl.CMPCODE = DH.CMPCODE
  AND dcl.DOCCODE = DH.DOCCODE
  AND dcl.DOCNUM = DH.DOCNUM
  where DH.cmpcode in ('PFMS', 
'PPC', 
'GPC', 
'PPCROI' , 
'CEL', 
'LPFG')
and DH.yr = @year
and DH.period between @fromperiod and @toperiod

/*oas_element*/
INSERT INTO dbo.oas_element(cmpcode , cmpcode_cs, code, code_cs, elmlevel, 
elmlevel_cs, indirectcode, tstamp, name, sname, cur, tax, accounttype, statuser, 
statpay, statrec, descr, matchable, statpayint, summary, split, settle, paper, elec,
subanal, taxrepesl, taxrepintra, crliminforce, crlim, crlim_dp, taxmethod, terms,
  keepturn, ten99, custsuppacc, discenable, forcedisperse, enablepay, paymode, priority,
   medcode , tag, qty1_used, qty1_title, qty1_mand, qty1_balcode , qty1_dp, qty2_used, qty2_title,
    qty2_mand, qty2_balcode , qty2_dp, qty3_used, qty3_title, qty3_mand, qty3_balcode , qty3_dp,
                qty4_used, qty4_title, qty4_mand, qty4_balcode , qty4_dp, adddate, moddate, deldate, 
                 usrname, accountsummary, crlimdate, crlimcurr, elmstat, sic, crmanager, crrating, 
                 crratingdate, crref, cragency, dateaccopened, paymentindex, taxadjustment, matchtopo,
                  extval, arcpaid, arcrecon, ten99code, subslevel, subselm, temporaryelm, maxtemporaryid, 
                  allowtaxnum, allowlangcode, allowctycode, forceterms, forcetaxnum, forceaddress, force1099, 
                  startyear, startperiod, endyear, endperiod, statmemo, balancingacc, catcode, assetelement, 
                  extcode, extconfig, procallowprnt, proctxpdf, proctxxml, proctxb2b, procorders, procreq,
                   billallowprnt, billtxpdf, billtxxml, billsipforma, billsifinal, billcnpforma, billcnfinal, 
                   repcode1, repcode2, repcode3, punchoutcode, punchouturl, punchoutdomain, punchoutuser, punchoutpasswd,
                    punchoutidcode, punchoutenc, punchoutmktplace, custsuppaccext, autoreceipt, procstatus, tolerancecode,
                                matchingoffset, proctranslimit, proctranslimit_dp, proccalloffs, procgrns, procreturns, procemailsal, 
                                 procemailsub, billoutputdevice, billemailsal, billemailsub)

SELECT cmpcode, cmpcode_cs, code, code_cs,
                                  elmlevel, elmlevel_cs, indirectcode, tstamp, name, sname, cur, tax, accounttype,
                                   statuser, statpay, statrec, descr, matchable, statpayint, summary, split, settle, paper, 
                                   elec, subanal, taxrepesl, taxrepintra, crliminforce, crlim, crlim_dp, taxmethod, terms, keepturn,
                                    ten99, custsuppacc, discenable, forcedisperse, enablepay, paymode, priority, medcode , tag, qty1_used,
                                                qty1_title, qty1_mand, qty1_balcode , qty1_dp, qty2_used, qty2_title, qty2_mand, qty2_balcode , qty2_dp, 
                                                 qty3_used, qty3_title, qty3_mand, qty3_balcode , qty3_dp, qty4_used, qty4_title, qty4_mand, qty4_balcode ,
                                                  qty4_dp, adddate, moddate, deldate, usrname, accountsummary, crlimdate, crlimcurr, elmstat, sic, crmanager,
                                                   crrating, crratingdate, crref, cragency, dateaccopened, paymentindex, taxadjustment, matchtopo, extval, arcpaid, 
                                                   arcrecon, ten99code, subslevel, subselm, temporaryelm, maxtemporaryid, allowtaxnum, allowlangcode, allowctycode,
                                                    forceterms, forcetaxnum, forceaddress, force1099, startyear, startperiod, endyear, endperiod, statmemo, balancingacc,
                                                                catcode, assetelement, extcode, extconfig, procallowprnt, proctxpdf, proctxxml, proctxb2b, procorders, procreq, billallowprnt,
                                                                  billtxpdf, billtxxml, billsipforma, billsifinal, billcnpforma, billcnfinal, repcode1, repcode2, repcode3, punchoutcode, 
                                                                  punchouturl, punchoutdomain, punchoutuser, punchoutpasswd, punchoutidcode, punchoutenc, punchoutmktplace, custsuppaccext, 
                                                                  autoreceipt, procstatus, tolerancecode, matchingoffset, proctranslimit, proctranslimit_dp, proccalloffs, procgrns, procreturns,
                                                                   procemailsal, procemailsub, billoutputdevice, billemailsal, billemailsub 

  FROM [CFNLIVE].[dbo].[oas_element]

/*oas_document*/
INSERT INTO dbo.oas_document(cmpcode ,code ,tstamp ,name ,sname ,adddate ,deldate ,moddate ,usrname
,cancel_doc ,turn ,batch ,statuser ,statpay ,descr ,numrule ,pdl ,special_doc ,duerule ,duemod 
 ,valmod ,valrule ,widedue ,wideval ,wideext ,defcurrule ,defcur ,tax ,banktype ,esl ,intrastat 
 ,ten99 ,spselfprop ,spreversing ,sprecurring ,spnumdocs ,spnumdocs_ov ,spdocphasing ,spdocphasingrule
  ,spdocphase_ov ,spdaterule ,spdaterule_ov ,spamountrule ,spamountrule_ov ,summ_pre ,anal_pre
   ,ctrl_tot ,dest ,intray_check ,num_type ,cur_ctl ,auth_user ,num_sum ,num_tax_codes ,defsumlines
    ,defanllines ,allowadd ,maxpdllines ,validonacc ,userexit ,destctrl ,destcode ,periodusage ,purord 
                ,linetype ,linesense ,userstatus ,ext1ac ,ext1act ,ext1usage ,ext1comp1 ,ext1comp2 ,ext1comp3 ,ext1comp4 
                ,ext1comp5 ,ext1comp6 ,ext1docrule ,extreflabel1 ,ext2ac ,ext2act ,ext2usage ,ext2comp1 ,ext2comp2
                ,ext2comp3 ,ext2comp4 ,ext2comp5 ,ext2comp6 ,ext2docrule ,extreflabel2 ,ext3ac ,ext3act ,ext3usage
                  ,ext3comp1 ,ext3comp2 ,ext3comp3 ,ext3comp4 ,ext3comp5 ,ext3comp6 ,ext3docrule ,extreflabel3
                   ,ext4ac ,ext4act ,ext4usage ,ext4comp1 ,ext4comp2 ,ext4comp3 ,ext4comp4 ,ext4comp5 ,ext4comp6 
                   ,ext4docrule ,extreflabel4 ,ext5ac ,ext5act ,ext5usage ,ext5comp1 ,ext5comp2 ,ext5comp3 ,ext5comp4 
                   ,ext5comp5 ,ext5comp6 ,ext5docrule ,extreflabel5 ,ext6ac ,ext6act ,ext6usage ,ext6comp1 ,ext6comp2 ,
                   ext6comp3 ,ext6comp4 ,ext6comp5 ,ext6comp6 ,ext6docrule ,extreflabel6 ,extcomb ,extacruleall ,extdocruleall
                    ,extactruleall ,allowdisc ,documenttype ,ext1vocab ,ext2vocab ,ext3vocab ,ext4vocab ,ext5vocab ,ext6vocab 
                                ,paydetails ,mediareq ,mediaprot ,mediadef ,cmpbnkreq ,cmpbnkprot ,cmpbnkdef ,elmbnkreq ,elmaddreq ,userref1req
                                ,userref1prot ,userref1type ,userref1def ,userref2req ,userref2prot ,userref2type ,userref2def ,userref3req ,
                                userref3prot ,userref3type ,userref3def ,retainvalue ,userref1vocab ,userref2vocab ,userref3vocab ,revqtycredit 
                                 ,revqtydebit ,headuserexit ,actioncode ,promptfororig ,allowamendment ,extrefmodify1 ,extrefmodify2 ,extrefmodify3 
                                 ,extrefmodify4 ,extrefmodify5 ,extrefmodify6 ,ext1excdocrule ,ext2excdocrule ,ext3excdocrule ,ext4excdocrule ,ext5excdocrule
                                  ,ext6excdocrule ,extexcdocruleall ,ext1sumonlyrule ,ext2sumonlyrule ,ext3sumonlyrule ,ext4sumonlyrule ,ext5sumonlyrule
                                   ,ext6sumonlyrule ,extsumonlyruleall ,balelmrule ,balaccounts ,cancelmatch ,matchfrominput ,matcode ,assetdoc ,extcode
                                    ,extconfig ,headextcode ,headextconfig ,previntraydel ,previntraymod ,assetperline ,wfwrequired ,wfwexppres ,wfwposhier
                                                ,intraywfw ,protintraywfw ,confintraywfw ,editintraywfw ,bookswfw ,protbookswfw ,reserveappid ,matchfrombrowse ,browsematcode ,promptforauth ) 

select cmpcode ,code ,tstamp ,name ,sname ,adddate ,deldate ,moddate ,usrname
,cancel_doc ,turn ,batch ,statuser ,statpay ,descr ,numrule ,pdl ,special_doc ,duerule ,duemod 
 ,valmod ,valrule ,widedue ,wideval ,wideext ,defcurrule ,defcur ,tax ,banktype ,esl ,intrastat 
 ,ten99 ,spselfprop ,spreversing ,sprecurring ,spnumdocs ,spnumdocs_ov ,spdocphasing ,spdocphasingrule
  ,spdocphase_ov ,spdaterule ,spdaterule_ov ,spamountrule ,spamountrule_ov ,summ_pre ,anal_pre
   ,ctrl_tot ,dest ,intray_check ,num_type ,cur_ctl ,auth_user ,num_sum ,num_tax_codes ,defsumlines
    ,defanllines ,allowadd ,maxpdllines ,validonacc ,userexit ,destctrl ,destcode ,periodusage ,purord 
                ,linetype ,linesense ,userstatus ,ext1ac ,ext1act ,ext1usage ,ext1comp1 ,ext1comp2 ,ext1comp3 ,ext1comp4 
                ,ext1comp5 ,ext1comp6 ,ext1docrule ,extreflabel1 ,ext2ac ,ext2act ,ext2usage ,ext2comp1 ,ext2comp2
                ,ext2comp3 ,ext2comp4 ,ext2comp5 ,ext2comp6 ,ext2docrule ,extreflabel2 ,ext3ac ,ext3act ,ext3usage
                  ,ext3comp1 ,ext3comp2 ,ext3comp3 ,ext3comp4 ,ext3comp5 ,ext3comp6 ,ext3docrule ,extreflabel3
                   ,ext4ac ,ext4act ,ext4usage ,ext4comp1 ,ext4comp2 ,ext4comp3 ,ext4comp4 ,ext4comp5 ,ext4comp6 
                   ,ext4docrule ,extreflabel4 ,ext5ac ,ext5act ,ext5usage ,ext5comp1 ,ext5comp2 ,ext5comp3 ,ext5comp4 
                   ,ext5comp5 ,ext5comp6 ,ext5docrule ,extreflabel5 ,ext6ac ,ext6act ,ext6usage ,ext6comp1 ,ext6comp2 ,
                   ext6comp3 ,ext6comp4 ,ext6comp5 ,ext6comp6 ,ext6docrule ,extreflabel6 ,extcomb ,extacruleall ,extdocruleall
                    ,extactruleall ,allowdisc ,documenttype ,ext1vocab ,ext2vocab ,ext3vocab ,ext4vocab ,ext5vocab ,ext6vocab 
                                ,paydetails ,mediareq ,mediaprot ,mediadef ,cmpbnkreq ,cmpbnkprot ,cmpbnkdef ,elmbnkreq ,elmaddreq ,userref1req
                                ,userref1prot ,userref1type ,userref1def ,userref2req ,userref2prot ,userref2type ,userref2def ,userref3req ,
                                userref3prot ,userref3type ,userref3def ,retainvalue ,userref1vocab ,userref2vocab ,userref3vocab ,revqtycredit 
                                 ,revqtydebit ,headuserexit ,actioncode ,promptfororig ,allowamendment ,extrefmodify1 ,extrefmodify2 ,extrefmodify3 
                                 ,extrefmodify4 ,extrefmodify5 ,extrefmodify6 ,ext1excdocrule ,ext2excdocrule ,ext3excdocrule ,ext4excdocrule ,ext5excdocrule
                                  ,ext6excdocrule ,extexcdocruleall ,ext1sumonlyrule ,ext2sumonlyrule ,ext3sumonlyrule ,ext4sumonlyrule ,ext5sumonlyrule
                                   ,ext6sumonlyrule ,extsumonlyruleall ,balelmrule ,balaccounts ,cancelmatch ,matchfrominput ,matcode ,assetdoc ,extcode
                                    ,extconfig ,headextcode ,headextconfig ,previntraydel ,previntraymod ,assetperline ,wfwrequired ,wfwexppres ,wfwposhier
                                                ,intraywfw ,protintraywfw ,confintraywfw ,editintraywfw ,bookswfw ,protbookswfw ,reserveappid ,matchfrombrowse ,browsematcode ,promptforauth 
  FROM [CFNLIVE].[dbo].[oas_document] 
