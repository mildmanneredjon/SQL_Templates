/*
Run the following as multi server query against the required database engines
*/

DECLARE @DB_Name varchar(128) 
DECLARE @Command nvarchar(max)
DECLARE database_cursor CURSOR FOR 
SELECT name
FROM MASTER.sys.databases
where name not in ('model','msdb','distribution','DBSAdmin','dbs_maintenance','tempdb')
and name not like 'work_%'

OPEN database_cursor

FETCH NEXT FROM database_cursor INTO @DB_Name

WHILE @@FETCH_STATUS = 0 
BEGIN 

set @Command = 'use '+@db_name+'; 
						SELECT db_name(), sp.name as "Database Owner"
,sp.[principal_id] as "Database Owner Principal ID"
,sp.[sid] as "Database Owner SID"
,sp.[type_desc] as "Database Owner Type"
,sp.[is_disabled] as "Database Owner Disabled"
,sl.denylogin as "Database Owner Deny Login"
,sl.hasaccess as "Has Access"
,sp.[create_date] as "Database Owner Create Date"
,sp.[modify_date] as "Database Owner Account Modify
Date"
, LOGINPROPERTY(sp.name,''PasswordLastSetTime'') as
"Account Last Password Change Date"
, db.name as "Database"
FROM master.sys.databases as db,
master.sys.server_principals as sp LEFT JOIN
master.sys.syslogins as sl
on (sp.sid = sl.sid)
WHERE (db.owner_sid = sl.sid);'

	EXEC sp_executesql @Command

     FETCH NEXT FROM database_cursor INTO @DB_Name 
END

CLOSE database_cursor 
DEALLOCATE database_cursor