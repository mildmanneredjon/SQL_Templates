/*
Run the following as multi server query against the required database engines
*/

DECLARE @DB_Name varchar(128) 
DECLARE @Command nvarchar(max)
DECLARE database_cursor CURSOR FOR 
SELECT name
FROM MASTER.sys.databases
where name not in ('model','msdb','distribution','DBSAdmin','dbs_maintenance','tempdb')
and name not like 'work_%'

OPEN database_cursor

FETCH NEXT FROM database_cursor INTO @DB_Name

WHILE @@FETCH_STATUS = 0 
BEGIN 

set @Command = 'use '+@db_name+'; 
						SELECT db_name(), sp3.name as "Schema Owner Login"
,sp.name as "Schema Owner"
,sp.[principal_id] as "Schema Owner Principal ID"
,sp.[sid] as "Schema Owner SID"
,sp.[type_desc] as "Schema Owner Type"
,sp3.[is_disabled] as "Schema Owner Disabled"
,sl.denylogin as "Schema Owner Deny Login"
,sl.hasaccess as "Schema Owner Has Access"
,sp.[create_date] as "Account Create Date"
,sp.[modify_date] as "Account Modify Date"
, LOGINPROPERTY(sp3.name,''PasswordLastSetTime'') as
"Account Last Password Change Date"
,CASE WHEN su.islogin = 0 THEN ''N\A - Role''
WHEN su.[hasdbaccess] = 0 THEN ''No''
WHEN su.[hasdbaccess] = 1 THEN ''Yes'' END as "Has
Database Access"
,sc.schema_id as "Schema ID"
,sc.name as "Schema Name"
,so.name as "Object Name"
,so.type_desc "Object Type"
FROM sys.schemas as sc, sys.sysusers as su, sys.objects
as so, sys.database_principals as sp LEFT JOIN
master.sys.syslogins as sl
on (sp.sid = sl.sid)
LEFT JOIN master.sys.server_principals as sp3
on (sp.sid = sp3.sid)
WHERE ((sc.[principal_id] = sp.principal_id) and
(sp.[principal_id] = su.uid) and (so.schema_id =
sc.schema_id));'

	EXEC sp_executesql @Command

     FETCH NEXT FROM database_cursor INTO @DB_Name 
END

CLOSE database_cursor 
DEALLOCATE database_cursor