/*
Run the following as multi server query against the required database engines
*/

SELECT * FROM msdb.dbo.sysjobschedules;