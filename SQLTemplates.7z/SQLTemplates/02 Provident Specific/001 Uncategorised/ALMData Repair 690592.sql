--EXECUTE master..sqlbackup '-SQL "RESTORE DATABASE [ALMData] FROM DISK = ''G:\Backups\FULL_MANUAL_ALMData_20140707_192007.sqb'' WITH RECOVERY, MOVE ''ALMData'' TO ''E:\MSSQL$RANSOM\Data\ALMData.mdf'', MOVE ''ALMData_log'' TO ''E:\MSSQL$RANSOM\Log\ALMData_log.ldf'', REPLACE, ORPHAN_CHECK"'

--EXECUTE master..sqlbackup '-SQL "RESTORE DATABASE [ALMData_20140129] FROM DISK = ''\\HOSWAKBACKUP1\g$\HosAlmanac$Manual\ALMData\FULL_MANUAL_ALMData_20140129_192001.sqb'' WITH RECOVERY, MOVE ''ALMData'' TO ''E:\MSSQL$RANSOM\Data\ALMData_20140129.mdf'', MOVE ''ALMData_log'' TO ''E:\MSSQL$RANSOM\Log\ALMData_20140129_log.ldf'', ORPHAN_CHECK"'

---\\HOSWAKBACKUP1\g$\HosAlmanac$Manual\ALMData

/**
Msg 8928, Level 16, State 1, Line 1
Object ID 1637580872, index ID 1, partition ID 72057594069057536, alloc unit ID 72057594045792256 (type LOB data): Page (1:2136813) could not be processed.  See other errors for details.
Msg 8939, Level 16, State 98, Line 1
Table error: Object ID 1637580872, index ID 1, partition ID 72057594069057536, alloc unit ID 72057594045792256 (type LOB data), page (1:2136813). Test (IS_OFF (BUF_IOERR, pBUF->bstat)) failed. Values are 12716041 and -4.
Msg 8965, Level 16, State 1, Line 1
Table error: Object ID 1637580872, index ID 1, partition ID 72057594069057536, alloc unit ID 72057594045792256 (type LOB data). The off-row data node at page (1:2136813), slot 0, text ID 1676804096 is referenced by page (1:2136682), slot 0, but was not seen in the scan.
Msg 8929, Level 16, State 1, Line 1
Object ID 1637580872, index ID 1, partition ID 72057594069057536, alloc unit ID 72057594077708288 (type In-row data): Errors found in off-row data with ID 1676804096 owned by data record identified by RID = (1:4908847:54)
**/


ALTER DATABASE ALMData SET SINGLE_USER WITH ROLLBACK AFTER 10 SECONDS
DBCC CHECKDB ('ALMData', REPAIR_REBUILD)
ALTER DATABASE ALMData SET MULTI_USER WITH ROLLBACK AFTER 10 SECONDS

DBCC CHECKDB ('ALMData', REPAIR_ALLOW_DATA_LOSS)

DBCC TRACEON (3604)

DBCC IND('ALMData', 'WorkflowData',1)

DBCC PAGE (ALMData, 1, 2136813,2)

--reference by
DBCC PAGE (ALMData, 1, 2136682,0)


ALTER DATABASE ALMData SET MULTI_USER WITH ROLLBACK AFTER 10 SECONDS


DBCC CHECKDB ('ALMData_20140129')
