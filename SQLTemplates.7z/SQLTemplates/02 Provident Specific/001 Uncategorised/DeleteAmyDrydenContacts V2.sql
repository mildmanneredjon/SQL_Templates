 
 /**
*-----------------------------------------------------------------------------*
|								CR 137310                                     |
|                                                                             |
|         Version 1         Dale Stewart             13/11/2014               |
|                                                                             |
*-----------------------------------------------------------------------------*

COMPATIBLITY
------------
2008 upwards

*-----------------------------------------------------------------------------*
BACKGROUND
----------


*-----------------------------------------------------------------------------*
USAGE
-----

*-----------------------------------------------------------------------------*
VERSION 1
---------

*-----------------------------------------------------------------------------*
REFERENCES
----------

*-----------------------------------------------------------------------------*
PARAMETERS
----------


*-----------------------------------------------------------------------------*
DEPENDENCIES
----------

**/

-------------------------------------------------------------------------------
:setvar checkSQLCMD "checkSQLCMD" 
GO 
IF ('$(checkSQLCMD)' = '$' + '(checkSQLCMD)') RAISERROR ('This script must be run in SQLCMD mode.', 20, 1) WITH LOG 
GO 
SELECT 'This part executes only in SQLCMD mode!'

-------------------------------------------------------------------------------
:setvar ServerName "PFGLONBAG01"
:setvar DatabaseName "checkSQLCMD" 

:connect $(ServerName)
USE $(DatabaseName)

------------------------------------------------------------------------------- 
 SET XACT_ABORT ON;

 DECLARE @ExpectedRowCount INT = 1
	, @ActualRowCount INT = 0

BEGIN TRAN

	-------------------------------------------------------------------------------
	--Take a backup copy of the data
	SELECT *
	INTO BISupport.dbo.EntityHub_Links_CR137310
	FROM EntityHub.dbo.Links
	WHERE hubid = 'F01BBA84-6B33-E411-BDBE-005056AE7818';

	SELECT *
	INTO BISupport.dbo.Auth_t_User_CR137310
	FROM Auth.auth.t_User
	WHERE rowid = 466;

	SELECT *
	INTO BISupport.dbo.Prospects_t_Prospect_CR137310
	FROM Prospects.dbo.t_Prospect
	WHERE RowGUID = 'A5F19F47-EC72-4668-B890-72CE89393573';

	SELECT *
	INTO BISupport.dbo.EntitySearch_PersonKeys_CR137310
	from EntitySearch.dbo.PersonKeys
	WHERE id = 225381;

	-------------------------------------------------------------------------------
	DELETE FROM EntityHub.dbo.Links
	where hubid = 'F01BBA84-6B33-E411-BDBE-005056AE7818';

	SET @ActualRowCount = @@ROWCOUNT
	IF @ExpectedRowCount <> @ActualRowCount
		BEGIN
			THROW 99999, 1, 'Row count mismatch in EntityHub.dbo.Links'; 
		END;

	-------------------------------------------------------------------------------
	DELETE FROM Auth.auth.t_User
	WHERE rowid = 466;

	SET @ActualRowCount = @@ROWCOUNT
	IF @ExpectedRowCount <> @ActualRowCount
		BEGIN
			 THROW 99999, 1, 'Row count mismatch in Auth.auth.t_User';
		END;

	-------------------------------------------------------------------------------   
	DELETE FROM Prospects.dbo.t_Prospect
	WHERE RowGUID = 'A5F19F47-EC72-4668-B890-72CE89393573';

	SET @ActualRowCount = @@ROWCOUNT
	IF @ExpectedRowCount <> @ActualRowCount
		BEGIN
			THROW 99999, 1, 'Row count mismatch in Prospects.dbo.t_Prospect';
		END;

	-------------------------------------------------------------------------------
	DELETE FROM EntitySearch.dbo.PersonKeys
	WHERE id = 225381;

	SET @ActualRowCount = @@ROWCOUNT
	IF @ExpectedRowCount <> @ActualRowCount
		BEGIN
			THROW 99999, 1, 'Row count mismatch in EntitySearch.dbo.PersonKeys';
		END;


COMMIT TRAN