-- Synopsis: APPLY
-- To de-activate the targeted Tandem CRM applications for which no application progression has taken place.
-- The purpose of the de-activation is to unclutter the CRM application Active view by moving the old tandem 
-- applications to the Inactive view.
--
-- This script specifically Inactivates the CRM application whose Application Status = "Application Received"
-- Borrrower Status = "Application Received" and Guarantor Status not set.
--
-- Scripted By: Yogesh Mistry
-- Dated: 11/11/2014
--
-- 

SET XACT_ABORT ON; 

DECLARE @BatchSize SMALLINT	= 50
	, @ExpectedTotalRowCount INT = 161402
	, @ActualTotalRowCount INT = 0
    , @modifiedon datetime = '2014-11-12 00:00:00'
    , @modifiedby uniqueidentifier ='8605EE39-4292-E311-B52D-005056B32DF9' -- User Yogesh Mistry on PRODUCTION or PFTEST, This account is the owner of the change, but can be modified 
	, @BatchNo INT = 0

DECLARE @pf_applicationBase_update TABLE
(
	 modifiedon	datetime
	 , modifiedby uniqueidentifier
	 , pf_applicationid	uniqueidentifier
	 , pf_providentapplicationid int
	 , pf_prospectid int
	 , updated BIT DEFAULT 0
)

DECLARE @pf_applicationBase_batch TABLE
(
	 modifiedon	datetime
	 , modifiedby uniqueidentifier
	 , pf_applicationid	uniqueidentifier
	 , pf_providentapplicationid int
	 , pf_prospectid int
)

INSERT INTO	@pf_applicationBase_update
	(
		 modifiedon	
		 , modifiedby 
		 , pf_applicationid	
		 , pf_providentapplicationid
		 , pf_prospectid
		 , updated 
	)
SELECT 
	@modifiedon
	, @modifiedby
	, b.pf_applicationid
	, a.pf_providentapplicationid
	, a.pf_prospectid
FROM   [Provident_MSCRM].[dbo].pf_applicationExtensionBase a
	INNER JOIN [Provident_MSCRM].[dbo].pf_applicationBase b
		ON a.pf_applicationid = b.pf_applicationid 
WHERE  a.pf_applicationStatus = '86358FE3-29D1-E311-909C-005056AE3AF5' -- Application Received PRODUCTION or PFTEST
	AND    a.pf_glapplicantborrowerstatus = '100000004' -- Application Received
	AND    a.pf_glapplicantguarantorstatus1 is null -- Not Set
	--AND    a.pf_applicationid = b.pf_applicationid
	AND    b.statecode = 0 -- Active
	AND    b.statuscode = 1 -- Active
	AND    b.createdon < DATEADD(DAY,-3,'2014-11-07');

WHILE (SELECT COUNT(*)
		FROM   @pf_applicationBase_update
		WHERE updated = 0) > 0
BEGIN

	PRINT 'Starting batch number ' + CONVERT(VARCHAR, @BatchNo)

	DELETE FROM @pf_applicationBase_batch
	INSERT @pf_applicationBase_batch
		(
			 modifiedon	
			 , modifiedby 
			 , pf_applicationid	
			 , pf_providentapplicationid
			 , pf_prospectid
		)
	SELECT TOP (@BatchSize)
		modifiedon	
		, modifiedby 
		, pf_applicationid	
		, pf_providentapplicationid
		, pf_prospectid
	FROM @pf_applicationBase_update
	WHERE updated = 0

	--update the applicationbase table
	UPDATE ab
    SET ab.statecode =  1
        , ab.statuscode = 2
        , ab.modifiedon = pab.modifiedon
        , ab.modifiedby = pab.modifiedby
	FROM [Provident_MSCRM].[dbo].pf_applicationBase ab
		INNER JOIN @pf_applicationBase_batch pab
			ON ab.pf_applicationid = pab.pf_applicationid


	SET @ActualTotalRowCount = @ActualTotalRowCount + @@ROWCOUNT

	IF @ActualTotalRowCount <> @BatchSize
	BEGIN
		THROW 99999, 1, 'Actual row updated does not match the batch size'
	END
		
	--mark the record as updated 
	UPDATE pau
	SET updated = 1
	FROM @pf_applicationBase_update pau
		INNER JOIN @pf_applicationBase_batch pab
			ON pau.pf_applicationid = pab.pf_applicationid
    		 
	
	PRINT 'Batch number ' + CONVERT(VARCHAR, @BatchNo) + ' completed'  

	SET @BatchNo = @BatchNo + 1

END

PRINT CONVERT(VARCHAR,@ActualTotalRowCount) + ' rows out of an expected ' + CONVERT(VARCHAR,@ExpectedTotalRowCount) + ' rows have been udpated'