-- Synopsis: APPLY
-- To de-activate the targeted Tandem CRM applications for which no application progression has taken place.
-- The purpose of the de-activation is to unclutter the CRM application Active view by moving the old tandem 
-- applications to the Inactive view.
--
-- This script specifically Inactivates the CRM application whose Application Status = "Application Received"
-- Borrrower Status = "Application Received" and Guarantor Status not set.
--
-- Scripted By: Yogesh Mistry
-- Dated: 11/11/2014
--
-- 

SET XACT_ABORT ON; 

DECLARE @ExpectedTotalRowCount INT = 161402
	, @ActualTotalRowCount INT = 0
    , @modifiedon datetime = '2014-11-12 00:00:00'
    , @modifiedby uniqueidentifier ='8605EE39-4292-E311-B52D-005056B32DF9'; -- User Yogesh Mistry on PRODUCTION or PFTEST, This account is the owner of the change, but can be modified 


BEGIN TRAN

	UPDATE ab
	SET ab.statecode =  1
        , ab.statuscode = 2
        , ab.modifiedon = pab.modifiedon
        , ab.modifiedby = pab.modifiedby
	FROM [Provident_MSCRM].[dbo].pf_applicationBase ab
		INNER JOIN 
			(
				SELECT 
					@modifiedon modifiedon
					, @modifiedby modifiedby
					, b.pf_applicationid
					, a.pf_providentapplicationid
					, a.pf_prospectid
				FROM   [Provident_MSCRM].[dbo].pf_applicationExtensionBase a
					INNER JOIN [Provident_MSCRM].[dbo].pf_applicationBase b
						ON a.pf_applicationid = b.pf_applicationid 
				WHERE  a.pf_applicationStatus = '86358FE3-29D1-E311-909C-005056AE3AF5' -- Application Received PRODUCTION or PFTEST
					AND    a.pf_glapplicantborrowerstatus = '100000004' -- Application Received
					AND    a.pf_glapplicantguarantorstatus1 is null -- Not Set
					--AND    a.pf_applicationid = b.pf_applicationid
					AND    b.statecode = 0 -- Active
					AND    b.statuscode = 1 -- Active
					AND    b.createdon < DATEADD(DAY,-3,'2014-11-07')
			) AS pab
			ON ab.pf_applicationid = pab.pf_applicationid
    ;

	SET @ActualTotalRowCount = @@ROWCOUNT;
	
	IF @ExpectedTotalRowCount <> @ActualTotalRowCount
	BEGIN
		THROW 99999, 1, 'Expected row count mismatch';
	END

COMMIT TRAN
 
END