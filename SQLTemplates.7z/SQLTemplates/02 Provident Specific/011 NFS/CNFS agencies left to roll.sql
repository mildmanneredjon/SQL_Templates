/*Has CNFS rolled*/

SELECT DISTINCT NFS.nfs_dbo.agency.agency_id, NFS.nfs_dbo.agency.accounting_week_num, NFS.nfs_dbo.agency.agency_status_type_code
    FROM NFS.nfs_dbo.agency (nolock)
    LEFT JOIN NFS.NFS_DBO.Accounting_Week (nolock) on NFS.NFS_DBO.Accounting_Week.accounting_week_num    = NFS.nfs_dbo.agency.accounting_week_num 
    WHERE Agency_Status_Type_Code = 'OP'
    and NFS.NFS_DBO.Accounting_Week.start_date  between DATEADD(wk, DATEDIFF(wk,0,GETDATE()), -7) and DATEADD(wk, DATEDIFF(wk,0,GETDATE()), 0)

/*Check PNFS*/

select * from nfs_dbo.import_statement_0001 with (nolock)

/*Check import file*/

select * from nfs_dbo.import_file with (nolock)  

/*Check agency Q*/

select * from NFS_DBO.Agency_Queue_CNFS_Table with (nolock) where status != 'PR'