/*
Connect to UKSWAKSENTINAL\WAKPENGUIN

Use to determine why ETL has not started - when JINITIAL_ETL_SETUP fails and you get an email with the following:

JINITIAL_ETL_SETUP because open transactions exist on the CNFS Please investigate 

28/12/2017 -	Changed join from left to inner as not every transaction has a related session. 
				No idea what you're meant to do with this lack of information though! 
				Also added @get_transaction_info = 1 - http://whoisactive.com/docs/12_transaction/
*/

select dt.database_transaction_begin_time, dt.database_transaction_type, tst.session_id
from sys.dm_tran_database_transactions dt
left join sys.dm_tran_session_transactions tst
on dt.transaction_id = tst.transaction_id
where database_transaction_type=1 --read/write transaction
and database_id=5 --nfs database

exec sp_whoisactive @filter = 'nfs', @filter_type = 'database',@