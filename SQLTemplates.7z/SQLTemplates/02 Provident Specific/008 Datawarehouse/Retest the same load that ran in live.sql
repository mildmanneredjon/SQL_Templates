/*
Run the following to get the load_Id you want to rerun in test

SELECT *--MAX(Load_Id) 
FROM   EDW_DBO.DW_ETL_LOAD_PROCESS_MDT
WHERE  Process_Id = '1' -- @intProcessIdFocus 
order by 1 desc

*/

DECLARE @preprod_server varchar(128)
DECLARE @load_id smallint

SET @preprod_server = 'RSDEVDW03'
SET	@load_id = 0

IF @@Servername = @preprod_server and @load_id <> 0
	BEGIN
		update EDW_DBO.dw_etl_load_process_mdt
		set current_stage = null,Active_Record_Bln = 1,last_updated_date = Last_Creation_Date
	END
ELSE
	BEGIN
		PRINT 'You either need to input a correct @load_id or are connected to the wrong server, please change the connection to the correct server'
	END

/*
Before starting the test ETL cancel the	JSTART_STAGING_ETL in the SDEV_ETLSTART job stream
*/