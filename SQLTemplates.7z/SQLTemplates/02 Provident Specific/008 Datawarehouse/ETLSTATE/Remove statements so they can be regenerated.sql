/*Connect to the preprod database server*/
declare @msg varchar(256)

select @msg = 'Server is: '+@@servername+', ensure you are using a test server'

if (select @@servername) not in ('PFGSQLT4N13','rsdevdw02\lands')
begin
raiserror(@msg,16,1)
return
end

use DW_Compliance_Mart
	if(select count(1) 
		from EDW_DBO.DM_STATEMENT_CONFIG
		where file_production_date is null) = 8
	begin
		delete from EDW_DBO.DM_STATEMENT_CONFIG
		where file_production_date is null
	end
	else
	begin
		raiserror('Number of statements is not 8, check the state of the table',16,1)
	end