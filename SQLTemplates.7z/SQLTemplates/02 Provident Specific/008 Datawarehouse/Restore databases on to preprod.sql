/*Script to generate tsql to restore most recent backups on to RSDEVDW02\LANDS - run this on RSDSHAKER\LEG*/

Declare @DestinationServer varchar(128)
set @destinationServer = 'RSDEVDW02\LANDS'

SELECT distinct replace('if (select @@servername) <> '''+@destinationserver+'''
begin
print ''incorrect destination server''
end
else
begin
use master
ALTER DATABASE ['+bs.database_name+'] SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
ALTER DATABASE ['+bs.database_name+'] SET MULTI_USER WITH NO_WAIT;
EXECUTE master..sqlbackup ''-SQL "RESTORE DATABASE ['+bs.database_name+'] FROM DISK = '''''+bmf.physical_device_name+''''' WITH RECOVERY,REPLACE"''
end','.ho','')
FROM msdb.dbo.backupmediafamily bmf
     INNER JOIN msdb.dbo.backupset bs
         ON bmf.media_set_id = bs.media_set_id
WHERE bs.media_set_id in (select max(media_set_id) from msdb.dbo.backupset where database_name in ('DW_Compliance_Mart','DW_EDW','DW_Mapping','DW_Metadata','DW_Reference','DW_Sales_ODS','DW_Staging','DW_Statement_Mart','DW_Statement_Mart_Snapshot','DW_Statement_Viewer') and [type] = 'd' group by database_name)