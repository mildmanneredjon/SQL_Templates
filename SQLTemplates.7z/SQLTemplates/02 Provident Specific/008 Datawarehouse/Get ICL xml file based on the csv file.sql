/*
The csv file is generated in \\rsdshaker\e$\ITOps\ICL\Extract by the field risk team

The xml file is generated after JDOCUMENT_GENERATOR_ICL. This relies on SW3RDUI_ICL running 1st to queue the customer_id entries

The xml file is outputted to \\rsdshaker\e$\ITOps\STATEMENTFILE_EXPORT
*/

  use DW_Compliance_Mart
  select sc.file_name
  from [DW_Compliance_Mart].[EDW_DBO].[DM_Statement_Config] sc
  inner join edw_dbo.DM_ICL_FILE_LOAD_CONFIG lc
  on sc.batch_id = lc.processed_batch_id
  where lc.filename = '201728_SecurityLetterRequest.csv'