SET NOCOUNT ON;

DECLARE @Var_FinanceWeek		INTEGER,
		@Var_CodaLoadId			INTEGER,
		@BankRecLoadId			INTEGER,
		@Var_ReportsLoadId		INTEGER,
		@Var_SQLCMD				NVARCHAR(3000),
		@Var_ExecutionStatus	INTEGER

SELECT 'Extract Files Deletion Start' Info
SET @Var_SQLCMD = 'DEL /Q E:\ITOps\CODA_Extract\*.*'
EXEC @Var_ExecutionStatus = master..xp_cmdshell @Var_SQLCMD
IF @Var_ExecutionStatus <> 0 OR @Var_ExecutionStatus IS NULL 
BEGIN
	RAISERROR('Del 1 Failed',16,1)
END

SET @Var_SQLCMD = 'DEL /Q E:\ITOps\Datawarehouse\CODA\*.*'
EXEC @Var_ExecutionStatus = master..xp_cmdshell @Var_SQLCMD
IF @Var_ExecutionStatus <> 0 OR @Var_ExecutionStatus IS NULL 
BEGIN
	RAISERROR('Del 2 Failed',16,1)
END

SET @Var_SQLCMD = 'DEL /Q E:\ITOps\Datawarehouse\BANKREC\GPC\*.*'
EXEC @Var_ExecutionStatus = master..xp_cmdshell @Var_SQLCMD
IF @Var_ExecutionStatus <> 0 OR @Var_ExecutionStatus IS NULL 
BEGIN
	RAISERROR('Del 3 Failed',16,1)
END

SET @Var_SQLCMD = 'DEL /Q E:\ITOps\Datawarehouse\BANKREC\PPC\*.*'
EXEC @Var_ExecutionStatus = master..xp_cmdshell @Var_SQLCMD
IF @Var_ExecutionStatus <> 0 OR @Var_ExecutionStatus IS NULL 
BEGIN
	RAISERROR('Del 4 Failed',16,1)
END

SET @Var_SQLCMD = 'DEL /Q E:\ITOps\Datawarehouse\BANKREC\ROI\*.*'
EXEC @Var_ExecutionStatus = master..xp_cmdshell @Var_SQLCMD
IF @Var_ExecutionStatus <> 0 OR @Var_ExecutionStatus IS NULL 
BEGIN
	RAISERROR('Del 5 Failed',16,1)
END

SET @Var_SQLCMD = 'DEL /Q E:\ITOps\Datawarehouse\BANKREC\*.*'
EXEC @Var_ExecutionStatus = master..xp_cmdshell @Var_SQLCMD
IF @Var_ExecutionStatus <> 0 OR @Var_ExecutionStatus IS NULL 
BEGIN
	RAISERROR('Del 6 Failed',16,1)
END

SET @Var_SQLCMD = 'DEL /Q E:\ITOps\Datawarehouse\REPORTS\ISSUES\*.*'
EXEC @Var_ExecutionStatus = master..xp_cmdshell @Var_SQLCMD
IF @Var_ExecutionStatus <> 0 OR @Var_ExecutionStatus IS NULL 
BEGIN
	RAISERROR('Del 7 Failed',16,1)
END

SET @Var_SQLCMD = 'DEL /Q E:\ITOps\Datawarehouse\REPORTS\ARREARS\*.*'
EXEC @Var_ExecutionStatus = master..xp_cmdshell @Var_SQLCMD
IF @Var_ExecutionStatus <> 0 OR @Var_ExecutionStatus IS NULL 
BEGIN
	RAISERROR('Del 8 Failed',16,1)
END

SET @Var_SQLCMD = 'DEL /Q E:\ITOps\Datawarehouse\REPORTS\BALANCE\*.*'
EXEC @Var_ExecutionStatus = master..xp_cmdshell @Var_SQLCMD
IF @Var_ExecutionStatus <> 0 OR @Var_ExecutionStatus IS NULL 
BEGIN
	RAISERROR('Del 9 Failed',16,1)
END

SET @Var_SQLCMD = 'DEL /Q E:\ITOps\Datawarehouse\REPORTS\Other_Payment_And_Receipts\*.*'
EXEC @Var_ExecutionStatus = master..xp_cmdshell @Var_SQLCMD
IF @Var_ExecutionStatus <> 0 OR @Var_ExecutionStatus IS NULL 
BEGIN
	RAISERROR('Del 10 Failed',16,1)
END

SELECT 'Extract Files Deletion End' Info

--BEGIN TRAN

/*
Use this script to clear down the most recent Finance data produced
and then recreate it using updated code. Please note the intention 
is to reuse the batches
*/

/*
-- This code was used to identify tables to clear down/update
-- which will be touched by Finance ETL. Run against DW_Metadata,
-- DW_Reference and DW_Sales_ODS
SELECT name
FROM SYSOBJECTS
WHERE xtype = 'U';

-- This code was used to identify tables with Am_ column name
-- to further cover tables for cleardown etc.
SELECT t.name AS table_name,
SCHEMA_NAME(schema_id) AS schema_name,
c.name AS column_name
FROM sys.tables AS t
INNER JOIN sys.columns c ON t.OBJECT_ID = c.OBJECT_ID
WHERE c.name LIKE '%Am_Role%'
ORDER BY schema_name, table_name;

*/
-- Update config parameters
SELECT 'Updating namevalues Start' Info 
UPDATE DW_Metadata.EDW_DBO.DW_ETL_NAMEVALUE_MDT
SET Value = 'E:\ITOps\Datawarehouse\CODA\'
WHERE Name = 'CODA_FILE_DESTINATION_LOCATION'  

UPDATE DW_Metadata.EDW_DBO.DW_ETL_NAMEVALUE_MDT
SET Value = 'E:\ITOps\Datawarehouse\BANKREC\GPC\'
WHERE Name = 'BANKREC_GPC_EXTRACT_DESTINATION_LOCATION'  

UPDATE DW_Metadata.EDW_DBO.DW_ETL_NAMEVALUE_MDT
SET Value = 'E:\ITOps\Datawarehouse\BANKREC\PPC\'
WHERE Name = 'BANKREC_PPC_EXTRACT_DESTINATION_LOCATION'  

UPDATE DW_Metadata.EDW_DBO.DW_ETL_NAMEVALUE_MDT
SET Value = 'E:\ITOps\Datawarehouse\BANKREC\ROI\'
WHERE Name = 'BANKREC_ROI_EXTRACT_DESTINATION_LOCATION'  

UPDATE DW_Metadata.EDW_DBO.DW_ETL_NAMEVALUE_MDT
SET Value = 'E:\ITOps\Datawarehouse\BANKREC\'
WHERE Name = 'BANKREC_OTHER_EXTRACT_DESTINATION_LOCATION'  

UPDATE DW_Metadata.EDW_DBO.DW_ETL_NAMEVALUE_MDT
SET Value = 'http://hossnake/reportserver_boa'
WHERE Name = 'REPORT_SERVER_URL'  

UPDATE DW_Metadata.EDW_DBO.DW_ETL_NAMEVALUE_MDT
SET Value = 'E:\ITOps\Datawarehouse\REPORTS\ISSUES\'
WHERE Name = 'ISSUE_ANALYSIS_REPORTS_DESTINATION_LOCATION'  

UPDATE DW_Metadata.EDW_DBO.DW_ETL_NAMEVALUE_MDT
SET Value = 'E:\ITOps\Datawarehouse\REPORTS\ARREARS\'
WHERE Name = 'ARREARS_PROVISION_REPORTS_DESTINATION_LOCATION'  

UPDATE DW_Metadata.EDW_DBO.DW_ETL_NAMEVALUE_MDT
SET Value = 'E:\ITOps\Datawarehouse\REPORTS\BALANCE\'
WHERE Name = 'BALANCING_REPORTS_DESTINATION_LOCATION'  

UPDATE DW_Metadata.EDW_DBO.DW_ETL_NAMEVALUE_MDT
SET Value = 'E:\ITOps\Datawarehouse\REPORTS\Other_Payment_And_Receipts\'
WHERE Name = 'OTHER_REPORTS_DESTINATION_LOCATION'  

UPDATE DW_Metadata.EDW_DBO.DW_ETL_NAMEVALUE_MDT
SET Value = 'RSTMikado\YumYum'
WHERE Name = 'FILE_MANAGEMENT_DB_SERVER'  

UPDATE DW_Metadata.EDW_DBO.DW_ETL_NAMEVALUE_MDT
SET Value = 'E:\ITOps\Datawarehouse\BANKREC\PPC\'
WHERE Name = 'PCI_PPC_EXTRACT_LOCATION'  

UPDATE DW_Metadata.EDW_DBO.DW_ETL_NAMEVALUE_MDT
SET Value = 'E:\ITOps\Datawarehouse\BANKREC\GPC\'
WHERE Name = 'PCI_GPC_EXTRACT_LOCATION'  

UPDATE DW_Metadata.EDW_DBO.DW_ETL_NAMEVALUE_MDT
SET Value = 'E:\ITOps\Datawarehouse\BANKREC\ROI\'
WHERE Name = 'PCI_ROI_EXTRACT_LOCATION'  

UPDATE DW_Metadata.EDW_DBO.DW_ETL_NAMEVALUE_MDT
SET Value = 'E:\ITOps\Datawarehouse\BANKREC\PPC\'
WHERE Name = 'RS_PPC_EXTRACT_LOCATION'  

UPDATE DW_Metadata.EDW_DBO.DW_ETL_NAMEVALUE_MDT
SET Value = 'E:\ITOps\Datawarehouse\BANKREC\GPC\'
WHERE Name = 'RS_GPC_EXTRACT_LOCATION'  

UPDATE DW_Metadata.EDW_DBO.DW_ETL_NAMEVALUE_MDT
SET Value = 'E:\ITOps\Datawarehouse\BANKREC\ROI\'
WHERE Name = 'RS_ROI_EXTRACT_LOCATION'  

UPDATE DW_Metadata.EDW_DBO.DW_ETL_NAMEVALUE_MDT
SET Value = 'E:\ITOps\Datawarehouse\BANKREC\PPC\'
WHERE Name = 'RP_PPC_EXTRACT_LOCATION'  

UPDATE DW_Metadata.EDW_DBO.DW_ETL_NAMEVALUE_MDT
SET Value = 'E:\ITOps\Datawarehouse\BANKREC\ROI\'
WHERE Name = 'RP_ROI_EXTRACT_LOCATION'  

UPDATE DW_Metadata.EDW_DBO.DW_ETL_NAMEVALUE_MDT
SET Value = 'E:\ITOps\Datawarehouse\BANKREC\PPC\'
WHERE Name = 'OC_PPC_EXTRACT_LOCATION'  

UPDATE DW_Metadata.EDW_DBO.DW_ETL_NAMEVALUE_MDT
SET Value = 'E:\ITOps\Datawarehouse\BANKREC\PPC\'
WHERE Name = 'OU_PPC_EXTRACT_LOCATION'  

UPDATE DW_Metadata.EDW_DBO.DW_ETL_NAMEVALUE_MDT
SET Value = 'E:\ITOps\Datawarehouse\BANKREC\GPC\'
WHERE Name = 'OC_GPC_EXTRACT_LOCATION'  

UPDATE DW_Metadata.EDW_DBO.DW_ETL_NAMEVALUE_MDT
SET Value = 'E:\ITOps\Datawarehouse\BANKREC\GPC\'
WHERE Name = 'OU_GPC_EXTRACT_LOCATION'  

SELECT 'Updating namevalues End' Info 

--Get code for fetch load id and week number to clear down
SELECT @Var_FinanceWeek = MAX(Accounting_Week_Num)
FROM DW_Metadata.EDW_DBO.DW_ETL_WEEKLY_PROCESS_MDT
WHERE Bankrec_Load_Id IS NOT NULL 
AND Coda_Load_Id IS NOT NULL
AND Reports_Load_Id IS NOT NULL

SELECT	@BankRecLoadId	= Bankrec_Load_Id,
		@Var_CodaLoadId		= Coda_Load_Id,
		@Var_ReportsLoadId	= Reports_Load_Id 
FROM DW_Metadata.EDW_DBO.DW_ETL_WEEKLY_PROCESS_MDT
WHERE Accounting_Week_Num = @Var_FinanceWeek

SELECT 'Processing following load ids and week' Info 
SELECT @Var_FinanceWeek FinanceWeek, @BankRecLoadId BankRecLoadId, @Var_CodaLoadId CodaLoadId, @Var_ReportsLoadId ReportsLoadId

SELECT 'Data deletion/clear down Start' Info
DELETE DW_Reference.EDW_DBO.DW_NFS_REPRESENTATIVE_AM_ASSOCIATION_REF WHERE Accounting_Week_Num = @Var_FinanceWeek
DELETE DW_Sales_ODS.EDW_DBO.DW_NFS_CODA_VOUCHER_ACTIVITY_ODS WHERE Accounting_Week_Num = @Var_FinanceWeek
DELETE DW_Sales_ODS.EDW_DBO.DW_NFS_CODA_TRANSACTION_ODS WHERE Load_Id = @Var_CodaLoadId
DELETE DW_Sales_ODS.EDW_DBO.DW_NFS_ARREARS_PROVISION_AGENCY_ODS WHERE Load_Id = @Var_ReportsLoadId
DELETE DW_Sales_ODS.EDW_DBO.DW_NFS_ARREARS_PROVISION_REPORT_ODS WHERE Load_Id = @Var_ReportsLoadId
DELETE DW_Sales_ODS.EDW_DBO.DW_NFS_BANKREC_SUMMARY_ODS WHERE Load_Id = @BankRecLoadId
DELETE DW_Sales_ODS.EDW_DBO.DW_NFS_BANKREC_TRANSACTION_ODS WHERE Load_Id = @BankRecLoadId
DELETE DW_Sales_ODS.EDW_DBO.DW_NFS_ISSUE_ANALYSIS_REPORT_ODS WHERE Load_Id = @Var_ReportsLoadId

UPDATE DW_Metadata.EDW_DBO.DW_PREPAID_CARD_ISSUE_EXTRACT_CONFIG_MDT 
SET PCI_Data_Generation_Date	= NULL,
    Purged_Date					= NULL,
	Batch_Processed_Date		= NULL	
WHERE Accounting_Week_Num = @Var_FinanceWeek
DELETE DW_Sales_ODS.EDW_DBO.DW_PREPAID_CARD_ISSUE_EXTRACT_DATA WHERE Accounting_Week_Num = @Var_FinanceWeek
;WITH BATCH AS
(
	SELECT Batch_Id
	FROM DW_Metadata.EDW_DBO.DW_PREPAID_CARD_ISSUE_EXTRACT_CONFIG_MDT 
	WHERE Accounting_Week_Num = @Var_FinanceWeek
)
UPDATE MDT
SET MDT.Processed_Date = NULL,
	MDT.Filename = REPLACE(MDT.Filename,'\\hosfence.ho\gendata$','E:\ITOps')
FROM DW_Metadata.EDW_DBO.DW_FILE_CREATION_REQUEST_MDT MDT
INNER JOIN BATCH BAT
ON BAT.Batch_Id = MDT.Batch_Id 
WHERE MDT.Process_Name LIKE '%PCI_%'

UPDATE DW_Metadata.EDW_DBO.DW_REFINANCE_SETTLEMENT_EXTRACT_CONFIG_MDT 
SET RS_Data_Generation_Date		= NULL,
    Batch_Processed_Date		= NULL
WHERE Accounting_Week_Num = @Var_FinanceWeek
DELETE DW_Sales_ODS.EDW_DBO.DW_REFINANCE_SETTLEMENT_EXTRACT_DATA WHERE Accounting_Week_Num = @Var_FinanceWeek
;WITH BATCH AS
(
	SELECT Batch_Id
	FROM DW_Metadata.EDW_DBO.DW_REFINANCE_SETTLEMENT_EXTRACT_CONFIG_MDT 
	WHERE Accounting_Week_Num = @Var_FinanceWeek
)
UPDATE MDT
SET MDT.Processed_Date = NULL,
	MDT.Filename = REPLACE(MDT.Filename,'\\hosfence.ho\gendata$','E:\ITOps')
FROM DW_Metadata.EDW_DBO.DW_FILE_CREATION_REQUEST_MDT MDT
INNER JOIN BATCH BAT
ON BAT.Batch_Id = MDT.Batch_Id 
WHERE MDT.Process_Name LIKE '%RS_%'

UPDATE DW_Metadata.EDW_DBO.DW_OVERPAYMENT_CHQ_EXTRACT_CONFIG_MDT 
SET OC_Data_Generation_Date		= NULL,
    Purged_Date					= NULL,
	Batch_Processed_Date		= NULL	
WHERE Accounting_Week_Num = @Var_FinanceWeek
DELETE DW_Sales_ODS.EDW_DBO.DW_OVERPAYMENT_CHQ_EXTRACT_DATA WHERE Accounting_Week_Num = @Var_FinanceWeek
;WITH BATCH AS
(
	SELECT Batch_Id
	FROM DW_Metadata.EDW_DBO.DW_OVERPAYMENT_CHQ_EXTRACT_CONFIG_MDT 
	WHERE Accounting_Week_Num = @Var_FinanceWeek
)
UPDATE MDT
SET MDT.Processed_Date = NULL,
	MDT.Filename = REPLACE(MDT.Filename,'\\hosfence.ho\gendata$','E:\ITOps')
FROM DW_Metadata.EDW_DBO.DW_FILE_CREATION_REQUEST_MDT MDT
INNER JOIN BATCH BAT
ON BAT.Batch_Id = MDT.Batch_Id 
WHERE MDT.Process_Name LIKE '%OC_%'

UPDATE DW_Metadata.EDW_DBO.DW_OVERPAYMENT_UNCL_EXTRACT_CONFIG_MDT 
SET OU_Data_Generation_Date		= NULL,
    Purged_Date					= NULL,
	Batch_Processed_Date		= NULL	
WHERE Accounting_Week_Num = @Var_FinanceWeek
DELETE DW_Sales_ODS.EDW_DBO.DW_OVERPAYMENT_UNCL_EXTRACT_DATA WHERE Accounting_Week_Num = @Var_FinanceWeek
;WITH BATCH AS
(
	SELECT Batch_Id
	FROM DW_Metadata.EDW_DBO.DW_OVERPAYMENT_UNCL_EXTRACT_CONFIG_MDT 
	WHERE Accounting_Week_Num = @Var_FinanceWeek
)
UPDATE MDT
SET MDT.Processed_Date = NULL,
	MDT.Filename = REPLACE(MDT.Filename,'\\hosfence.ho\gendata$','E:\ITOps')
FROM DW_Metadata.EDW_DBO.DW_FILE_CREATION_REQUEST_MDT MDT
INNER JOIN BATCH BAT
ON BAT.Batch_Id = MDT.Batch_Id 
WHERE MDT.Process_Name LIKE '%OU_%'

UPDATE DW_Metadata.EDW_DBO.DW_ETL_LOAD_PROCESS_MDT 
SET Active_Record_Bln	= 1,
	Current_Stage		= NULL 
WHERE Process_Id = 7 
AND Load_Id = @Var_CodaLoadId

UPDATE DW_Metadata.EDW_DBO.DW_ETL_LOAD_PROCESS_MDT 
SET Active_Record_Bln	= 1,
	Current_Stage		= NULL 
WHERE Process_Id = 8 
AND Load_Id = @BankRecLoadId

UPDATE DW_Metadata.EDW_DBO.DW_ETL_LOAD_PROCESS_MDT 
SET Active_Record_Bln	= 1,
	Current_Stage		= NULL 
WHERE Process_Id = 9 
AND Load_Id = @Var_ReportsLoadId

UPDATE DW_Metadata.EDW_DBO.DW_ETL_SUBPROCESS_MDT 
SET Last_Load_Id = 0
WHERE Process_Id IN (7,8,9)

DELETE DW_Metadata.EDW_DBO.DW_ETL_FILECREATE_MDT WHERE Process_Id = 7 AND Load_Id = @Var_CodaLoadId
DELETE DW_Metadata.EDW_DBO.DW_ETL_FILECREATE_MDT WHERE Process_Id = 8 AND Load_Id = @BankRecLoadId
DELETE DW_Metadata.EDW_DBO.DW_ETL_FILECREATE_MDT WHERE Process_Id = 9 AND Load_Id = @Var_ReportsLoadId

SELECT 'Data deletion/clear down End' Info

--ROLLBACK TRAN