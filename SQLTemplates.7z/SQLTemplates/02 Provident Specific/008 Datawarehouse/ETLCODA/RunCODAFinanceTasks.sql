SET NOCOUNT ON;

DECLARE @Var_SQLCMD				NVARCHAR(3000),
		@Var_ExecutionStatus	INTEGER,
		@Var_FinanceWeek		INTEGER,
		@Var_CodaLoadId			INTEGER,
		@BankRecLoadId			INTEGER,
		@Var_ReportsLoadId		INTEGER


--Get code for fetch load id and week number to clear down
SELECT @Var_FinanceWeek = MAX(Accounting_Week_Num)
FROM DW_Metadata.EDW_DBO.DW_ETL_WEEKLY_PROCESS_MDT
WHERE Bankrec_Load_Id IS NOT NULL 
AND Coda_Load_Id IS NOT NULL
AND Reports_Load_Id IS NOT NULL

SELECT	@BankRecLoadId	= Bankrec_Load_Id,
		@Var_CodaLoadId		= Coda_Load_Id,
		@Var_ReportsLoadId	= Reports_Load_Id 
FROM DW_Metadata.EDW_DBO.DW_ETL_WEEKLY_PROCESS_MDT
WHERE Accounting_Week_Num = @Var_FinanceWeek

SELECT 'Processing following load ids and week' Info 
SELECT @Var_FinanceWeek FinanceWeek, @BankRecLoadId BankRecLoadId, @Var_CodaLoadId CodaLoadId, @Var_ReportsLoadId ReportsLoadId

-- Perform AM association table rebuild by calling SP directly to avoid triggering attempt for new accounting week data
SELECT 'Getting Rep AM Data' Info
EXEC DW_Reference.EDW_DBO.DWP_DW_NFS_REPRESENTATIVE_AM_ASSOCIATION_REF 1,1,1,@Var_FinanceWeek

-- Perform Prepaid Card extract
SELECT 'Performing PCI process' Info
EXEC DW_Metadata.EDW_DBO.DWP_INITIATE_PCI_EXTRACT_DATA
EXEC DW_Sales_ODS.EDW_DBO.DWP_GENERATE_PCI_EXTRACT_DATA

SET @Var_SQLCMD = 'DTEXEC /DTS "\MSDB\Generic\Generic_File_Creator" /SERVER RSTMIKADO /MAXCONCURRENT " -1 " /CHECKPOINTING OFF  /REPORTING V /SET "\Package.variables[User::ProcessName].Properties[Value]";"PCI_PPC" > E:\ITOps\Generic_PCI_PPC.txt'
EXEC @Var_ExecutionStatus = master..xp_cmdshell @Var_SQLCMD
IF @Var_ExecutionStatus <> 0 OR @Var_ExecutionStatus IS NULL 
BEGIN
	RAISERROR('Cannot kick off PCI PPC',16,1)
END

SET @Var_SQLCMD = 'DTEXEC /DTS "\MSDB\Generic\Generic_File_Creator" /SERVER RSTMIKADO /MAXCONCURRENT " -1 " /CHECKPOINTING OFF  /REPORTING V /SET "\Package.variables[User::ProcessName].Properties[Value]";"PCI_GPC" > E:\ITOps\Generic_PCI_GPC.txt'
EXEC @Var_ExecutionStatus = master..xp_cmdshell @Var_SQLCMD
IF @Var_ExecutionStatus <> 0 OR @Var_ExecutionStatus IS NULL 
BEGIN
	RAISERROR('Cannot kick off PCI GPC',16,1)
END

SET @Var_SQLCMD = 'DTEXEC /DTS "\MSDB\Generic\Generic_File_Creator" /SERVER RSTMIKADO /MAXCONCURRENT " -1 " /CHECKPOINTING OFF  /REPORTING V /SET "\Package.variables[User::ProcessName].Properties[Value]";"PCI_ROI" > E:\ITOps\Generic_PCI_ROI.txt'
EXEC @Var_ExecutionStatus = master..xp_cmdshell @Var_SQLCMD
IF @Var_ExecutionStatus <> 0 OR @Var_ExecutionStatus IS NULL 
BEGIN
	RAISERROR('Cannot kick off PCI ROI',16,1)
END

EXEC DW_Sales_ODS.EDW_DBO.DWP_PURGE_PCI_EXTRACT_DATA
EXEC DW_Metadata.EDW_DBO.DWP_COMPLETE_PCI_EXTRACT_DATA

-- Perform Refinance settlement extract
SELECT 'Performing Refinance' Info
EXEC DW_Metadata.EDW_DBO.DWP_INITIATE_RS_EXTRACT_DATA
EXEC DW_Sales_ODS.EDW_DBO.DWP_GENERATE_RS_EXTRACT_DATA

SET @Var_SQLCMD = 'DTEXEC /DTS "\MSDB\Generic\Generic_File_Creator" /SERVER RSTMIKADO /MAXCONCURRENT " -1 " /CHECKPOINTING OFF  /REPORTING V /SET "\Package.variables[User::ProcessName].Properties[Value]";"RS_PPC" > E:\ITOps\Generic_RS_PPC.txt'
EXEC @Var_ExecutionStatus = master..xp_cmdshell @Var_SQLCMD
IF @Var_ExecutionStatus <> 0 OR @Var_ExecutionStatus IS NULL 
BEGIN
	RAISERROR('Cannot kick off RS PPC',16,1)
END

SET @Var_SQLCMD = 'DTEXEC /DTS "\MSDB\Generic\Generic_File_Creator" /SERVER RSTMIKADO /MAXCONCURRENT " -1 " /CHECKPOINTING OFF  /REPORTING V /SET "\Package.variables[User::ProcessName].Properties[Value]";"RS_GPC" > E:\ITOps\Generic_RS_GPC.txt'
EXEC @Var_ExecutionStatus = master..xp_cmdshell @Var_SQLCMD
IF @Var_ExecutionStatus <> 0 OR @Var_ExecutionStatus IS NULL 
BEGIN
	RAISERROR('Cannot kick off RS GPC',16,1)
END

SET @Var_SQLCMD = 'DTEXEC /DTS "\MSDB\Generic\Generic_File_Creator" /SERVER RSTMIKADO /MAXCONCURRENT " -1 " /CHECKPOINTING OFF  /REPORTING V /SET "\Package.variables[User::ProcessName].Properties[Value]";"RS_ROI" > E:\ITOps\Generic_RS_ROI.txt'
EXEC @Var_ExecutionStatus = master..xp_cmdshell @Var_SQLCMD
IF @Var_ExecutionStatus <> 0 OR @Var_ExecutionStatus IS NULL 
BEGIN
	RAISERROR('Cannot kick off RS ROI',16,1)
END

EXEC DW_Sales_ODS.EDW_DBO.DWP_PURGE_RS_EXTRACT_DATA
EXEC DW_Metadata.EDW_DBO.DWP_COMPLETE_RS_EXTRACT_DATA

-- Overpayment Cheques
SELECT 'Performing Overpayment Cheques' Info
EXEC DW_Metadata.EDW_DBO.DWP_INITIATE_OC_EXTRACT_DATA
EXEC DW_Sales_ODS.EDW_DBO.DWP_GENERATE_OC_EXTRACT_DATA

SET @Var_SQLCMD = 'DTEXEC /DTS "\MSDB\Generic\Generic_File_Creator" /SERVER RSTMIKADO /MAXCONCURRENT " -1 " /CHECKPOINTING OFF  /REPORTING V /SET "\Package.variables[User::ProcessName].Properties[Value]";"OC_PPC" > E:\ITOps\Generic_OC_PPC.txt'
EXEC @Var_ExecutionStatus = master..xp_cmdshell @Var_SQLCMD
IF @Var_ExecutionStatus <> 0 OR @Var_ExecutionStatus IS NULL 
BEGIN
	RAISERROR('Cannot kick off OC PPC',16,1)
END

SET @Var_SQLCMD = 'DTEXEC /DTS "\MSDB\Generic\Generic_File_Creator" /SERVER RSTMIKADO /MAXCONCURRENT " -1 " /CHECKPOINTING OFF  /REPORTING V /SET "\Package.variables[User::ProcessName].Properties[Value]";"OC_GPC" > E:\ITOps\Generic_OC_GPC.txt'
EXEC @Var_ExecutionStatus = master..xp_cmdshell @Var_SQLCMD
IF @Var_ExecutionStatus <> 0 OR @Var_ExecutionStatus IS NULL 
BEGIN
	RAISERROR('Cannot kick off OC GPC',16,1)
END

EXEC DW_Sales_ODS.EDW_DBO.DWP_PURGE_OC_EXTRACT_DATA
EXEC DW_Metadata.EDW_DBO.DWP_COMPLETE_OC_EXTRACT_DATA

-- Overpayment Unclaimed
SELECT 'Performing Overpayment Unclained' Info
EXEC DW_Metadata.EDW_DBO.DWP_INITIATE_OU_EXTRACT_DATA
EXEC DW_Sales_ODS.EDW_DBO.DWP_GENERATE_OU_EXTRACT_DATA

SET @Var_SQLCMD = 'DTEXEC /DTS "\MSDB\Generic\Generic_File_Creator" /SERVER RSTMIKADO /MAXCONCURRENT " -1 " /CHECKPOINTING OFF  /REPORTING V /SET "\Package.variables[User::ProcessName].Properties[Value]";"OU_PPC" > E:\ITOps\Generic_OU_PPC.txt'
EXEC @Var_ExecutionStatus = master..xp_cmdshell @Var_SQLCMD
IF @Var_ExecutionStatus <> 0 OR @Var_ExecutionStatus IS NULL 
BEGIN
	RAISERROR('Cannot kick off OU PPC',16,1)
END

SET @Var_SQLCMD = 'DTEXEC /DTS "\MSDB\Generic\Generic_File_Creator" /SERVER RSTMIKADO /MAXCONCURRENT " -1 " /CHECKPOINTING OFF  /REPORTING V /SET "\Package.variables[User::ProcessName].Properties[Value]";"OU_GPC" > E:\ITOps\Generic_OU_GPC.txt'
EXEC @Var_ExecutionStatus = master..xp_cmdshell @Var_SQLCMD
IF @Var_ExecutionStatus <> 0 OR @Var_ExecutionStatus IS NULL 
BEGIN
	RAISERROR('Cannot kick off OU GPC',16,1)
END

EXEC DW_Sales_ODS.EDW_DBO.DWP_PURGE_OU_EXTRACT_DATA
EXEC DW_Metadata.EDW_DBO.DWP_COMPLETE_OU_EXTRACT_DATA

-- Finally run CODA/Finance extract
--**Paul Run this from MSDB!!!**
--SELECT 'Performing Main Coda Finance Run' Info
--SET @Var_SQLCMD = 'DTEXEC /DTS "\MSDB\Finance\Weekly_Extract_Generate" /SERVER RSTMIKADO /MAXCONCURRENT " -1 " /CHECKPOINTING OFF  /REPORTING V > E:\ITOps\CODAFinanceExtractMain.txt'
--EXEC @Var_ExecutionStatus = master..xp_cmdshell @Var_SQLCMD
--IF @Var_ExecutionStatus <> 0 OR @Var_ExecutionStatus IS NULL 
--BEGIN
--	RAISERROR('Cannot kick off main CODA Finance Extract',16,1)
--END
--PRINT 'Even if the CODA Finance reports failure, still check run configs [DW_ETL_LOAD_PROCESS_MDT] for most recent Process Id 7/8/9'



