--***************************************************************************
--* Magic Incident Num   : 
--*
--* Date Implemented     : dd/mm/yyyy
--*
--* Script Description   : Initialise the Pre-Production Data Warehouse NAME-VALUE configuration tables.
--*    
--* Additional Comments  : This data patch should first be run in rollback mode (default setting), and then commit mode once the results are judged to be satisfactory.
--*						   
--*
--* Review      Ver      Author             Date           Remarks      
--* ----------------------------------------------------------------------------------------------------
--* 			001      A Kombilath        07/08/2015     Original 
--* 
--***************************************************************************
use dw_compliance_mart

BEGIN

	DECLARE @COMMIT_MODE EDW_DBO.T_NUMBER
	
	SET @COMMIT_MODE = 0 -- Change to 1 (COMMIT TRANSACTION) once satisfied with the rollback results.

	BEGIN TRY
		BEGIN TRAN
			/************************************************************
			[DW_Compliance_Mart].[EDW_DBO].[DM_PAYMENT_CARD_NAMEVALUE_CONFIG]
			************************************************************/
			SELECT 'B - [DM_PAYMENT_CARD_NAMEVALUE_CONFIG]',* FROM [DW_Compliance_Mart].[EDW_DBO].[DM_PAYMENT_CARD_NAMEVALUE_CONFIG]

			UPDATE [DW_Compliance_Mart].[EDW_DBO].[DM_PAYMENT_CARD_NAMEVALUE_CONFIG]
			SET VALUE = REPLACE(VALUE,'RSSSHADOW.RS\LANDS','RSDEVDW02')
			WHERE VALUE = 'RSSSHADOW.RS\LANDS'

			UPDATE [DW_Compliance_Mart].[EDW_DBO].[DM_PAYMENT_CARD_NAMEVALUE_CONFIG]
			SET VALUE = REPLACE(VALUE,'\\rssshadow.rs\e$','\\RSDEVDW02\e$')
			WHERE VALUE LIKE('\\rssshadow\e$%')

			UPDATE [DW_Compliance_Mart].[EDW_DBO].[DM_PAYMENT_CARD_NAMEVALUE_CONFIG]
			SET VALUE = REPLACE(VALUE,'\\rsdshaker\e$','\\RSDEVDW02\e$')
			WHERE VALUE LIKE('\\rsdshaker\e$%')
			
			SELECT 'A - [DM_PAYMENT_CARD_NAMEVALUE_CONFIG]',* FROM [DW_Compliance_Mart].[EDW_DBO].[DM_PAYMENT_CARD_NAMEVALUE_CONFIG]

		IF @COMMIT_MODE != 1
			ROLLBACK TRAN
		ELSE
			COMMIT TRAN
		
			/************************************************************
			[DW_Compliance_Mart].[EDW_DBO].[DM_STATEMENT_NAMEVALUE_CONFIG]
			************************************************************/
		BEGIN TRAN
			SELECT 'B - [DM_STATEMENT_NAMEVALUE_CONFIG]',* FROM [DW_Compliance_Mart].[EDW_DBO].[DM_STATEMENT_NAMEVALUE_CONFIG]

			UPDATE [DW_Compliance_Mart].[EDW_DBO].[DM_STATEMENT_NAMEVALUE_CONFIG]
			SET VALUE = REPLACE(VALUE,'RSSSHADOW.RS\LANDS','RSDEVDW02')
			WHERE VALUE = 'RSSSHADOW.RS\LANDS'

			UPDATE [DW_Compliance_Mart].[EDW_DBO].[DM_STATEMENT_NAMEVALUE_CONFIG]
			SET VALUE = REPLACE(VALUE,'RSSSHADOW\LANDS','RSDEVDW02')
			WHERE VALUE = 'RSSSHADOW\LANDS'

			UPDATE [DW_Compliance_Mart].[EDW_DBO].[DM_STATEMENT_NAMEVALUE_CONFIG]
			SET VALUE = REPLACE(VALUE,'\\rssshadow.rs\e$','\\RSDEVDW02\e$')
			WHERE VALUE LIKE('\\rssshadow.rs\e$%')

			UPDATE [DW_Compliance_Mart].[EDW_DBO].[DM_STATEMENT_NAMEVALUE_CONFIG]
			SET VALUE = REPLACE(VALUE,'\\rsdshaker\e$','\\RSDEVDW02\e$')
			WHERE VALUE LIKE('\\rsdshaker\e$%')
			
			-- AKK- 06/08/2015
			-- deactivate email ids. 
			UPDATE [DW_Compliance_Mart].[EDW_DBO].[DM_STATEMENT_NAMEVALUE_CONFIG]
			SET VALUE = REPLACE(VALUE,'@','XXX@')
			WHERE VALUE LIKE('%@%')
			
			UPDATE [DW_Compliance_Mart].[EDW_DBO].[DM_STATEMENT_NAMEVALUE_CONFIG]
			SET VALUE = REPLACE(VALUE,'HOSFENCE.HO','<ServerName>.<DomainName>')
			WHERE VALUE LIKE '%HOSFENCE.HO%'

			SELECT 'A - [DM_STATEMENT_NAMEVALUE_CONFIG]',* FROM [DW_Compliance_Mart].[EDW_DBO].[DM_STATEMENT_NAMEVALUE_CONFIG]
		
		IF @COMMIT_MODE != 1
			ROLLBACK TRAN
		ELSE
			COMMIT TRAN

			/************************************************************
			[DW_EDW].[EDW_DBO].[DM_CAIS_NAMEVALUE_CONFIG]
			************************************************************/
		BEGIN TRAN
			SELECT 'B - [DM_CAIS_NAMEVALUE_CONFIG]',* FROM [DW_EDW].[EDW_DBO].[DM_CAIS_NAMEVALUE_CONFIG]

			UPDATE [DW_EDW].[EDW_DBO].[DM_CAIS_NAMEVALUE_CONFIG]
			SET VALUE = REPLACE(VALUE,'RSSSHADOW.RS\LANDS','RSDEVDW02')
			WHERE VALUE = 'RSSSHADOW.RS\LANDS'

			UPDATE [DW_EDW].[EDW_DBO].[DM_CAIS_NAMEVALUE_CONFIG]
			SET VALUE = REPLACE(VALUE,'\\rssshadow\e$','\\RSDEVDW02\e$')
			WHERE VALUE LIKE('\\rssshadow\e$%')

			SELECT 'A - [DM_CAIS_NAMEVALUE_CONFIG]',* FROM [DW_EDW].[EDW_DBO].[DM_CAIS_NAMEVALUE_CONFIG]

		IF @COMMIT_MODE != 1
			ROLLBACK TRAN
		ELSE
			COMMIT TRAN

		-- COMMIT TRAN

			/************************************************************
			[DW_Staging].[EDW_DBO].[DW_ETL_NAMEVALUE_CONFIG]
			************************************************************/
		BEGIN TRAN
			SELECT 'B - [DW_ETL_NAMEVALUE_CONFIG]',* FROM [DW_Staging].[EDW_DBO].[DW_ETL_NAMEVALUE_CONFIG]

			UPDATE [DW_Staging].[EDW_DBO].[DW_ETL_NAMEVALUE_CONFIG]
			SET VALUE = REPLACE(VALUE,'RSSSHADOW.RS\LANDS','RSDEVDW02')
			WHERE VALUE = 'RSSSHADOW.RS\LANDS'

			UPDATE [DW_Staging].[EDW_DBO].[DW_ETL_NAMEVALUE_CONFIG]
			SET VALUE = REPLACE(VALUE,'RSSSHADOW\LANDS','RSDEVDW02')
			WHERE VALUE = 'RSSSHADOW\LANDS'

			UPDATE [DW_Staging].[EDW_DBO].[DW_ETL_NAMEVALUE_CONFIG]
			SET VALUE = REPLACE(VALUE,'\\rssshadow\e$','\\RSDEVDW02\e$')
			WHERE VALUE LIKE('\\rssshadow\e$%')

			UPDATE [DW_Staging].[EDW_DBO].[DW_ETL_NAMEVALUE_CONFIG]
			SET VALUE = REPLACE(VALUE,'\\RSSPETAL\E$\ITOps','\\RSDEVDW03\E$\ITOps')
			WHERE VALUE LIKE('\\RSSPETAL\E$\ITOps%')

			UPDATE [DW_Staging].[EDW_DBO].[DW_ETL_NAMEVALUE_CONFIG]
			SET VALUE = REPLACE(VALUE,'\\RSDSHAKER\E$\ITOps','\\RSDEVDW02\E$\ITOps')
			WHERE VALUE LIKE('\\RSDSHAKER\E$\ITOps%')
			
			SELECT 'A - [DW_ETL_NAMEVALUE_CONFIG]',* FROM [DW_Staging].[EDW_DBO].[DW_ETL_NAMEVALUE_CONFIG]

		IF @COMMIT_MODE != 1
			ROLLBACK TRAN
		ELSE
			COMMIT TRAN
	
			/************************************************************
			[DW_Metadata].[EDW_DBO].[SSIS_CONFIG]
			************************************************************/
		BEGIN TRAN
			SELECT 'B - [SSIS_CONFIG]',* FROM [DW_Metadata].[EDW_DBO].[SSIS_CONFIG]
			
			UPDATE [DW_Metadata].[EDW_DBO].[SSIS_CONFIG]
			SET CONFIGUREDVALUE = REPLACE(CONFIGUREDVALUE,'RSSSHADOW.RS\LANDS','RSDEVDW02')
			WHERE CONFIGUREDVALUE LIKE '%RSSSHADOW.RS\LANDS%'
			
			UPDATE [DW_Metadata].[EDW_DBO].[SSIS_CONFIG]
			SET CONFIGUREDVALUE = REPLACE(CONFIGUREDVALUE,'RSSPETAL.RS\ROSE','RSDEVDW03.RS\ROSE')
			WHERE CONFIGUREDVALUE LIKE '%RSSPETAL.RS\ROSE%'

			UPDATE [DW_Metadata].[EDW_DBO].[SSIS_CONFIG]
			SET CONFIGUREDVALUE = REPLACE(CONFIGUREDVALUE,'\\RSDSHAKER\E$','\\RSDEVDW02\E$')
			WHERE CONFIGUREDVALUE LIKE '\\RSDSHAKER\E$%'
		
			SELECT 'A - [SSIS_CONFIG]',* FROM [DW_Metadata].[EDW_DBO].[SSIS_CONFIG]

			-- AKK- 06/08/2015
			/************************************************************
			[DW_Metadata].[EDW_DBO].DW_ETL_NAMEVALUE_MDT
			************************************************************/
			SELECT 'B - [DW_ETL_NAMEVALUE_MDT]',* FROM [DW_Metadata].[EDW_DBO].[DW_ETL_NAMEVALUE_MDT]
							
			UPDATE [DW_Metadata].[EDW_DBO].[DW_ETL_NAMEVALUE_MDT]
			SET VALUE = REPLACE(VALUE,'HOSFENCE.HO','<ServerName>.<DomainName>')
			WHERE VALUE LIKE '%HOSFENCE.HO%'
			
			UPDATE [DW_Metadata].[EDW_DBO].[DW_ETL_NAMEVALUE_MDT]
			SET VALUE = REPLACE(VALUE,'HOSFENCE','<ServerName>')
			WHERE VALUE LIKE '%HOSFENCE%'
			
			UPDATE [DW_Metadata].[EDW_DBO].[DW_ETL_NAMEVALUE_MDT]
			SET VALUE = REPLACE(VALUE,'http://172.30.20.15/Reportserver','<ReportServerURL>/Reportserver')
			WHERE VALUE LIKE '%http://172.30.20.15/Reportserver%'
			
			UPDATE [DW_Metadata].[EDW_DBO].[DW_ETL_NAMEVALUE_MDT]
			SET VALUE = REPLACE(VALUE,'\\rssshadow\e$','\\RSDEVDW02\e$')
			WHERE VALUE LIKE('\\rssshadow\e$%')

			UPDATE [DW_Metadata].[EDW_DBO].[DW_ETL_NAMEVALUE_MDT]
			SET VALUE = REPLACE(VALUE,'\\rsdshaker\e$','\\RSDEVDW02\e$')
			WHERE VALUE LIKE('\\rsdshaker\e$%')
						-- deactivate email ids. 
			UPDATE [DW_Metadata].[EDW_DBO].[DW_ETL_NAMEVALUE_MDT]
			SET VALUE = REPLACE(VALUE,'@','XXX@')
			WHERE VALUE LIKE('%@%')
			
			UPDATE [DW_Metadata].[EDW_DBO].[DW_ETL_NAMEVALUE_MDT]
			SET VALUE = REPLACE(VALUE,'RSSSHADOW\LANDS','RSDEVDW02')
			WHERE VALUE = 'RSSSHADOW\LANDS'

			UPDATE DW_Metadata.EDW_DBO.DW_ETL_NAMEVALUE_MDT
			SET Value = 'http://hossnake/reportserver_boa'
			WHERE Name = 'REPORT_SERVER_URL' 
			
			SELECT 'A - [DW_ETL_NAMEVALUE_MDT]',* FROM [DW_Metadata].[EDW_DBO].[DW_ETL_NAMEVALUE_MDT]

			SELECT 'Updating namevalues Start' Info 
UPDATE DW_Metadata.EDW_DBO.DW_ETL_NAMEVALUE_MDT
SET Value = '\\rsdevdw02\e$\ITOps\Datawarehouse\CODA\'
WHERE Name = 'CODA_FILE_DESTINATION_LOCATION'  

UPDATE DW_Metadata.EDW_DBO.DW_ETL_NAMEVALUE_MDT
SET Value = '\\rsdevdw02\e$\ITOps\Datawarehouse\BANKREC\GPC\'
WHERE Name = 'BANKREC_GPC_EXTRACT_DESTINATION_LOCATION'  

UPDATE DW_Metadata.EDW_DBO.DW_ETL_NAMEVALUE_MDT
SET Value = '\\rsdevdw02\e$\ITOps\Datawarehouse\BANKREC\PPC\'
WHERE Name = 'BANKREC_PPC_EXTRACT_DESTINATION_LOCATION'  

UPDATE DW_Metadata.EDW_DBO.DW_ETL_NAMEVALUE_MDT
SET Value = '\\rsdevdw02\e$\ITOps\Datawarehouse\BANKREC\ROI\'
WHERE Name = 'BANKREC_ROI_EXTRACT_DESTINATION_LOCATION'  

UPDATE DW_Metadata.EDW_DBO.DW_ETL_NAMEVALUE_MDT
SET Value = '\\rsdevdw02\e$\ITOps\Datawarehouse\BANKREC\'
WHERE Name = 'BANKREC_OTHER_EXTRACT_DESTINATION_LOCATION'  

UPDATE DW_Metadata.EDW_DBO.DW_ETL_NAMEVALUE_MDT
SET Value = 'http://hossnake/reportserver_boa'
WHERE Name = 'REPORT_SERVER_URL'  

UPDATE DW_Metadata.EDW_DBO.DW_ETL_NAMEVALUE_MDT
SET Value = '\\rsdevdw02\e$\ITOps\Datawarehouse\REPORTS\ISSUES\'
WHERE Name = 'ISSUE_ANALYSIS_REPORTS_DESTINATION_LOCATION'  

UPDATE DW_Metadata.EDW_DBO.DW_ETL_NAMEVALUE_MDT
SET Value = '\\rsdevdw02\e$\ITOps\Datawarehouse\REPORTS\ARREARS\'
WHERE Name = 'ARREARS_PROVISION_REPORTS_DESTINATION_LOCATION'  

UPDATE DW_Metadata.EDW_DBO.DW_ETL_NAMEVALUE_MDT
SET Value = '\\rsdevdw02\e$\ITOps\Datawarehouse\REPORTS\BALANCE\'
WHERE Name = 'BALANCING_REPORTS_DESTINATION_LOCATION'  

UPDATE DW_Metadata.EDW_DBO.DW_ETL_NAMEVALUE_MDT
SET Value = '\\rsdevdw02\e$\ITOps\Datawarehouse\REPORTS\Other_Payment_And_Receipts\'
WHERE Name = 'OTHER_REPORTS_DESTINATION_LOCATION'  

UPDATE DW_Metadata.EDW_DBO.DW_ETL_NAMEVALUE_MDT
SET Value = 'RSTMikado\YumYum'
WHERE Name = 'FILE_MANAGEMENT_DB_SERVER'  

UPDATE DW_Metadata.EDW_DBO.DW_ETL_NAMEVALUE_MDT
SET Value = '\\rsdevdw02\e$\ITOps\Datawarehouse\BANKREC\PPC\'
WHERE Name = 'PCI_PPC_EXTRACT_LOCATION'  

UPDATE DW_Metadata.EDW_DBO.DW_ETL_NAMEVALUE_MDT
SET Value = '\\rsdevdw02\e$\ITOps\Datawarehouse\BANKREC\GPC\'
WHERE Name = 'PCI_GPC_EXTRACT_LOCATION'  

UPDATE DW_Metadata.EDW_DBO.DW_ETL_NAMEVALUE_MDT
SET Value = '\\rsdevdw02\e$\ITOps\Datawarehouse\BANKREC\ROI\'
WHERE Name = 'PCI_ROI_EXTRACT_LOCATION'  

UPDATE DW_Metadata.EDW_DBO.DW_ETL_NAMEVALUE_MDT
SET Value = '\\rsdevdw02\e$\ITOps\Datawarehouse\BANKREC\PPC\'
WHERE Name = 'RS_PPC_EXTRACT_LOCATION'  

UPDATE DW_Metadata.EDW_DBO.DW_ETL_NAMEVALUE_MDT
SET Value = '\\rsdevdw02\e$\ITOps\Datawarehouse\BANKREC\GPC\'
WHERE Name = 'RS_GPC_EXTRACT_LOCATION'  

UPDATE DW_Metadata.EDW_DBO.DW_ETL_NAMEVALUE_MDT
SET Value = '\\rsdevdw02\e$\ITOps\Datawarehouse\BANKREC\ROI\'
WHERE Name = 'RS_ROI_EXTRACT_LOCATION'  

UPDATE DW_Metadata.EDW_DBO.DW_ETL_NAMEVALUE_MDT
SET Value = '\\rsdevdw02\e$\ITOps\Datawarehouse\BANKREC\PPC\'
WHERE Name = 'RP_PPC_EXTRACT_LOCATION'  

UPDATE DW_Metadata.EDW_DBO.DW_ETL_NAMEVALUE_MDT
SET Value = '\\rsdevdw02\e$\ITOps\Datawarehouse\BANKREC\ROI\'
WHERE Name = 'RP_ROI_EXTRACT_LOCATION'  

UPDATE DW_Metadata.EDW_DBO.DW_ETL_NAMEVALUE_MDT
SET Value = '\\rsdevdw02\e$\ITOps\Datawarehouse\BANKREC\PPC\'
WHERE Name = 'OC_PPC_EXTRACT_LOCATION'  

UPDATE DW_Metadata.EDW_DBO.DW_ETL_NAMEVALUE_MDT
SET Value = '\\rsdevdw02\e$\ITOps\Datawarehouse\BANKREC\PPC\'
WHERE Name = 'OU_PPC_EXTRACT_LOCATION'  

UPDATE DW_Metadata.EDW_DBO.DW_ETL_NAMEVALUE_MDT
SET Value = '\\rsdevdw02\e$\ITOps\Datawarehouse\BANKREC\GPC\'
WHERE Name = 'OC_GPC_EXTRACT_LOCATION'  

UPDATE DW_Metadata.EDW_DBO.DW_ETL_NAMEVALUE_MDT
SET Value = '\\rsdevdw02\e$\ITOps\Datawarehouse\BANKREC\GPC\'
WHERE Name = 'OU_GPC_EXTRACT_LOCATION'  

SELECT 'Updating namevalues End' Info 
	
		IF @COMMIT_MODE != 1
			ROLLBACK TRAN
		ELSE
			COMMIT TRAN

	END TRY
	BEGIN CATCH
		SELECT 'Unsuccessful: Rolling Back Database Changes...' AS Status
		ROLLBACK TRAN

		SELECT ERROR_NUMBER() AS ErrorNumber,ERROR_MESSAGE() AS ErrorMessage;
	END CATCH
END
