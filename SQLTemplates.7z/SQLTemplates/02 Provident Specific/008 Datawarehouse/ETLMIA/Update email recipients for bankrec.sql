/*Connect to HOSSNAKE\ADDER*/

use systemcontrol
select u.useremail useremail, ec.recipienttype rectype,sy.systemname,ed.emailreason
from dbo.emaildefinition ed
    join dbo.[system] sy
    on ed.systemid = sy.systemid
    join dbo.emailcontrol ec
    on ec.definitionid = ed.definitionid
    join dbo.systemuser u
    on u.userid = ec.userid
where systemname = 'bankrec'
--where sy.systemname = ?
--and ed.emailreason = ?

/*Connect to hossnake\adder*/
--insert into dbo.emaildefinition
--values('bankrec.notification@provident.co.uk'
