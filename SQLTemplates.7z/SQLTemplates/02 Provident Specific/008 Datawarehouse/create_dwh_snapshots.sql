--******DECLARE VARIABLES**********************************************************
 
DECLARE @CurrDatabase varchar(50),@Database varchar(50),@LogicalFile varchar(250)
DECLARE @PhysicalFile varchar(250),@Qry nvarchar(2000),@Snapshot varchar(250)
DECLARE @DBFiles TABLE (LogicalFile varchar(250),PhysicalFile varchar(512))
DECLARE @Databases TABLE (DatabaseName varchar(50))
DECLARE @Snapshots TABLE (source_database_id tinyint,name varchar(100),Date datetime)
 
SET NOCOUNT ON
--*********************************************************************************
--*********************************************************************************
BEGIN TRY
 
      SET @Qry =''
      SET @Snapshot=''
      SET @Database=''
      SET @CurrDatabase=''
      --*********************************************************************************
      --*********************************************************************************
      INSERT @Snapshots 
      SELECT 
            source_database_id,
            Name,
            create_date
      FROM
            sys.databases
      WHERE
            source_database_id IS NOT NULL
      ORDER BY create_date ASC      
      --*********************************************************************************
      --*********************************************************************************
      INSERT @Databases
      SELECT name 
      FROM sys.databases
      WHERE name IN ('DW_Statement_Viewer','DW_Statement_Mart','DW_Staging','DW_Compliance_Mart','DW_EDW','DW_Sales_ODS','DW_Reference','DW_Staging','DW_Metadata','File_Management')--ADD DATABASES REQUIRED TO LIST
      --********************************************************************************
      --********************************************************************************
      WHILE EXISTS (SELECT 1 FROM @Databases)
            BEGIN
                  SELECT @Currdatabase=DatabaseName FROM @Databases
                  SET @Snapshot=@CurrDatabase + '_SNAPSHOT%'
                  WHILE (SELECT COUNT(*) FROM @Snapshots WHERE name LIKE (@Snapshot)) >1
                        BEGIN
                              SET @Database=(SELECT TOP 1 name FROM @Snapshots WHERE name LIKE (@Snapshot))
                              SET @Qry='DROP DATABASE ['+ @Database +']'
                              EXECUTE (@Qry) 
                              DELETE @Snapshots WHERE name=@Database 
                        END 
                  SET @Qry=''
                  SET @Qry='SELECT name,Physical_name FROM ' + @CurrDatabase + '.sys.database_files WHERE type<>1 ORDER BY data_space_id'
                  INSERT INTO @DBFiles
                  EXEC (@Qry)
                  SET @Qry=''
                  SET @Qry=@Qry + 'CREATE DATABASE [' + @CurrDatabase + '_SNAPSHOT_' + REPLACE(REPLACE(REPLACE(CONVERT(VARCHAR,GETDATE(),120),'-',''),':',''),' ','_') + '] ON '
                  WHILE EXISTS(SELECT 1 FROM @DBFiles)
                        BEGIN
                              SELECT @LogicalFile=LogicalFile, @PhysicalFile=PhysicalFile FROM @DBFiles
                              IF (SELECT COUNT(*) FROM @DBFiles)>1
                                    SET @Qry=@Qry + '(NAME = N''' + @LogicalFile + ''', FILENAME = N''' + LEFT(@PhysicalFile,CHARINDEX(RIGHT(@PhysicalFile,4),@PhysicalFile)-1) + '_' + REPLACE(CONVERT(VARCHAR,GETDATE()),' ','') + '.ss''),'
                              ELSE
                                    SET @Qry=@Qry + '(NAME = N''' + @LogicalFile + ''', FILENAME = N''' + LEFT(@PhysicalFile,CHARINDEX(RIGHT(@PhysicalFile,4),@PhysicalFile)-1) + '_' + REPLACE(CONVERT(VARCHAR,GETDATE()),' ','') + '.ss'')'
                              DELETE @DBFiles WHERE LogicalFile=@LogicalFile 
                              AND PhysicalFile=@PhysicalFile
                        END
                  SET @Qry=@Qry + ' AS SNAPSHOT OF ' + @CurrDatabase
                  EXECUTE (@Qry)
                  DELETE @Databases WHERE DatabaseName=@Currdatabase
            END
END TRY
BEGIN CATCH
       SELECT 
        ERROR_NUMBER() AS ErrorNumber
        ,ERROR_SEVERITY() AS ErrorSeverity
        ,ERROR_STATE() AS ErrorState
        ,ERROR_LINE () AS ErrorLine
        ,ERROR_PROCEDURE() AS ErrorProcedure
        ,ERROR_MESSAGE() AS ErrorMessage;
END CATCH
--********************************************************************************
--********************************************************************************
 