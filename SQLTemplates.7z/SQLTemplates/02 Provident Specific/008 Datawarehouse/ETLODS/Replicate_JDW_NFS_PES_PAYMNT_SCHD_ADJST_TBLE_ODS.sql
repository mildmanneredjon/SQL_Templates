UPDATE ods
SET ods.Week_Number = pes.Week_Number,
    ods.Contracted_Payment = pes.Contracted_Payment,
    ods.Partial_Early_Settlement_Payment = pes.Partial_Early_Settlement_Payment,
    ods.Partial_Early_Settlement_Rebate_Value = pes.Partial_Early_Settlement_Rebate_Value,
    ods.Accounting_Week_Num = pes.Accounting_Week_Num,
    ods.Company_Code = pes.Company_Code,
    ods.Agreement_Id = pes.Agreement_Id,
    ods.Agreement_Db_Id = pes.Agreement_Db_Id,
    ods.Deleted_Flag = pes.Deleted_Flag,
    ods.Dt_Generation_Id_Src = pes.Dt_Generation_Id,
    ods.Dt_Transaction_Id_Src = pes.Dt_Transaction_Id,
    ods.Dt_Write_Bln_Src = pes.Dt_Write_Bln,
    ods.Last_Updated_Datetime_Src = pes.Last_Updated_Datetime,
    ods.Last_Updated_Id_Src = pes.Last_Updated_Id,
    ods.Last_Updated_Timestamp_Src = pes.Last_Updated_Timestamp,
    ods.Last_Updated_Date = pes.Last_Updated_Date,
    ods.Last_Creation_Date = pes.Last_Creation_Date
FROM dw_staging.EDW_DBO.DW_PES_PAYMENT_SCHEDULE_ADJUSTMENT_TABLE_STG pes
INNER JOIN dw_sales_ods.EDW_DBO.DW_NFS_PES_PAYMENT_SCHEDULE_ADJUSTMENT_ODS ods ON pes.PES_Payment_Schedule_Adjustment_Id = ods.PES_Payment_Schedule_Adjustment_Id
AND pes.PES_Payment_Schedule_Adjustment_Db_Id = ods.PES_Payment_Schedule_Adjustment_Db_Id


INSERT INTO dw_sales_ods.EDW_DBO.DW_NFS_PES_PAYMENT_SCHEDULE_ADJUSTMENT_ODS (Week_Number, Contracted_Payment, Partial_Early_Settlement_Payment, Partial_Early_Settlement_Rebate_Value, Accounting_Week_Num, Company_Code, Agreement_Id, Agreement_Db_Id, Deleted_Flag, Dt_Generation_Id_Src, Dt_Transaction_Id_Src, Dt_Write_Bln_Src, Last_Updated_Datetime_Src, Last_Updated_Id_Src, Last_Updated_Timestamp_Src, Last_Updated_Date, Last_Creation_Date)
SELECT pes.Week_Number,
       pes.Contracted_Payment,
       pes.Partial_Early_Settlement_Payment,
       pes.Partial_Early_Settlement_Rebate_Value,
       pes.Accounting_Week_Num,
       pes.Company_Code,
       pes.Agreement_Id,
       pes.Agreement_Db_Id,
       pes.Deleted_Flag,
       pes.Dt_Generation_Id,
       pes.Dt_Transaction_Id,
       pes.Dt_Write_Bln,
       pes.Last_Updated_Datetime,
       pes.Last_Updated_Id,
       pes.Last_Updated_Timestamp,
       pes.Last_Updated_Date,
       pes.Last_Creation_Date
FROM dw_staging.EDW_DBO.DW_PES_PAYMENT_SCHEDULE_ADJUSTMENT_TABLE_STG pes
LEFT JOIN dw_sales_ods.EDW_DBO.DW_NFS_PES_PAYMENT_SCHEDULE_ADJUSTMENT_ODS ods ON pes.PES_Payment_Schedule_Adjustment_Id = ods.PES_Payment_Schedule_Adjustment_Id
AND pes.PES_Payment_Schedule_Adjustment_Db_Id = ods.PES_Payment_Schedule_Adjustment_Db_Id
WHERE pes.PES_Payment_Schedule_Adjustment_Id IS NULL
  AND pes.PES_Payment_Schedule_Adjustment_Db_Id IS NULL