/*Connect to OpenHRDBTest*/

/*Set db owner to sa*/
USE [HRProEmployee]
GO
EXEC dbo.sp_changedbowner @loginame = N'sa', @map = false
GO

/*Check if cross db ownership chaining is switched on*/

select name,is_db_chaining_on
from sys.databases
where name = 'hrproemployee'

/*Enable database chaining*/
alter database hrproemployee set db_chaining on

/*Set up login with a database user*/

USE [HRProEmployee]
GO
CREATE USER [PFG\OpenHRDBTest-HREmployee-DL-RestrictedViews] FOR LOGIN [PFG\OpenHRDBTest-HREmployee-DL-RestrictedViews]
GO