/*Connect to openhrdb*/
use HRProEmployee
select job_title,email_work,department from personnel_records