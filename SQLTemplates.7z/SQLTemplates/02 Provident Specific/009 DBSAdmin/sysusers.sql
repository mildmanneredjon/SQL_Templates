DECLARE @SQL VARCHAR(MAX) 
SET @SQL = ''
DECLARE @Databases TABLE
(
	database_name varchar(256)
	, uid smallint
	, status smallint
	, name sysname
	, sid varbinary(85)
	, roles varbinary(2048)
	, createdate datetime
	, updatedate datetime
	, altuid smallint
	, password varbinary(255)
	, gid smallint
	, environ varchar(255)
	, hasdbaccess int
	, islogin int
	, isntname int
	, isntgroup int
	, isntuser int
	, issqluser int
	, isaliased int
	, issqlrole int
	, isapprole int
)


SELECT @SQL = @SQL +
'
USE [' + name + '];
select db_name(), *
from sys.sysusers;'
FROM sys.databases
WHERE state_desc = 'ONLINE'

INSERT INTO @Databases
EXEC (@SQL)

SELECT * 
FROM @Databases