/*Connect to hosquestion\time*/
SELECT
      [SQL_SERVER_NAME],[DOMAIN],[Server_Desc],[Server_Use],[SQL_PRODUCTVERSION],[SQL_EDITION],[OS],
	  [MODEL],[MEMORY_GB],[PROCESSORS],[CLUSTER],[WINDOWS_CLUSTER_NAME],[SQL_CLUSTER_NAME],
	  [SQL_STATUS],[SQL_LOG_ON_AS],[SQL_AGENT_STATUS],[AGENT_LOG_ON_AS],[SQL_COLLATION],
	  [ISCLUSTERED],[ActiveNode],[LicenseType],[AWE_ENABLED],[REDGATE_INSTALL],[REDGATE_STATUS]
  FROM [Server_Info].[dbo].[All_PFMS_SQL_Servers]
  where sql_server_name like '%%'
  --where server_desc like '%%'
