/*Connect to hosquestion*/

use GDPR_Metadata
select distinct dbname,instance
from meta.vw_All_Metadata
where dbname like '%mstore%'