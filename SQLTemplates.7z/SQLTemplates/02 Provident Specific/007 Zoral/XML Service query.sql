 -- 300000009147,300000009149,200000009213
  
-- Change this to your AgreementNumber
declare @agreementNumber varchar(50) = '200000336484';

-- Change this to your KnowledgeBase database name
use KnowledgeBaseStorage;

declare @applicationId uniqueidentifier;

select top 1  @applicationId = a.ApplicationId
  from Application a
 where a.AgreementNumber = @agreementNumber
 order by a.ApplicationCreationDate desc

declare @knowledgeBaseXml xml = 
(select (select icl.RequestedOn,
			   icl.RespondedOn,
			   reqm.RawContent as Request,
			   respm.RawContent as Response,
			   (select cast(oreqm.RawContent as xml) as Request,
					   cast(orespm.RawContent as xml) as Response,
					   (select oclt.RequestedOn,
								oclt.RespondedOn,
								oclt.Success,
								oclt.ErrorDescription
					      from dbo.OutgoingCallTryLog oclt
					     where oclt.OutgoingCallLogId = ocl.OutgoingCallLogId
					     for xml raw('PanCreditCallAttempt'), type) as PanCreditCallAttempts
			      from OutgoingCallLog ocl 
				  left join RawMessage oreqm on ocl.RequestRawMessageId = oreqm.RawMessageId
                  left join RawMessage orespm on ocl.ResponseRawMessageId = orespm.RawMessageId
				 where ocl.IncomingCallLogId = icl.IncomingCallLogId
				 for xml raw('PanCreditCall'), type) as PanCreditCalls
          from IncomingCallLog icl
          left join RawMessage reqm on icl.RequestRawMessageId = reqm.RawMessageId
		  left join RawMessage respm on icl.ResponseRawMessageId = respm.RawMessageId
         where icl.ApplicationId = a.ApplicationId 
		for xml raw('WebSiteCall'), type, elements) as WebSiteCalls,
		a.*,
	    (select la.PotentialFraud,
				lt.Name as LinkType,
				FraudTypeCode,
				a2.AgreementNumber
		   from dbo.LinkedApplication la
		   left join Application a2 on a2.ApplicationId = la.ApplicationLinkId
		   join dbo.ApplicationLinkType lt on lt.ApplicationLinkTypeId = la.LinkTypeId
		  where la.ApplicationId = a.ApplicationId
		   for xml raw('LinkedApplication'), type) as LinkedApplications 
  from Application a
 where a.ApplicationId = @applicationId
   for xml raw('Application'), ELEMENTS)

-- Change this to your DecisionEngine database name
use DecisionEngineStorage;

declare @dexml xml = 
(select dr.WorkflowName,
	   dr.WorkflowConfigurationVersion,
	   dr.ReceivedDateTime,
	   vs.Name as Status,
	   ResponseDateTime,
	   (select drr.ReasonCode,
			   drr.ReasonDescription,
			   drr.ReasonCategory
	      from Reason drr 
	     where drr.DecisionRequestId = dr.Id
	       for xml raw('Reason'), type) as Reasons,
	   cast(inputso.Serialized as xml) as WorkflowInput,
	   cast(outputso.Serialized as xml) as WorkflowOutput,
	   cast(gvso.Serialized as xml) as GlobalVariables,
	    (select dpr.ProviderName,
				dprs.Name as State,
				dpr.RequestDateTime,
				dpr.ResponseDateTime,
				dpr.ErrorDescription,
				cast(inputs.Serialized as xml) as Input,
				cast(outputs.Serialized as xml) as Output
	       from DecisionDataRequest ddr
	       join DataProviderRequest dpr on dpr.Id = ddr.DataProviderRequestId
	       join dbo.DataProviderRequestState dprs on dprs.Id = dpr.StateId
	       left join SerializedObject inputs on inputs.Id = dpr.InputId
	       left join SerializedObject outputs on outputs.Id = dpr.OutputId
	      where ddr.DecisionRequestId = dr.Id
	      for xml raw('DataProviderRequest'), type) as DataProviderRequests,
	   (select le.Date,
			   le.Thread,
			   le.Level,
			   le.Logger,
			   le.Message,
			   le.Exception
	      from LogEntry le 
	     where le.RequestId= dr.WorkflowRequestId and le.WorkflowName = dr.WorkflowName
	       for xml raw('LogEntry'), type, elements) as LogEntries
  from DecisionRequest dr
  left join dbo.VerificationStatus vs on vs.Id = dr.VerificationStatusId
  left join dbo.SerializedObject inputso on inputso.Id = dr.WorkflowInputId
  left join dbo.SerializedObject outputso on outputso.Id = dr.WorkflowOutputId
  left join dbo.SerializedObject gvso on gvso.Id = dr.GlobalVariablesId
 where len(dr.WorkflowRequestId) > 20
   and dr.WorkflowRequestId = @applicationId
   and WorkflowName in ('SatsumaApplicationWorkflow', 'SatsumaApplicationBankWorkflow')
   for xml raw('Decision'), type)
   
-- Change this to your Connectivity database name
use ConnectivityStorage;
   
   declare @connectivity xml = (
   select dr.ExternalApplicationId,
           dr.ExternalPersonId,
           dr.RequestDateTime ,
           dr.ResponseDateTime,
           dr.Cached,
  		   so.Serialized as Request,
   	    (select CacheKey,
   	            CacheKeyHash,
   	            dp.ProviderMethodName,
   	            so.Serialized as Response,
   				(select CallDateTime,
   						Success,
   						ErrorDescription,
   						ResponseDateTime
				   from dbo.DataCallTry dct
   	               where dc.DataCallId = dct.DataCallId
	                 for xml raw('DataCallTry'), type)
	       from dbo.DataCall dc
	       join dbo.DataProvider dp on dc.DataProviderId = dp.DataProviderId
	       left join dbo.SerializedObject so on so.SerializedObjectId = dc.SerializedObjectId
	      where dc.DataCallId = dr.DataCallId
	       for xml raw('DataCall'), type, elements)
     from DataRequest dr
     left join dbo.SerializedObject so on so.SerializedObjectId = dr.SerializedObjectId
    where dr.ExternalApplicationId = cast(@applicationId as varchar(50))
    for xml raw('DataRequest'), type);
   
   
select @knowledgeBaseXml as KnowledgeBase,
	   @dexml as Decisions,
	   @connectivity as Connectivity
   for xml raw('AgreementInfo')



