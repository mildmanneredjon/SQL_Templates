USE DecisionEngineStorage


-- Workflows results.
select DISTINCT
    dr.WorkflowRequestId as "Workflow Request ID",
       cast(winput.Serialized as xml).value('(/DecisionWorkflowInput/AgreementNumber/text())[1]','VARCHAR(50)') as "Agreement Number"
from DecisionRequest as dr
    left join VerificationStatus as vs on dr.VerificationStatusId = vs.Id
    left join SerializedObject as winput on winput.Id = dr.WorkflowInputId
    left join SerializedObject as woutput on woutput.Id = dr.WorkflowOutputId
    left join SerializedObject as gvars on gvars.Id = dr.GlobalVariablesId
where cast(winput.Serialized as xml).value('(/DecisionWorkflowInput/AgreementNumber/text())[1]','VARCHAR(50)') = '200000440096' -- <--- PUT AGREEMENT NUMBER HERE


-- PUT WORKFLOW REQUEST ID FROM QUERY ABOVE IN THE SET STATEMENT BELOW
--
DECLARE @applicationId nvarchar(322);
set @applicationId = '2d60e06c-2260-e411-9aee-005056ae742c';



-- Workflows results.
select 
    dr.WorkflowRequestId as "Workflow Request ID",
    dr.WorkflowName as "Workflow Name",
    vs.Name as "Verification Result",
    dr.IsCompleted as "Is Completed",
    cast(winput.Serialized as xml) as "Decision Workflow Input",
    cast(woutput.Serialized as xml) as "Decision Workflow Output",
    cast(gvars.Serialized as xml) as "Workflow Global Variables"	
from DecisionRequest as dr
    left join VerificationStatus as vs on dr.VerificationStatusId = vs.Id
    left join SerializedObject as winput on winput.Id = dr.WorkflowInputId
    left join SerializedObject as woutput on woutput.Id = dr.WorkflowOutputId
    left join SerializedObject as gvars on gvars.Id = dr.GlobalVariablesId
where dr.WorkflowRequestId = @applicationId;

-- Reasons of workflow decision
select
    dr.WorkflowRequestId as "Workflow Request ID",
    dr.WorkflowName as "Workflow Name",
    rs.ReasonCategory as "Reason Category",
    rs.ReasonCode as "Reason Code",
    rs.ReasonDescription as "Reason Description"
from DecisionRequest as dr
    left join Reason as rs on dr.Id = rs.DecisionRequestId
where dr.WorkflowRequestId = @applicationId;

-- Information about data requests made by workflow.
select
    dr.WorkflowRequestId as "Workflow Request ID",
    dr.WorkflowName as "Workflow Name",
    dpr.ProviderName as "Data Provider Name",
    cast(rq.Serialized as xml) as "Data Provider Input Content",
    cast(rs.Serialized as xml) as "Data Provider Output Content",
    dpr.ErrorDescription as "Data Provider Error Description",
    dprs.Name as "Data Provider State Name"
from DecisionRequest as dr
    left join DecisionDataRequest as ddr on dr.Id = ddr.DecisionRequestId
    left join DataProviderRequest as dpr on dpr.Id = ddr.DataProviderRequestId
    left join SerializedObject as rq on dpr.InputId = rq.Id
    left join SerializedObject as rs on dpr.OutputId = rs.Id
    left join DataProviderRequestState as dprs on dpr.StateId = dprs.Id
where dr.WorkflowRequestId = @applicationId;
