use KnowledgeBaseStorage;
declare @agreementNumber bigint;
set @agreementNumber = 70000260001;

select count (*) as "Imported Blacklist Entries Count"
from BlacklistLanding;

declare @currentDateTime datetime2;
set @currentDateTime = SYSUTCDATETIME();

select count(*) as "Runtime Active Blacklist Entries Count"
from Blacklist as b
where b.ActiveFrom <= @currentDateTime and (b.ActiveTo is null or b.ActiveTo > @currentDateTime)

declare @isInBlacklist bit;
declare @applicationId uniqueidentifier;
select @applicationId = a.ApplicationId
from Application as a
where a.AgreementNumber = @agreementNumber
order by a.ApplicationCreationDate desc;

exec BlackListCheck @applicationId, @isInBlacklist output;
select @isInBlacklist as "Is In Blacklist";

