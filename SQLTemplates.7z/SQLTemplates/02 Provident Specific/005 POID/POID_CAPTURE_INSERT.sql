--***************************************************************************
--* SDE Ticket Reference :  137197
--*
--* Script to be run at  : 
--*
--* Script Owner         : Hakima
--*
--* Date Implemented     : 
--*
--* Script Description   : POID_CAPTURE_INSERT.sql - Insert POID_LOOKUP Record
--*
--* Additional Comments  : Script Needs to be ran afer POID_DESCRIPTION_INSERT.sql has been executed
--*							As of creating this script, only 348 records out of 578 will be inserted.
--*							230 records in CSV have already come through. The total records to be 
--*							inserted may still go down, but will not increase.
--* 
--***************************************************************************

USE POID
GO

DECLARE  @CAPTUREExpectedRows SMALLINT

SELECT @CAPTUREExpectedRows = 348 -- expected POID Capture rows, number may go down but should not increase

BEGIN TRY

	BEGIN TRANSACTION

		--Show Data Before Patch
		SELECT	'PRE POID_CAPTURE'
		  SELECT count(*) [Pre Update count] FROM [POID].[dbo].[POID_CAPTURE]

	  --Insert new POID Description (Lookup)
	  INSERT INTO [POID].[dbo].[POID_CAPTURE] ([Customer_ID]
      ,[PoID_Type]
      ,[PoID_Date]
      ,[PoID_Date_Created]
      ,[PoID_Date_Last_Updated]
      ,[PoID_Reference1]
      ,[PoID_Updated_User_ID]
	  )
		SELECT CSV.[Customer_ID]
			  ,CSV.[PoID_Type]
			  --,'UK ID Card'                             
			  --,'MLRO Confirmed'
			  ,CSV.[PoID_Date]
			  ,CSV.[PoID_Date_Created]
			  ,CSV.[PoID_Date_Last_Updated]
			  ,CSV.[PoID_Reference1]
			  ,CSV.[PoID_Updated_User_ID]
		  FROM [DBSAdmin].[dbo].[POID_CAPTURE] CSV
		  WHERE CSV.Customer_ID  NOT IN (SELECT Customer_ID FROM [POID].[dbo].[POID_CAPTURE])

		--error if number of PRA Agreement rows returned isnt as expected (2)
			IF @@ROWCOUNT <> @CAPTUREExpectedRows
			BEGIN
				RAISERROR('Incorrect Number of POID Description Rows Inserted',16,1)
			END

		--Show Data After Patch
		SELECT	'POST POID_CAPTURE'
		  SELECT count(*) [Post Update count] FROM [POID].[dbo].[POID_CAPTURE]


	ROLLBACK TRANSACTION--Replace With COMMIT Once Happy With Results 
	--COMMIT TRANSACTION

END TRY

BEGIN CATCH
 
	SELECT 'Unsucessful: Rolling Back Statement'
	ROLLBACK

	SELECT ERROR_NUMBER() AS errorNumber,
       	ERROR_MESSAGE() AS ErrorMessage;

END CATCH