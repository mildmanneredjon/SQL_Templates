--***************************************************************************
--* SDE Ticket Reference :  
--*
--* Script to be run at  : 
--*
--* Script Owner         : A.Jones
--*
--* Date Implemented     : 06/Mar/2014
--*
--* Script Description   : Set "D","P" flag and balance in DM_CAIS_DETAIL table for debt sale Customers
--*
--* Additional Comments  : 
--* 
--***************************************************************************

DROP TABLE #CAIS_DebtSaleWithBalance
GO
CREATE TABLE #CAIS_DebtSaleWithBalance (
[Account_Number]  nvarchar(20) NULL )

BULK INSERT #CAIS_DebtSaleWithBalance
FROM '\\rsspetal\e$\ITOps\Tallyman\Test\DebtSaleWithBalances.csv'
WITH
(
	FIELDTERMINATOR = ',',
    ROWTERMINATOR = '\n'
)

select count(*) from #CAIS_DebtSaleWithBalance

SELECT count(*)
FROM  DW_EDW.EDW_DBO.DM_CAIS_DETAIL CA (nolock)
	JOIN	#CAIS_DebtSaleWithBalance DS
	ON		DS.Account_Number		=	CA.Account_Number
	WHERE	CA.Cais_Calendar_Id		=	(SELECT MAX(Cais_Calendar_Id) FROM DW_EDW.EDW_DBO.DM_CAIS_CALENDAR)

SELECT count(*)
FROM  DW_EDW.EDW_DBO.DM_CAIS_DETAIL CA (nolock)
	JOIN	#CAIS_DebtSaleWithBalance DS
	ON		DS.Account_Number		=	CA.Account_Number
	WHERE	CA.Cais_Calendar_Id		in	 (SELECT MAX(Cais_Calendar_Id) FROM DW_EDW.EDW_DBO.DM_CAIS_CALENDAR)
--	AND		Flag_Setting			!=	'P'
	AND		Special_Instruction		=	'D'
--	AND		Current_Balance			not like '0.000000' 
--	AND		Default_Satisfaction_Date IS NULL


-- Backup the records to be modified
INSERT INTO [DW_EDW].[EDW_DBO].[DM_CAIS_DETAIL_BACKUP_CAL_83]
           ([Cais_Calendar_Id]
           ,[Account_Number]
           ,[Account_Type_Code]
           ,[Start_Date]
           ,[Close_Date]
           ,[Monthly_Payment]
           ,[Repayment_Period]
           ,[Current_Balance]
           ,[Account_Status_Code]
           ,[Special_Instruction]
           ,[Flag_Setting]
           ,[Agreement_SK]
           ,[Customer_Id]
           ,[Customer_Name]
           ,[Address_Line_1]
           ,[Address_Line_2]
           ,[Address_Line_3]
           ,[Address_Line_4]
           ,[Post_Code]
           ,[Date_Of_Birth]
           ,[Default_Satisfaction_Date]
           ,[Original_Default_Balance]
           ,[New_Account_Number]
           ,[Source_System]
           ,[Last_Updated_Date]
           ,[Credit_Limit]
           ,[Extract_Excluded_Flag])
SELECT      CA.[Cais_Calendar_Id]
           ,CA.[Account_Number]
           ,[Account_Type_Code]
           ,[Start_Date]
           ,[Close_Date]
           ,[Monthly_Payment]
           ,[Repayment_Period]
           ,[Current_Balance]
           ,[Account_Status_Code]
           ,[Special_Instruction]
           ,[Flag_Setting]
           ,CA.[Agreement_SK]
           ,[Customer_Id]
           ,[Customer_Name]
           ,[Address_Line_1]
           ,[Address_Line_2]
           ,[Address_Line_3]
           ,[Address_Line_4]
           ,[Post_Code]
           ,[Date_Of_Birth]
           ,[Default_Satisfaction_Date]
           ,[Original_Default_Balance]
           ,[New_Account_Number]
           ,[Source_System]
           ,[Last_Updated_Date]
           ,[Credit_Limit]
           ,[Extract_Excluded_Flag]
 FROM DW_EDW.EDW_DBO.DM_CAIS_DETAIL CA
	JOIN #CAIS_DebtSaleWithBalance DS
	ON DS.Account_Number = CA.Account_Number
	WHERE DS.Account_Number = CA.Account_Number
    AND CA.Cais_Calendar_Id		=	(SELECT MAX(Cais_Calendar_Id) FROM DW_EDW.EDW_DBO.DM_CAIS_CALENDAR)
	AND Flag_Setting != 'P'
	AND Special_Instruction = ''
	AND Current_Balance not like '0.000000' 
 
SELECT    count(*)
FROM	[DW_EDW].[EDW_DBO].[DM_CAIS_DETAIL_BACKUP_CAL_83]



USE DW_EDW
go

SELECT 'Pre Patch Data'

SELECT count(*)
FROM  DW_EDW.EDW_DBO.DM_CAIS_DETAIL CA 
	JOIN	#CAIS_DebtSaleWithBalance DS
	ON		DS.Account_Number		=	CA.Account_Number
	where	CA.Cais_Calendar_Id		=	(SELECT MAX(Cais_Calendar_Id) FROM DW_EDW.EDW_DBO.DM_CAIS_CALENDAR)
	AND		Flag_Setting			!=	'P'
	AND		Current_Balance			!=	'0.000000'
 	AND		Special_Instruction		!=	'D'
	AND		Default_Satisfaction_Date IS NULL



BEGIN TRY

BEGIN TRANSACTION

--DECLARE VARIABLES
DECLARE 	@UP_DATE 				datetime
DECLARE		@CAIS_CAL				int
--SET VARIABLES
SET			@CAIS_CAL			=	(SELECT MAX(Cais_Calendar_Id) FROM DW_EDW.EDW_DBO.DM_CAIS_CALENDAR)
SET 		@UP_DATE 			=	getdate() 

UPDATE DW_EDW.EDW_DBO.DM_CAIS_DETAIL
SET Special_Instruction			=	'D' ,
	Flag_Setting				=	'P' ,
	Current_Balance				=	'0.000000'  ,
    Last_Updated_Date			=	@UP_DATE
FROM DW_EDW.EDW_DBO.DM_CAIS_DETAIL CA
	JOIN	#CAIS_DebtSaleWithBalance DS
	ON		DS.Account_Number		=	CA.Account_Number
	where	CA.Cais_Calendar_Id		=	(SELECT MAX(Cais_Calendar_Id) FROM DW_EDW.EDW_DBO.DM_CAIS_CALENDAR)
	AND		Flag_Setting			=	'P'
	AND		Special_Instruction		=	'D'
	AND		Current_Balance			=	'0.000000'
 	AND		Default_Satisfaction_Date IS NULL


SELECT 'Post Patch Data'

SELECT *
FROM  DW_EDW.EDW_DBO.DM_CAIS_DETAIL CA (nolock)
	JOIN	#CAIS_DebtSaleWithBalance DS
	ON		DS.Account_Number		=	CA.Account_Number
	WHERE	CA.Cais_Calendar_Id		=	(SELECT MAX(Cais_Calendar_Id) FROM DW_EDW.EDW_DBO.DM_CAIS_CALENDAR)
	AND		Flag_Setting			=	'P'
	AND		Special_Instruction		=	'D'
	AND		Current_Balance			=	'0.000000'
-- 	AND		Default_Satisfaction_Date IS NULL


ROLLBACK TRANSACTION

END TRY

BEGIN CATCH
 
	SELECT 'Unsucessful: Rolling Back Statement'
	ROLLBACK

	SELECT ERROR_NUMBER() AS errorNumber,
       	ERROR_MESSAGE() AS ErrorMessage;

END CATCH

SELECT 'Post ROLLBACK Data'

SELECT count(*)
FROM  DW_EDW.EDW_DBO.DM_CAIS_DETAIL CA (nolock)
	JOIN	#CAIS_DebtSaleWithBalance DS
	ON		DS.Account_Number		=	CA.Account_Number
	where	CA.Cais_Calendar_Id		=	(SELECT MAX(Cais_Calendar_Id) FROM DW_EDW.EDW_DBO.DM_CAIS_CALENDAR)
	and		Flag_Setting			=	'P'
 	and		Special_Instruction		=	'D'
	AND		Current_Balance			=	'0.000000'



