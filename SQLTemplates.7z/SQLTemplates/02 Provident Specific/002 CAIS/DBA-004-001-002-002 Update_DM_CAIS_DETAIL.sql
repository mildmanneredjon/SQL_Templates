--***************************************************************************
--* SDE Ticket Reference :  136784
--*
--* Script to be run at  : RSSSHADOW\LANDS.DW_EDW
--*
--* Script Owner         : Dipesh Mistry
--*
--* Date Implemented     : 08/10/2014
--*
--* Script Description   : Set "D" Special_Instruction flag in DM_CAIS_DETAIL table for debt sale Customers
--*
--* Additional Comments  : 
--* 
--***************************************************************************

--CREATE TEMP TABLE TO STORE DATA FROM CSV FILE
IF OBJECT_ID('tempdb..#CAIS_D_UPDATE_DATA') IS NOT NULL  
 BEGIN

   DROP TABLE #CAIS_D_UPDATE_DATA

   CREATE TABLE #CAIS_D_UPDATE_DATA (
	[Tallyman_Customer_Number] [bigint] NULL,
	[Rapid_Unique_Number] [bigint] NULL,
	[Tallyman_Unique_Number] [bigint] NULL,
	[Write_Off_Code] nvarchar(20) NULL,
	[Write_Off_Date] [datetime] NULL,
	[Transaction_Value] numeric(22,6) NULL,
	[Debt_Balance] numeric(22,6) NULL,
	[Customer_Status] nvarchar(20) NULL,
	[Tallyman_Customer_Creation_Date] [datetime] NULL,
	[Tallyman Insolvency Satisfied Date] [datetime] NULL )
 
 END
 ELSE
 BEGIN
 
	CREATE TABLE #CAIS_D_UPDATE_DATA (
	[Tallyman_Customer_Number] [bigint] NULL,
	[Rapid_Unique_Number] [bigint] NULL,
	[Tallyman_Unique_Number] [bigint] NULL,
	[Write_Off_Code] nvarchar(20) NULL,
	[Write_Off_Date] [datetime] NULL,
	[Transaction_Value] numeric(22,6) NULL,
	[Debt_Balance] numeric(22,6) NULL,
	[Customer_Status] nvarchar(20) NULL,
	[Tallyman_Customer_Creation_Date] [datetime] NULL,
	[Tallyman Insolvency Satisfied Date] [datetime] NULL )

 END

 
--BULK INSERT THE DATA FROM THE FILE INTO THE TEMP TABLE
BULK INSERT #CAIS_D_UPDATE_DATA
FROM '\\Hosshaun\c$\BExtract\DataWarehouse\TallymanFiles\September-DebtSale\DW_WRITE_OFFS_13092014_2136.csv'
WITH
(
	FIELDTERMINATOR = ',',
    ROWTERMINATOR = '\n'
)

BULK INSERT #CAIS_D_UPDATE_DATA
FROM '\\Hosshaun\c$\BExtract\DataWarehouse\TallymanFiles\September-DebtSale\DW_WRITE_OFFS_20092014_2134.csv'
WITH
(
	FIELDTERMINATOR = ',',
    ROWTERMINATOR = '\n'
)


BULK INSERT #CAIS_D_UPDATE_DATA
FROM '\\Hosshaun\c$\BExtract\DataWarehouse\TallymanFiles\September-DebtSale\DW_WRITE_OFFS_27092014_2133.csv'
WITH
(
	FIELDTERMINATOR = ',',
    ROWTERMINATOR = '\n'
)

-- Backup the records to be modified

DROP TABLE [DW_EDW].[EDW_DBO].[DM_CAIS_DETAIL_BACKUP_CAL_90]

select  
		   CA.[Cais_Calendar_Id]
           ,CA.[Account_Number]
           ,[Account_Type_Code]
           ,[Start_Date]
           ,[Close_Date]
           ,[Monthly_Payment]
           ,[Repayment_Period]
           ,[Current_Balance]
           ,[Account_Status_Code]
           ,[Special_Instruction]
           ,[Flag_Setting]
           ,CA.[Agreement_SK]
           ,[Customer_Id]
           ,[Customer_Name]
           ,[Address_Line_1]
           ,[Address_Line_2]
           ,[Address_Line_3]
           ,[Address_Line_4]
           ,[Post_Code]
           ,[Date_Of_Birth]
           ,[Default_Satisfaction_Date]
           ,[Original_Default_Balance]
           ,[New_Account_Number]
           ,[Source_System]
           ,[Last_Updated_Date]
           ,[Credit_Limit]
           ,[Extract_Excluded_Flag] INTO [DW_EDW].[EDW_DBO].[DM_CAIS_DETAIL_BACKUP_CAL_90]
 from DW_EDW.EDW_DBO.DM_CAIS_DETAIL CA
	JOIN #CAIS_D_UPDATE_DATA Upd
	ON CA.Customer_Id			=	Upd.Tallyman_Customer_Number
	where CA.Customer_Id		=	Upd.Tallyman_Customer_Number
    and CA.Cais_Calendar_Id		=	'90'
	and Upd.Write_Off_Code		=	'98'


SELECT 'RECORDS TO BE UPDATED BACKED UP IN DM_CAIS_DETAIL_BACKUP_CAL_90 TABLE '
SELECT * FROM [DW_EDW].[EDW_DBO].[DM_CAIS_DETAIL_BACKUP_CAL_90]

BEGIN TRY

BEGIN TRANSACTION

--DECLARE VARIABLES
DECLARE  @UP_DATE 	datetime
DECLARE @ExpectedRows SMALLINT

--SET VARIABLES
SET 	@UP_DATE 	=	getdate() 
SET     @ExpectedRows = 137 -- expected number of rows 

SELECT 'BEFORE UPDATE'

SELECT CA.Special_Instruction,CA.Last_Updated_Date,CA.*
  FROM DW_EDW.EDW_DBO.DM_CAIS_DETAIL CA
  JOIN #CAIS_D_UPDATE_DATA Upd
	ON CA.Customer_Id			=	Upd.Tallyman_Customer_Number
 WHERE CA.Customer_Id		=	Upd.Tallyman_Customer_Number AND
       CA.Cais_Calendar_Id		=	'90' AND
	   Upd.Write_Off_Code		=	'98'

SELECT 'SELECT UPDATE'
UPDATE CA
   SET CA.Special_Instruction =	'D' ,
       CA.Last_Updated_Date	= @UP_DATE
  FROM DW_EDW.EDW_DBO.DM_CAIS_DETAIL CA
  JOIN #CAIS_D_UPDATE_DATA Upd
	ON CA.Customer_Id =	Upd.Tallyman_Customer_Number
 WHERE CA.Customer_Id =	Upd.Tallyman_Customer_Number AND
       CA.Cais_Calendar_Id = '90' AND
	   Upd.Write_Off_Code = '98'


--Error if number of rows returned isnt as expected
IF @@ROWCOUNT <> @ExpectedRows
	BEGIN
		RAISERROR('Incorrect Number of Rows',16,1)
	END
        
SELECT 'AFTER UPDATE'

SELECT CA.Special_Instruction,CA.Last_Updated_Date,CA.*
  FROM DW_EDW.EDW_DBO.DM_CAIS_DETAIL CA
  JOIN #CAIS_D_UPDATE_DATA Upd
	ON CA.Customer_Id			=	Upd.Tallyman_Customer_Number
 WHERE CA.Customer_Id		=	Upd.Tallyman_Customer_Number AND
       CA.Cais_Calendar_Id		=	'90' AND
	   Upd.Write_Off_Code		=	'98'


ROLLBACK TRANSACTION

END TRY

BEGIN CATCH
 
	ROLLBACK TRANSACTION
	SELECT 'Unsucessful: Rolling Back Statement'

	SELECT ERROR_NUMBER() AS errorNumber,      	
	       ERROR_MESSAGE() AS ErrorMessage;
		   
END CATCH