--***************************************************************************
--* SDE Ticket Reference :  137111
--*
--* Script to be run at  : 
--*
--* Script Owner         : Hakima
--*
--* Date Implemented     : 
--*
--* Script Description   : Patch Customer address field and update statement_config
--*
--* Additional Comments  : 
--* 
--***************************************************************************

USE DW_COMPLIANCE_MART
GO

DECLARE @CurrentDate DATETIME
		,@ExpectedRows_For_Statement_Customer SMALLINT
		,@ExpectedRows_For_Statement_Config SMALLINT
		,@Customer_Id BIGINT
		,@Batch_ID  BIGINT 

SELECT @CurrentDate = GETDATE()
		,@ExpectedRows_For_Statement_Customer = 1
		,@ExpectedRows_For_Statement_Config = 1 -- expected number of rows 
		,@CUSTOMER_ID =  51000767619
		,@BATCH_ID = 16262

BEGIN TRY

	BEGIN TRANSACTION

--Correct Address line 2 for original_customer_identifier 51000767619
SELECT Address_Line_2,* FROM [DW_Compliance_Mart].[EDW_DBO].[DM_STATEMENT_CUSTOMER]
where original_customer_identifier = @CUSTOMER_ID
and batch_id = @BATCH_ID

update [DW_Compliance_Mart].[EDW_DBO].[DM_STATEMENT_CUSTOMER]
SET Address_Line_2 = 'Frenchay'
where original_customer_identifier = @CUSTOMER_ID
and batch_id = @BATCH_ID

		--error if number of rows returned isnt as expected
		IF @@ROWCOUNT <> @ExpectedRows_For_Statement_Customer
		BEGIN
			RAISERROR('Incorrect Number of Rows in DM_STATEMENT_CUSTOME',16,1)
		END

SELECT Address_Line_2,* FROM [DW_Compliance_Mart].[EDW_DBO].[DM_STATEMENT_CUSTOMER]
where original_customer_identifier = @CUSTOMER_ID
and batch_id = @BATCH_ID

--Update config processed status for batch id to DG
select Processed_Status [Processed_Status BEFORE] from [DW_Compliance_Mart].[EDW_DBO].[DM_STATEMENT_CONFIG]
where batch_id = @BATCH_ID

update [DW_Compliance_Mart].[EDW_DBO].[DM_STATEMENT_CONFIG]
set Processed_Status = 'DG'
where batch_id = @BATCH_ID

		--error if number of rows returned isnt as expected
		IF @@ROWCOUNT <> @ExpectedRows_For_Statement_Config
		BEGIN
			RAISERROR('Incorrect Number of Rows Returned in DM_STATEMENT_CONFIG',16,1)
		END


select Processed_Status [Processed_Status AFTER]
from [DW_Compliance_Mart].[EDW_DBO].[DM_STATEMENT_CONFIG]
where batch_id = @BATCH_ID


	--ROLLBACK TRANSACTION--Replace With COMMIT Once Happy With Results 
	COMMIT TRANSACTION

END TRY

BEGIN CATCH
 
	SELECT 'Unsucessful: Rolling Back Statement'
	ROLLBACK

	SELECT ERROR_NUMBER() AS errorNumber,
       	ERROR_MESSAGE() AS ErrorMessage;

END CATCH


exec EDW_DBO.DM_GENERATE_STATEMENT @Batch_id = @BATCH_ID


--Update config processed status for batch id to DG
select Processed_Status [Processed_Status BEFORE] from [DW_Compliance_Mart].[EDW_DBO].[DM_STATEMENT_CONFIG]
where batch_id = @BATCH_ID

update [DW_Compliance_Mart].[EDW_DBO].[DM_STATEMENT_CONFIG]
set Processed_Status = 'CO'
where batch_id = @BATCH_ID

--run the Maestro job JMOVEFILES

