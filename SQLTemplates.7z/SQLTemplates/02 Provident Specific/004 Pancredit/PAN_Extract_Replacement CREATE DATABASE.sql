USE [master]
GO

/****** Object:  Database [PAN_Extract_Replacement]    Script Date: 08/07/2014 08:41:10 ******/
CREATE DATABASE [PAN_Extract_Replacement] ON  PRIMARY 
( NAME = N'PAN_Extract', FILENAME = N'F:\Program Files\Microsoft SQL Server\PAN_Extract.mdf' , SIZE = 25600KB , MAXSIZE = 131072KB , FILEGROWTH = 25600KB ), 
 FILEGROUP [Extract_Data] 
( NAME = N'PAN_Extract_Data_1', FILENAME = N'F:\Program Files\Microsoft SQL Server\PAN_Extract_Data_1.ndf' , SIZE = 262144KB , MAXSIZE = 2097152KB , FILEGROWTH = 131072KB ), 
( NAME = N'PAN_Extract_Data_2', FILENAME = N'F:\Program Files\Microsoft SQL Server\PAN_Extract_Data_2.ndf' , SIZE = 262144KB , MAXSIZE = 2097152KB , FILEGROWTH = 131072KB ), 
( NAME = N'PAN_Extract_Data_3', FILENAME = N'F:\Program Files\Microsoft SQL Server\PAN_Extract_Data_3.ndf' , SIZE = 262144KB , MAXSIZE = 2097152KB , FILEGROWTH = 131072KB ), 
( NAME = N'PAN_Extract_Data_4', FILENAME = N'F:\Program Files\Microsoft SQL Server\PAN_Extract_Data_4.ndf' , SIZE = 262144KB , MAXSIZE = 2097152KB , FILEGROWTH = 131072KB )
 LOG ON 
( NAME = N'PAN_Extract_log', FILENAME = N'F:\Program Files\Microsoft SQL Server\PAN_Extract_log.ldf' , SIZE = 1048576KB , MAXSIZE = 10485760KB , FILEGROWTH = 25600KB )
GO

ALTER DATABASE [PAN_Extract_Replacement] SET COMPATIBILITY_LEVEL = 90
GO

IF (1 = FULLTEXTSERVICEPROPERTY('IsFullTextInstalled'))
BEGIN
EXEC [PAN_Extract_Replacement].[dbo].[sp_fulltext_database] @action = 'disable'
END
GO

ALTER DATABASE [PAN_Extract_Replacement] SET ANSI_NULL_DEFAULT OFF 
GO

ALTER DATABASE [PAN_Extract_Replacement] SET ANSI_NULLS OFF 
GO

ALTER DATABASE [PAN_Extract_Replacement] SET ANSI_PADDING OFF 
GO

ALTER DATABASE [PAN_Extract_Replacement] SET ANSI_WARNINGS OFF 
GO

ALTER DATABASE [PAN_Extract_Replacement] SET ARITHABORT OFF 
GO

ALTER DATABASE [PAN_Extract_Replacement] SET AUTO_CLOSE OFF 
GO

ALTER DATABASE [PAN_Extract_Replacement] SET AUTO_CREATE_STATISTICS ON 
GO

ALTER DATABASE [PAN_Extract_Replacement] SET AUTO_SHRINK OFF 
GO

ALTER DATABASE [PAN_Extract_Replacement] SET AUTO_UPDATE_STATISTICS ON 
GO

ALTER DATABASE [PAN_Extract_Replacement] SET CURSOR_CLOSE_ON_COMMIT OFF 
GO

ALTER DATABASE [PAN_Extract_Replacement] SET CURSOR_DEFAULT  GLOBAL 
GO

ALTER DATABASE [PAN_Extract_Replacement] SET CONCAT_NULL_YIELDS_NULL OFF 
GO

ALTER DATABASE [PAN_Extract_Replacement] SET NUMERIC_ROUNDABORT OFF 
GO

ALTER DATABASE [PAN_Extract_Replacement] SET QUOTED_IDENTIFIER OFF 
GO

ALTER DATABASE [PAN_Extract_Replacement] SET RECURSIVE_TRIGGERS OFF 
GO

ALTER DATABASE [PAN_Extract_Replacement] SET  DISABLE_BROKER 
GO

ALTER DATABASE [PAN_Extract_Replacement] SET AUTO_UPDATE_STATISTICS_ASYNC OFF 
GO

ALTER DATABASE [PAN_Extract_Replacement] SET DATE_CORRELATION_OPTIMIZATION OFF 
GO

ALTER DATABASE [PAN_Extract_Replacement] SET TRUSTWORTHY OFF 
GO

ALTER DATABASE [PAN_Extract_Replacement] SET ALLOW_SNAPSHOT_ISOLATION OFF 
GO

ALTER DATABASE [PAN_Extract_Replacement] SET PARAMETERIZATION SIMPLE 
GO

ALTER DATABASE [PAN_Extract_Replacement] SET READ_COMMITTED_SNAPSHOT OFF 
GO

ALTER DATABASE [PAN_Extract_Replacement] SET RECOVERY SIMPLE 
GO

ALTER DATABASE [PAN_Extract_Replacement] SET  MULTI_USER 
GO

ALTER DATABASE [PAN_Extract_Replacement] SET PAGE_VERIFY CHECKSUM  
GO

ALTER DATABASE [PAN_Extract_Replacement] SET DB_CHAINING OFF 
GO

ALTER DATABASE [PAN_Extract_Replacement] SET  READ_WRITE 
GO


