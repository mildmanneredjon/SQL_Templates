CREATE PROC usp_QueryAgreementStatusChange
AS
/**
*-----------------------------------------------------------------------------*
|									Title									  |
|																			  |
|		Version 1				Michael Kettlewell		01/01/1900 00:00	  |
|		Version 2				Dale Stewart			09/07/2014 09:05	  |
|																			  |
*-----------------------------------------------------------------------------*

COMPATIBLITY
------------

*-----------------------------------------------------------------------------*
BACKGROUND
----------


*-----------------------------------------------------------------------------*
USAGE
-----

*-----------------------------------------------------------------------------*
VERSION 1
---------
first version, see background

VERSION 2
---------
Removed ORDER BY clause


*-----------------------------------------------------------------------------*
REFERENCES
----------

*-----------------------------------------------------------------------------*
PARAMETERS
----------

*-----------------------------------------------------------------------------*
CALL STACK
----------
**/


;With StatusChange as
(
	Select	a.AgreementNumber,
		a.AgreementStatus,
		a.ExtractDate StartDate,
		row_number() over (partition by a.AgreementNumber order by a.ExtractDate) StatusChangeID
	from	Staging.AgreementStatusChange_Temp a
	left join	Staging.AgreementStatusChange_Temp b	on	a.AgreementNumber = b.AgreementNumber
						and	a.ID = b.ID + 1
					
	where	isnull(a.AgreementStatus,'') <> isnull(b.AgreementStatus,'')
)	
Select	a.AgreementNumber,
	a.AgreementStatus,
	a.StartDate,
	dateadd(day, -1, b.StartDate) EndDate
from	StatusChange a
left join	StatusChange b	on	a.AgreementNumber = b.AgreementNumber
			and	a.StatusChangeID = b.StatusChangeID - 1
--order by	a.AgreementNumber,
--	a.StartDate

GO


CREATE PROC usp_QueryApplicationStatusChange
AS
/**
*-----------------------------------------------------------------------------*
|									Title									  |
|																			  |
|		Version 1				Michael Kettlewell		01/01/1900 00:00	  |
|		Version 2				Dale Stewart			09/07/2014 09:05	  |
|																			  |
*-----------------------------------------------------------------------------*

COMPATIBLITY
------------

*-----------------------------------------------------------------------------*
BACKGROUND
----------


*-----------------------------------------------------------------------------*
USAGE
-----

*-----------------------------------------------------------------------------*
VERSION 1
---------
first version, see background

VERSION 2
---------
Removed ORDER BY clause


*-----------------------------------------------------------------------------*
REFERENCES
----------

*-----------------------------------------------------------------------------*
PARAMETERS
----------

*-----------------------------------------------------------------------------*
CALL STACK
----------
**/

;With StatusChange as
(
Select	a.AgreementNumber,
	a.ApplicationStatus,
	a.ExtractDate StartDate,
	row_number() over (partition by a.AgreementNumber order by a.ExtractDate) StatusChangeID
from	Staging.ApplicationStatusChange_Temp a
left join	Staging.ApplicationStatusChange_Temp b	on	a.AgreementNumber = b.AgreementNumber
					and	a.ID = b.ID + 1
					
where	isnull(a.ApplicationStatus,'') <> isnull(b.ApplicationStatus,'')
)	
Select	a.AgreementNumber,
	a.ApplicationStatus,
	a.StartDate,
	dateadd(day, -1, b.StartDate) EndDate
from	StatusChange a
left join	StatusChange b	on	a.AgreementNumber = b.AgreementNumber
			and	a.StatusChangeID = b.StatusChangeID - 1
--order by	a.AgreementNumber,
--	a.StartDate



GO