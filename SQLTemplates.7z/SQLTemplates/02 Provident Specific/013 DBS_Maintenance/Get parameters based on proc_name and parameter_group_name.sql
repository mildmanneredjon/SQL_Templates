declare @proc_name varchar(128) = 'Maintenance.up_DatabaseBackup'
declare @parameter_group_name varchar(128) = 'NativeFull'

SELECT TOP 1000 [proc_name]
      ,[parameter_group_name]
      ,[parameter_name]
      ,[config_value]
      ,[order_of_appearance]
  FROM [DBS_Maintenance].[CONFIG].[vw_CurrentConfig]
  where proc_name = @proc_name
  and parameter_group_name = @parameter_group_name