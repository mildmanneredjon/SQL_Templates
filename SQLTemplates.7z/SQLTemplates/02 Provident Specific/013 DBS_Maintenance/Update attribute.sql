use DBS_Maintenance

  declare @proc_name varchar(256),
  @parameter_group_name varchar(256),
  @parameter_name varchar(256)

  set @proc_name = 'Maintenance.up_DatabaseBackup'
  set @parameter_group_name = 'NativeLog'
  set @parameter_name = '@CleanUpTime'

  set @new_value = '72'

  begin tran
  update c
  set config_value_vmax = @new_value
  from config.config c
  inner join config.Config_Header ch
  on c.config_header_id = ch.config_header_id
  where ch.proc_name = @proc_name
  and ch.parameter_group_name = @parameter_group_name
  and c.parameter_name = @parameter_name
  commit tran