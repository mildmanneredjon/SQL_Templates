 
 /**
*-----------------------------------------------------------------------------*
|							Standard Support Script	                          |
|                                                                             |
|         Version 1         Dale Stewart             13/11/2014               |
|         Version 2         Dale Stewart             10/08/2016               |
|                                                                             |
*-----------------------------------------------------------------------------*

COMPATIBLITY
------------
2008 upwards

*-----------------------------------------------------------------------------*
BACKGROUND
----------
Describe the reason the script has been created. this section should include
as much information about the 

*-----------------------------------------------------------------------------*
USAGE
-----
Give examples of how to execute the script. Are there any special conditions
that should exist beforehand (should the script test for those first?).
This section is particularly important when this code block is used in 
stored procedures.

*-----------------------------------------------------------------------------*
VERSION 1
---------
List all features of the first version

VERSION 2
---------
list all changes made to the script since version 1

*-----------------------------------------------------------------------------*
REFERENCES
----------
Include any references to external sites (if code has been copied) or to
any other internal policies or guidelines

*-----------------------------------------------------------------------------*
PARAMETERS
----------
List a

*-----------------------------------------------------------------------------*
DEPENDENCIES
----------
List all scripts or code this script relies upon. For example this could
include scripts that need to be run before this one.

**/

-------------------------------------------------------------------------------
:setvar checkSQLCMD "checkSQLCMD" 
GO 
IF ('$(checkSQLCMD)' = '$' + '(checkSQLCMD)') RAISERROR ('This script must be run in SQLCMD mode.', 20, 1) WITH LOG 
GO 
SELECT 'This part executes only in SQLCMD mode!'

-------------------------------------------------------------------------------
:setvar ServerName "<Target_SQL_Server, sysname, >"
:setvar DatabaseName "<Target_Database, sysname, >"
:setvar CR "<Change_Request_No, sysname, >"

:connect $(ServerName)
USE $(DatabaseName)

------------------------------------------------------------------------------- 
 SET XACT_ABORT ON;

 DECLARE @ExpectedRowCount INT
	, @ActualRowCount INT

SET @ExpectedRowCount = <Expected_Row_Count, INT, >
SET @ActualRowCount = 0

BEGIN TRAN

	-------------------------------------------------------------------------------
	--Take a backup copy of the data
	SELECT *
	INTO <Data_Backup_Database, sysname, DBSAdmin>.dbo.CR$(CR)
	FROM [<Security_Schema, sysname, dbo>].[<Table_Name, sysname, Table_Name>]
	WHERE <WHERE_Condition_Column, sysname, Column1> <WHERE_Predicate, VARCHAR, => <WHERE_Value, VARCHAR, 1>;

	-------------------------------------------------------------------------------
	--perform data modification
	/**
	DELETE FROM [<Security_Schema, sysname, dbo>].[<Table_Name, sysname, Table_Name>]
	WHERE <WHERE_Condition_Column, sysname, Column1> <WHERE_Predicate, VARCHAR, => <WHERE_Value, VARCHAR, 1>;

	**/

	/**
	UPDATE [<Security_Schema, sysname, dbo>].[<Table_Name, sysname, Table_Name>]
	SET [<Security_Schema, sysname, dbo>].[<Table_Name, sysname, Table_Name>]
	WHERE <WHERE_Condition_Column, sysname, Column1> <WHERE_Predicate, VARCHAR, => <WHERE_Value, VARCHAR, 1>;

	**/

	SET @ActualRowCount = @@ROWCOUNT
	IF @ExpectedRowCount <> @ActualRowCount
		BEGIN
			select 1/0 --used to create an error so the script rolls back
			RAISERROR ('Row count mismatch', 16, 1);
		END;


COMMIT TRAN