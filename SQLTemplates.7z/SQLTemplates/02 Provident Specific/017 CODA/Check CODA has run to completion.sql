/*
Query to check CODA run has worked as expected

The values should show that there are no 1s in Active_Record_Bln and all values are FPC
*/

SELECT *
FROM DW_Metadata.EDW_DBO.DW_ETL_LOAD_PROCESS_MDT
WHERE Process_Id IN (7,8,9)
ORDER BY Last_Creation_Date desc 