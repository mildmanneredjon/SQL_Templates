USE [msdb]
GO

/****** Object:  Job [Satsuma Incremental Load (Thrice Daily)]    Script Date: 11/12/2014 11:47:12 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]]    Script Date: 11/12/2014 11:47:12 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'Satsuma Incremental Load (Thrice Daily)', 
		@enabled=1, 
		@notify_level_eventlog=2, 
		@notify_level_email=3, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'sa', 
		@notify_email_operator_name=N'MIADDataSupport', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Satsuma_src_Incremental_MASTER_sync]    Script Date: 11/12/2014 11:47:13 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Satsuma_src_Incremental_MASTER_sync', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'DECLARE @execution_id BIGINT

EXEC [SSISDB].[catalog].[create_execution] @package_name = N''Satsuma_src_Incremental_MASTER.dtsx''
	,@execution_id = @execution_id OUTPUT
	,@folder_name = N''Satsuma''
	,@project_name = N''satsuma.etl''
	,@use32bitruntime = False
	,@reference_id = 1

EXEC [SSISDB].[catalog].[set_execution_parameter_value] 
        @execution_id,  -- execution_id from catalog.create_execution
        @object_type=50, 
        @parameter_name=N''SYNCHRONIZED'', 
        @parameter_value= 1; -- turn on synchronized execution

SELECT @execution_id

DECLARE @var0 SMALLINT = 1

EXEC [SSISDB].[catalog].[set_execution_parameter_value] @execution_id
	,@object_type = 20
	,@parameter_name = N''DeleteLoad''
	,@parameter_value = @var0

DECLARE @var1 SMALLINT = 1

EXEC [SSISDB].[catalog].[set_execution_parameter_value] @execution_id
	,@object_type = 50
	,@parameter_name = N''LOGGING_LEVEL''
	,@parameter_value = @var1

EXEC [SSISDB].[catalog].[start_execution] @execution_id
GO

', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Satsuma_src_RECON_async]    Script Date: 11/12/2014 11:47:13 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Satsuma_src_RECON_async', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'DECLARE @execution_id BIGINT

EXEC [SSISDB].[catalog].[create_execution] @package_name = N''Satsuma_src_RECON.dtsx''
	,@execution_id = @execution_id OUTPUT
	,@folder_name = N''Satsuma''
	,@project_name = N''satsuma.etl''
	,@use32bitruntime = False
	,@reference_id = 1

SELECT @execution_id

DECLARE @var0 SMALLINT = 1

EXEC [SSISDB].[catalog].[set_execution_parameter_value] @execution_id
	,@object_type = 50
	,@parameter_name = N''LOGGING_LEVEL''
	,@parameter_value = @var0

EXEC [SSISDB].[catalog].[start_execution] @execution_id
GO

', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Satsuma_Staging_Landing_MASTER]    Script Date: 11/12/2014 11:47:13 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Satsuma_Staging_Landing_MASTER', 
		@step_id=3, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=8, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'DECLARE @execution_id BIGINT

EXEC [SSISDB].[catalog].[create_execution] @package_name = N''Satsuma_Staging_Landing_MASTER.dtsx''
	,@execution_id = @execution_id OUTPUT
	,@folder_name = N''Satsuma''
	,@project_name = N''satsuma.etl''
	,@use32bitruntime = False
	,@reference_id = 1

EXEC [SSISDB].[catalog].[set_execution_parameter_value] 
        @execution_id,  -- execution_id from catalog.create_execution
        @object_type=50, 
        @parameter_name=N''SYNCHRONIZED'', 
        @parameter_value= 1; -- turn on synchronized execution

SELECT @execution_id

DECLARE @var0 SMALLINT = 1

EXEC [SSISDB].[catalog].[set_execution_parameter_value] @execution_id
	,@object_type = 50
	,@parameter_name = N''LOGGING_LEVEL''
	,@parameter_value = @var0

EXEC [SSISDB].[catalog].[start_execution] @execution_id
GO', 
		@database_name=N'SSISDB', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Satsuma_staging_Landing_ETL_LOOKUPS]    Script Date: 11/12/2014 11:47:13 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Satsuma_staging_Landing_ETL_LOOKUPS', 
		@step_id=4, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=8, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'DECLARE @execution_id BIGINT

EXEC [SSISDB].[catalog].[create_execution] @package_name = N''Satsuma_staging_Landing_ETL_LOOKUPS.dtsx''
	,@execution_id = @execution_id OUTPUT
	,@folder_name = N''Satsuma''
	,@project_name = N''satsuma.etl''
	,@use32bitruntime = False
	,@reference_id = 1

EXEC [SSISDB].[catalog].[set_execution_parameter_value] 
        @execution_id,  -- execution_id from catalog.create_execution
        @object_type=50, 
        @parameter_name=N''SYNCHRONIZED'', 
        @parameter_value= 1; -- turn on synchronized execution

SELECT @execution_id

DECLARE @var0 SMALLINT = 1

EXEC [SSISDB].[catalog].[set_execution_parameter_value] @execution_id
	,@object_type = 50
	,@parameter_name = N''LOGGING_LEVEL''
	,@parameter_value = @var0

EXEC [SSISDB].[catalog].[start_execution] @execution_id
GO
', 
		@database_name=N'SSISDB', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Interface MasterPackage Satsuma]    Script Date: 11/12/2014 11:47:13 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Interface MasterPackage Satsuma', 
		@step_id=5, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'DECLARE @execution_id BIGINT

EXEC [SSISDB].[catalog].[create_execution] @package_name = N''Interface MasterPackage Satsuma.dtsx''
	,@execution_id = @execution_id OUTPUT
	,@folder_name = N''Satsuma''
	,@project_name = N''satsuma.etl''
	,@use32bitruntime = False
	,@reference_id = 1

EXEC [SSISDB].[catalog].[set_execution_parameter_value] 
        @execution_id,  -- execution_id from catalog.create_execution
        @object_type=50, 
        @parameter_name=N''SYNCHRONIZED'', 
        @parameter_value= 1; -- turn on synchronized execution

SELECT @execution_id

DECLARE @var0 SMALLINT = 1

EXEC [SSISDB].[catalog].[set_execution_parameter_value] @execution_id
	,@object_type = 50
	,@parameter_name = N''LOGGING_LEVEL''
	,@parameter_value = @var0

EXEC [SSISDB].[catalog].[start_execution] @execution_id
GO', 
		@database_name=N'SSISDB', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Mirror MasterPackage Satsuma]    Script Date: 11/12/2014 11:47:13 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Mirror MasterPackage Satsuma', 
		@step_id=6, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'DECLARE @execution_id BIGINT

EXEC [SSISDB].[catalog].[create_execution] @package_name = N''Mirror MasterPackage Satsuma.dtsx''
	,@execution_id = @execution_id OUTPUT
	,@folder_name = N''Satsuma''
	,@project_name = N''satsuma.etl''
	,@use32bitruntime = False
	,@reference_id = 1

EXEC [SSISDB].[catalog].[set_execution_parameter_value] 
        @execution_id,  -- execution_id from catalog.create_execution
        @object_type=50, 
        @parameter_name=N''SYNCHRONIZED'', 
        @parameter_value= 1; -- turn on synchronized execution

SELECT @execution_id

DECLARE @var0 SMALLINT = 1

EXEC [SSISDB].[catalog].[set_execution_parameter_value] @execution_id
	,@object_type = 50
	,@parameter_name = N''LOGGING_LEVEL''
	,@parameter_value = @var0

EXEC [SSISDB].[catalog].[start_execution] @execution_id
GO
', 
		@database_name=N'SSISDB', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Warehouse MasterPackage Satsuma]    Script Date: 11/12/2014 11:47:13 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Warehouse MasterPackage Satsuma', 
		@step_id=7, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'DECLARE @execution_id BIGINT

EXEC [SSISDB].[catalog].[create_execution] @package_name = N''Warehouse MasterPackage Satsuma.dtsx''
	,@execution_id = @execution_id OUTPUT
	,@folder_name = N''Satsuma''
	,@project_name = N''satsuma.etl''
	,@use32bitruntime = False
	,@reference_id = 1

EXEC [SSISDB].[catalog].[set_execution_parameter_value] 
        @execution_id,  -- execution_id from catalog.create_execution
        @object_type=50, 
        @parameter_name=N''SYNCHRONIZED'', 
        @parameter_value= 1; -- turn on synchronized execution

SELECT @execution_id

DECLARE @var0 SMALLINT = 1

EXEC [SSISDB].[catalog].[set_execution_parameter_value] @execution_id
	,@object_type = 50
	,@parameter_name = N''LOGGING_LEVEL''
	,@parameter_value = @var0

EXEC [SSISDB].[catalog].[start_execution] @execution_id
GO
', 
		@database_name=N'SSISDB', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Cleanup Satsuma sysssislog]    Script Date: 11/12/2014 11:47:13 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Cleanup Satsuma sysssislog', 
		@step_id=8, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'/*

Need to address this as now on separate server

DELETE
FROM [dbo].[sysssislog]
WHERE datediff(DAY,endtime,getdate()) >10

*/', 
		@database_name=N'msdb', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'INCREMENTAL LOAD (00:00)', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20140708, 
		@active_end_date=99991231, 
		@active_start_time=200, 
		@active_end_time=235959, 
		@schedule_uid=N'2e082daa-af1a-47ae-b2e8-c4b78078bfd4'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'INCREMENTAL LOAD (07:00)', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20140522, 
		@active_end_date=99991231, 
		@active_start_time=70200, 
		@active_end_time=235959, 
		@schedule_uid=N'15885118-dc3a-4233-aad6-922edd336ce9'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Incremental LOAD (13:00)', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20140522, 
		@active_end_date=99991231, 
		@active_start_time=130200, 
		@active_end_time=235959, 
		@schedule_uid=N'eaaa0ba2-4049-4ca2-89b3-68c36cd71b38'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO


