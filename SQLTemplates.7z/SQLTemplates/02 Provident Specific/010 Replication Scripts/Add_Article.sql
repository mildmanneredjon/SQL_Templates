--***************************************************************************
--* MAGIC CR NUM	 :	135424
--*
--* SCRIPT TO BE RUN AT  :	LNFS
--*
--* SCRIPT OWNER         :	Dipesh Mistry
--*
--* DATE IMPLEMENTED     : 	28/10/2015
--*
--* SCRIPT DESCRIPTION   :	Add 4 tables to the publication,initiate snapshot
--*                             and refresh subscriptions. To be run on the publisher.
--*						
--***************************************************************************

SET XACT_ABORT ON

use $(var_Database);

BEGIN TRY
BEGIN TRANSACTION
   
 DECLARE @RepTables table(table_name varchar(100))
 DECLARE @table varchar(100)

--Insert your tables here
 INSERT into @RepTables
 SELECT 'Customer_Third_Party_Engagement_Table' UNION ALL
 SELECT 'Customer_Address_Table' UNION ALL
 SELECT 'Debt_Agency' UNION ALL
 SELECT 'Third_Party_Engagement_Status' 


WHILE (SELECT count(*) FROM @RepTables)>0
BEGIN 

 SELECT TOP 1 @table = table_name FROM @RepTables

   --Add article 
   EXEC sp_addarticle 
	@publication = $(var_LNFS_Publication), 
	@article = @table, 
	@source_object = @table, 
	@source_owner = 'NFS_DBO', 
	@type = N'logbased',
        @description = null,
        @creation_script = null,
        @pre_creation_cmd = 'drop',
        
        @destination_table = @table,
        @destination_owner = 'NFS_DBO',
        @vertical_partition = 'false',
	@force_invalidate_snapshot = 1

DELETE FROM @RepTables WHERE table_name = @table

END

   --Initiate snapshot 
   EXEC sp_startpublication_snapshot @publication = $(var_LNFS_Publication)

   --Add subscriptions to new articles in a pull subscription for all the existing Subscribers to the publication
   EXEC sp_refreshsubscriptions  @publication = $(var_LNFS_Publication)

COMMIT TRANSACTION
END TRY

BEGIN CATCH
   
    
    SELECT  ERROR_LINE() ,
            ERROR_MESSAGE() ,
            ERROR_NUMBER()

END CATCH


