 
 /**
*-----------------------------------------------------------------------------*
|							Standard Support Script	                          |
|                                                                             |
|         Version 1         Dale Stewart             13/11/2014               |
|                                                                             |
*-----------------------------------------------------------------------------*

COMPATIBLITY
------------
2008 upwards

*-----------------------------------------------------------------------------*
BACKGROUND
----------


*-----------------------------------------------------------------------------*
USAGE
-----

*-----------------------------------------------------------------------------*
VERSION 1
---------

*-----------------------------------------------------------------------------*
REFERENCES
----------

*-----------------------------------------------------------------------------*
PARAMETERS
----------


*-----------------------------------------------------------------------------*
DEPENDENCIES
----------

**/

-------------------------------------------------------------------------------
:setvar checkSQLCMD "checkSQLCMD" 
GO 
IF ('$(checkSQLCMD)' = '$' + '(checkSQLCMD)') RAISERROR ('This script must be run in SQLCMD mode.', 20, 1) WITH LOG 
GO 
SELECT 'This part executes only in SQLCMD mode!'

-------------------------------------------------------------------------------
:setvar ServerName "SomeServer"
:setvar DatabaseName "SomeDatabase"
:setvar CR ""

:connect $(ServerName)
USE $(DatabaseName)

------------------------------------------------------------------------------- 
 SET XACT_ABORT ON;

 DECLARE @ExpectedRowCount INT
	, @ActualRowCount INT

SET @ExpectedRowCount = 1
SET @ActualRowCount = 0

BEGIN TRAN

	-------------------------------------------------------------------------------
	--Take a backup copy of the data
	SELECT *
	INTO DBSAdmin.dbo.CR$(CR)
	FROM 
	WHERE ;

	-------------------------------------------------------------------------------
	--perform data modification
	/**
	DELETE FROM 
	WHERE ;

	**/

	/**
	UPDATE 
	SET
	WHERE 

	**/

	SET @ActualRowCount = @@ROWCOUNT
	IF @ExpectedRowCount <> @ActualRowCount
		BEGIN
			RAISERROR ('Row count mismatch', 16, 1);
		END;


COMMIT TRAN