USE [ConnectionControl]
GO

/****** Object:  Table [dbo].[SSIS_Configurations]    Script Date: 24/10/2014 10:58:54 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[SSIS_Configurations](
	[ConfigurationFilter] [nvarchar](255) NOT NULL,
	[ConfiguredValue] [nvarchar](255) NULL,
	[PackagePath] [nvarchar](255) NOT NULL,
	[ConfiguredValueType] [nvarchar](20) NOT NULL,
 CONSTRAINT [PK_SSIS_Configurations] PRIMARY KEY CLUSTERED 
(
	[ConfigurationFilter] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO




USE [ConnectionControl];
SET NOCOUNT ON;
SET XACT_ABORT ON;
GO

BEGIN TRANSACTION;
INSERT INTO [dbo].[SSIS_Configurations]([ConfigurationFilter], [ConfiguredValue], [PackagePath], [ConfiguredValueType])
SELECT N'AuditConfigurationDisable', N'True', N'\Package\Audit Configuration.Properties[Disable]', N'Boolean' UNION ALL
SELECT N'ConfigurationFilter', N'ConfiguredValue', N'PackagePath', N'ConfiguredValueType' UNION ALL
SELECT N'KenexaArchiveFolder', N'\\hosfabaceous\comdata$\man-acc\Data Management\Systems\ATS - Kenexa\Data Drop\Archive\', N'\Package.Variables[User::ArchiveFolder].Properties[Value]', N'String' UNION ALL
SELECT N'KenexaDataDropFolder', N'\\hosfabaceous\comdata$\man-acc\Data Management\Systems\ATS - Kenexa\Data Drop\', N'\Package.Variables[User::LoadLocation].Properties[Value]', N'String' UNION ALL
SELECT N'KenexaExceptionFolder', N'\\hosfabaceous\comdata$\man-acc\Data Management\Systems\ATS - Kenexa\Data Drop\Exceptions\', N'\Package.Variables[User::ExceptionFolder].Properties[Value]', N'String' UNION ALL
SELECT N'KenexaProxyURL', N'', N'\Package.Connections[Conn_BrassRing_DispatchMessage].Properties[ProxyURL]', N'String' UNION ALL
SELECT N'KenexaResponseArchiveFolder', N'\\hosfabaceous\comdata$\man-acc\Data Management\Systems\ATS - Kenexa\Data Drop\DataDrop\KenexaResponseArchive\', N'\Package.Variables[User::ResponseArchiveFilePath_Destination].Properties[Value]', N'String' UNION ALL
SELECT N'KenexaResponseFolder', N'\\hosfabaceous\comdata$\man-acc\Data Management\Systems\ATS - Kenexa\Data Drop\DataDrop\', N'\Package.Variables[User::KenexaResponseFilePath].Properties[Value]', N'String' UNION ALL
SELECT N'KenexaUseProxy', N'false', N'\Package.Connections[Conn_BrassRing_DispatchMessage].Properties[UseProxy]', N'Boolean' UNION ALL
SELECT N'KenexaWSDLFile', N'\\hosfabaceous\comdata$\man-acc\Data Management\Systems\ATS - Kenexa\DispatchMessage.wsdl', N'\Package.Variables[User::WSDLPath].Properties[Value]', N'String' UNION ALL
SELECT N'PANCredit_ControlEmailNotificationDisable', N'True', N'\Package\Email Notification.Properties[Disable]', N'Boolean' UNION ALL
SELECT N'PANCredit_ControlRefreshUATDisable', N'true', N'\Package\Refresh UAT.Properties[Disable]', N'Boolean' UNION ALL
SELECT N'PANCredit_ControlResetBuildDisable', N'True', N'\Package\Reset Build.Properties[Disable]', N'Boolean' UNION ALL
SELECT N'PANCredit_ControlWINZIP32Archive', N'False', N'\Package\Loop and unzip archives\Unzip Archive.Properties[Disable]', N'Boolean' UNION ALL
SELECT N'PANCredit_ControlWZUNZIPArchive', N'True', N'\Package\Loop and unzip archives\WZUNZIP Archive.Properties[Disable]', N'Boolean' UNION ALL
SELECT N'PANCreditControlWINZIPExecutable', N'C:\Program Files\WinZip\WINZIP64.EXE', N'\Package\Loop and unzip archives\Unzip Archive.Properties[Executable]', N'String' UNION ALL
SELECT N'PANCreditControlWZUNZIPExecutable', N'C:\Program Files\WinZip\WINZIP64.EXE', N'\Package\Loop and unzip archives\WZUNZIP Archive.Properties[Executable]', N'String' UNION ALL
SELECT N'SSISReportSecurityDisable', N'True', N'\Package\Refresh Security.Properties[Disable]', N'Boolean' UNION ALL
SELECT N'Vanquis_Extracts_Direct_EncryptDATFilesRemoveSource', N'True', N'\Package\Generate Output\Loop OutputTable\Encrypt DAT file.Properties[removeSource]', N'Boolean' UNION ALL
SELECT N'Vanquis_Extracts_Direct_FileOutputPath', N'\\hosfabaceous\comdata$\Data Team\Satsuma\VBLExtract_Test\Output\', N'\Package.Variables[User::FileOutputPath].Properties[Value]', N'String' UNION ALL
SELECT N'Vanquis_Extracts_Direct_FileWorkPath', N'\\hosfabaceous\comdata$\Data Team\Satsuma\VBLExtract_Test\', N'\Package.Variables[User::FileWorkPath].Properties[Value]', N'String' UNION ALL
SELECT N'Vanquis_Extracts_Direct_PGPPublicKeyFilename', N'vbl_public_key.txt', N'\Package.Variables[User::PGPPublicKeyFilename].Properties[Value]', N'String'
COMMIT;
RAISERROR (N'[dbo].[SSIS_Configurations]: Insert Batch: 1.....Done!', 10, 1) WITH NOWAIT;
GO

