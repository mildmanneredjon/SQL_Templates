select 
	timecreated,
	id,
	SUSER_SNAME(SID_BINARY(userid)) as username,
	substring(message,charindex('Object Name:',message)+13,(charindex('Handle ID:',message)-4)-(charindex('Object Name:',message)+13)) as objectname,
	message,*
from rsdshaker_seclog
where id = 560--not in (576,567,528,562,682,551,540,680,552)
and message not like '%C:\Program Files\Sophos\Sophos Anti-Virus\SavService.exe%'
and message not like '%C:\WINDOWS\system32\lsass.exe%'
and message not like '%C:\Program Files\Microsoft Monitoring Agent\Agent\MonitoringHost.exe%'
and SUSER_SNAME(SID_BINARY(userid)) = 'PFG\PFGRDSIT01$'
--not needed 576,567,528,562,682,551,540,680,552
--needed 560

select distinct SUSER_SNAME(SID_BINARY(userid))
from rsdshaker_seclog
where id = 560
order by 1