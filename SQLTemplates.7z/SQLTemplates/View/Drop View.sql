-- =============================================
-- Drop View template
-- =============================================
DROP VIEW <schema_name, sysname, dbo>.<view_name, sysname, Top10Sales>