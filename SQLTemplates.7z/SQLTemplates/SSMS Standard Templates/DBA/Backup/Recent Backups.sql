SELECT  a.server_name 							as 'Server', 
	a.database_name 						as 'Database', 
	convert(varchar(25),a.backup_start_date,100) 			AS 'Start Date', 
	convert(varchar(25),a.backup_finish_date,100) 			AS 'Finish Date', 
	DATENAME(weekday, a.backup_finish_date) 			AS 'Day' ,
	datediff(minute, a.backup_start_date, a.backup_finish_date) 	as 'Mins' ,
	cast(cast(datediff(minute, a.backup_start_date, a.backup_finish_date) 
		as  decimal (8,3))/60 as  decimal (8,1)) 		as 'Hours' ,
		case
			when datediff(minute, a.backup_start_date, a.backup_finish_date) > 0
				then cast(ceiling(a.backup_size /1048576) / datediff(minute, a.backup_start_date, a.backup_finish_date)  as  decimal (8,1))
			else 0 
		end 							as 'Meg/Min',
	ceiling(a.backup_size /1048576) 				as 'Size Meg' ,	--cast((a.backup_size /1048576) as decimal (9,2)) as 'Size Meg'  ,
	cast((a.backup_size /1073741824) as decimal (9,2)) 		as 'Gig',         -- div by 1073741824 to get gig
	a.user_name,a.backup_size 					as 'Raw Size'  
FROM         msdb.dbo.backupset a
join  msdb.dbo.backupset b on a.server_name = b.server_name and a.database_name = b.database_name 
WHERE     a.type = 'D'  and b.type = 'D'   /*D=Full*/      AND a.backup_start_date > getdate() -40   -- Last X days
			
group by a.server_name, a.database_name,  a.backup_start_date, a.backup_finish_date, a.backup_size, a.user_name
order by a.backup_start_date desc


SELECT SERVERPROPERTY('Servername') AS [Server]
     , bs.database_name
     , bs.backup_start_date
     , bs.backup_finish_date
     , bs.expiration_date
     , bs.[type] AS backup_type
     , bs.backup_size
     , bmf.logical_device_name
     , bmf.physical_device_name
     , bs.name AS backupset_name
     , bs.[description]
FROM msdb.dbo.backupmediafamily bmf
     INNER JOIN msdb.dbo.backupset bs
         ON bmf.media_set_id = bs.media_set_id
WHERE CONVERT(datetime, bs.backup_start_date, 120) >= DATEADD(d, -2, GETDATE())
ORDER BY bs.database_name
    , bs.backup_finish_date;


SELECT sdb.Name AS DatabaseName,
COALESCE(CONVERT(VARCHAR(12), MAX(bus.backup_finish_date), 101),'-') AS LastBackUpTime
FROM sys.sysdatabases sdb
LEFT OUTER JOIN msdb.dbo.backupset bus ON bus.database_name = sdb.name
GROUP BY sdb.Name


SELECT SERVERPROPERTY('Servername') AS [Server]
	, sd.name
     , Backups.database_name
     , Backups.backup_start_date
     , Backups.backup_finish_date
     , Backups.expiration_date
     , Backups.backup_type 
     , Backups.backup_size
     , Backups.logical_device_name
     , Backups.physical_device_name
     , Backups.backupset_name 
     , Backups.[description]
FROM sys.databases sd
	LEFT OUTER JOIN 
	(
		SELECT 
			bs.database_name
			 , bs.backup_start_date
			 , bs.backup_finish_date
			 , bs.expiration_date
			 , bs.[type] AS backup_type
			 , bs.backup_size
			 , bmf.logical_device_name
			 , bmf.physical_device_name
			 , bs.name AS backupset_name
			 , bs.[description]
		FROM msdb.dbo.backupset bs
			INNER JOIN msdb.dbo.backupmediafamily bmf
				 ON bmf.media_set_id = bs.media_set_id
		WHERE CONVERT(datetime, bs.backup_start_date, 120) >= DATEADD(d, -1, GETDATE())
			AND bs.[type] = 'D'
	) AS Backups
ON Backups.database_name = sd.name
ORDER BY Backups.database_name
    , Backups.backup_finish_date;

