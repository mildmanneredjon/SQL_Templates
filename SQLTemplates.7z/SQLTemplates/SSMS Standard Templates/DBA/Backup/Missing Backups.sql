SELECT SERVERPROPERTY('Servername') AS [Server]
     , bs.database_name
     , bs.backup_start_date
     , bs.backup_finish_date
     , bs.expiration_date
     , bs.[type] AS backup_type
     , bs.backup_size
     , bmf.logical_device_name
     , bmf.physical_device_name
     , bs.name AS backupset_name
     , bs.[description]
FROM msdb.dbo.backupmediafamily bmf
     INNER JOIN msdb.dbo.backupset bs
         ON bmf.media_set_id = bs.media_set_id
	LEFT OUTER JOIN sysdatabases sd
		ON sd.name = bs.database_name
WHERE CONVERT(datetime, bs.backup_start_date, 120) >= DATEADD(d, -1, GETDATE())
	AND family_sequence_number = 1
	AND bs.[type] = 'D'
ORDER BY bs.database_name
    , bs.backup_finish_date;