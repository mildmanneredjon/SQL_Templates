create master key encryption by password = ''
-------------------------------------------------------------------------------
--restore the backup certificate for encrypted backups
CREATE CERTIFICATE BackupCert
    FROM FILE = '\\sqlbackupderby\DatebaseCertAndKeys\HOEVADB01\HOEVADB01_BackupCert.bak'
    WITH PRIVATE KEY ( FILE = '\\sqlbackupderby\DatebaseCertAndKeys\HOEVADB01\HOEVADB01_BackupCertKey.bak' ,
    DECRYPTION BY PASSWORD = '' );



-------------------------------------------------------------------------------
DECLARE @sql NVARCHAR(4000)
	, @backupfile NVARCHAR(500)
	, @databasename VARCHAR(200)

SET @backupfile = N'E:\'

-------------------------------------------------------------------------------
	DECLARE @headeronly TABLE
	(
		BackupName nvarchar(128)
		, BackupDescription nvarchar(255)
		, BackupType smallint
		, ExpirationDate datetime
		, Compressed bit
		, Position smallint
		, DeviceType tinyint
		, UserName nvarchar(128)
		, ServerName nvarchar(128)
		, DatabaseName nvarchar(128)
		, DatabaseVersion int
		, DatabaseCreationDate datetime
		, BackupSize numeric(25,0)
		, FirstLSN numeric(25,0)
		, LastLSN numeric(25,0)
		, CheckpointLSN numeric(25,0)
		, DatabaseBackupLSN numeric(25,0)
		, BackupStartDate datetime
		, BackupFinishDate datetime
		, SortOrder smallint
		, [CodePage] smallint
		, UnicodeLocaleID int
		, UnicodeComparisonStyle int
		, CompatabilityLevel tinyint
		, SoftwareVendorID int
		, SoftwareVersionMajor int
		, SoftwareVersionMinor int
		, SoftwareVersionBuild int
		, MachineName nvarchar(128)
		, Flags int
		, BindingID uniqueidentifier
		, RecoveryForkId uniqueidentifier
		, Collation nvarchar(128)
		, FamilyGUID uniqueidentifier
		, HasBulkLoggedData bit
		, IsSnapshot bit
		, IsReadOnly bit
		, IsSingleUser bit
		, HasBackupChecksums bit
		, IsDamaged bit
		, BeginsLogChain bit
		, HasIncompleteMetaData bit 
		, IsForceOffline bit 
		, IsCopyOnly bit
		, FirstRecoveryForkId uniqueidentifier
		, ForkPointLSN numeric(25,0)
		, RecoveryModel nvarchar(60)
		, DifferentialBaseLSN numeric(25,0)
		, DifferentialBaseGUID uniqueidentifier
		, BackupTypeDescription nvarchar(60)
		, BackupSetGUID uniqueidentifier
		, CompressedBackupSize bigint
		, containment tinyint
		, KeyAlgorithm nvarchar(32)
		, EncryptorThumbprint varbinary(20)
		, EncryptorType nvarchar(32)
	)

DECLARE @filelistonly TABLE
(
	LogicalName VARCHAR(2000)
	, PhysicalName VARCHAR(2000)
	, [Type] CHAR(1)
	, FileGroupName VARCHAR(200)
	, Size numeric(20,0)
	, MaxSize numeric(25,0)
	, FileId bigint
	, CreateLSN numeric(25,0)
	, DropLSN numeric(25,0)
	, UniqueId uniqueidentifier
	, ReadOnlyLSN numeric(25,0)
	, ReadWriteLSN numeric(25,0)
	, BackupSizeInBytes bigint
	, SourceBlockSize int
	, FileGroupID int
	, LogGroupGUID uniqueidentifier
	, DifferentialBaseLSN numeric(25,0)
	, DifferentialBaseGUID uniqueidentifier
	, IsReadOnly bit
	, IsPresent bit
	, TDEThumbPrint varbinary(32) 
	, SnapshotURL nvarchar(360)
)




-------------------------------------------------------------------------------
--set the value for the backup file


SET @sql = 'restore filelistonly from disk = ''' + @backupfile + ''''

INSERT INTO @filelistonly
EXEC sp_executesql @sql
--EXEC master.dbo.xp_restore_filelistonly @filename = @backupfile

-------------------------------------------------------------------------------
--confirm the backup file exists

SET @sql = 'restore headeronly from disk = ''' + @backupfile + ''''

INSERT INTO @headeronly
EXEC sp_executesql @sql
--EXEC master.dbo.xp_restore_headeronly @filename = @backupfile

-------------------------------------------------------------------------------
--now build the restore statement
SELECT TOP 1 @databasename = DatabaseName FROM @headeronly


SET @sql = ''
SET @sql = 'ALTER DATABASE ' + @databasename + ' SET SINGLE_USER WITH ROLLBACK IMMEDIATE' + CHAR(13)
SET @sql = @sql + 'ALTER DATABASE ' + @databasename + ' SET MULTI_USER WITH NO_WAIT' + CHAR(13)
SET @sql = @sql + 'RESTORE DATABASE ' + @databasename + CHAR(13)
SET @sql = @sql + 'FROM DISK = N''' + @backupfile + '''' + CHAR(13)
SET @sql = @sql + 'WITH FILE = 1' + CHAR(13)
--SET @sql = @sql + ', REPLACE' + CHAR(13)
SET @sql = @sql + ', NORECOVERY' + CHAR(13)
SET @sql = @sql + ', STATS = 10' + CHAR(13)
SELECT @sql = @sql + ', MOVE N''' + LogicalName + ''' TO N''' + PhysicalName + '''' + CHAR(13)
FROM @filelistonly

SELECT @sql

