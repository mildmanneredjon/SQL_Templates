EXEC sp_change_users_login 'Report'

EXEC sp_change_users_login 'Auto_fix', '<Login name>'