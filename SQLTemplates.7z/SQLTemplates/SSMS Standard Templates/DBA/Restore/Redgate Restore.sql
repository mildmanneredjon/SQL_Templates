-------------------------------------------------------------------------------
DECLARE @sql NVARCHAR(4000)
	, @backupfile NVARCHAR(500)
	, @databasename VARCHAR(200)
	, @encryptionpassword VARCHAR(200)

SET @backupfile = N'\\HOSWAKBACKUP1\REDGATEX\GONZO\FULL_GONZO_FOCALPOINT_20160314_092511.SQB'
SET @encryptionpassword = N'2UJE85ob187p8266'
SET @encryptionpassword = N''

-------------------------------------------------------------------------------


	DECLARE @headeronly TABLE
	(
		Description nvarchar(128)
	)

DECLARE @filelistonly TABLE
(
	LogicalName VARCHAR(2000)
	, PhysicalName VARCHAR(2000)
	, [Type] CHAR(1)
	, FileGroupName VARCHAR(200)
	, Size numeric(20,0)
	, MaxSize numeric(25,0)
	, FileId bigint
	, CreateLSN numeric(25,0)
	, DropLSN numeric(25,0)
	, UniqueId uniqueidentifier
	, ReadOnlyLSN numeric(25,0)
	, ReadWriteLSN numeric(25,0)
	, BackupSizeInBytes bigint
	, SourceBlockSize int
	, FileGroupID int
	, LogGroupGUID uniqueidentifier
	, DifferentialBaseLSN numeric(25,0)
	, DifferentialBaseGUID uniqueidentifier
	, IsReadOnly bit
	, IsPresent bit
	--, TDEThumbPrint varbinary(32) 
)




-------------------------------------------------------------------------------
--set the value for the backup file
if len(@encryptionpassword) > 0
begin
SET @sql = 'EXECUTE master..sqlbackup ''-SQL "RESTORE FILELISTONLY FROM DISK = '''''+ @backupfile +''''' WITH PASSWORD = ''''' + @encryptionpassword + ''''', SINGLERESULTSET  "''' 
end
else
begin
SET @sql = 'EXECUTE master..sqlbackup ''-SQL "RESTORE FILELISTONLY FROM DISK = '''''+ @backupfile +''''' WITH SINGLERESULTSET "'''
end

INSERT INTO @filelistonly
EXEC sp_executesql @sql
--EXEC master.dbo.xp_restore_filelistonly @filename = @backupfile

-------------------------------------------------------------------------------
--confirm the backup file exists
SET @sql = 'EXECUTE master..sqlbackup ''-SQL "RESTORE SQBHEADERONLY FROM DISK = '''''+ @backupfile +''''' WITH PASSWORD = ''''' + @encryptionpassword + ''''', SINGLERESULTSET "'''

INSERT INTO @headeronly
EXEC sp_executesql @sql

SET @databasename = ''
SELECT @databasename = right(Description, len(Description) - charindex(':',Description) - 1)
FROM @headeronly
WHERE Description like '%Database name%'

--EXEC master.dbo.xp_restore_headeronly @filename = @backupfile

-------------------------------------------------------------------------------
--now build the restore statement
SET @sql = ''
SET @sql = 'ALTER DATABASE ' + @databasename + ' SET SINGLE_USER WITH ROLLBACK IMMEDIATE' + CHAR(13)
SET @sql = @sql + 'ALTER DATABASE ' + @databasename + ' SET MULTI_USER WITH NO_WAIT' + CHAR(13)
SET @sql = @sql + 'EXECUTE master..sqlbackup ''-SQL "RESTORE DATABASE [' + @databasename + ']' + CHAR(13)
SET @sql = @sql + 'FROM DISK = N''''' + @backupfile + '''''' + CHAR(13)
SET @sql = @sql + 'WITH NORECOVERY' + CHAR(13)
--SET @sql = @sql + ', STATS = 10' + CHAR(13)
SELECT @sql = @sql + ', MOVE N''''' + LogicalName + ''''' TO N''''' + PhysicalName + '''''' + CHAR(13)
FROM @filelistonly
SET @sql = @sql + ', PASSWORD = ''''2UJE85ob187p8266''''"''' + CHAR(13)

SELECT @sql




