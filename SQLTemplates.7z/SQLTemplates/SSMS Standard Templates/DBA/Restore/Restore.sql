-------------------------------------------------------------------------------
DECLARE @sql NVARCHAR(4000)
	, @backupfile NVARCHAR(500)
	, @databasename VARCHAR(200)
	, @Type VARCHAR(200) = 'NATIVE'
	, @Version VARCHAR(200) = '2005'

SET @type = 'REDGATE'
SET @version = '2012'
SET @backupfile = N'E:\'

-------------------------------------------------------------------------------
IF (@version = '2012')
BEGIN
	DECLARE @headeronly TABLE
	(
		BackupName nvarchar(128)
		, BackupDescription nvarchar(255)
		, BackupType smallint
		, ExpirationDate datetime
		, Compressed bit
		, Position smallint
		, DeviceType tinyint
		, UserName nvarchar(128)
		, ServerName nvarchar(128)
		, DatabaseName nvarchar(128)
		, DatabaseVersion int
		, DatabaseCreationDate datetime
		, BackupSize numeric(25,0)
		, FirstLSN numeric(25,0)
		, LastLSN numeric(25,0)
		, CheckpointLSN numeric(25,0)
		, DatabaseBackupLSN numeric(25,0)
		, BackupStartDate datetime
		, BackupFinishDate datetime
		, SortOrder smallint
		, [CodePage] smallint
		, UnicodeLocaleID int
		, UnicodeComparisonStyle int
		, CompatabilityLevel tinyint
		, SoftwareVendorID int
		, SoftwareVersionMajor int
		, SoftwareVersionMinor int
		, SoftwareVersionBuild int
		, MachineName nvarchar(128)
		, Flags int
		, BindingID uniqueidentifier
		, RecoveryForkId uniqueidentifier
		, Collation nvarchar(128)
		, FamilyGUID uniqueidentifier
		, HasBulkLoggedData bit
		, IsSnapshot bit
		, IsReadOnly bit
		, IsSingleUser bit
		, HasBackupChecksums bit
		, IsDamaged bit
		, BeginsLogChain bit
		, HasIncompleteMetaData bit 
		, IsForceOffline bit 
		, IsCopyOnly bit
		, FirstRecoveryForkId uniqueidentifier
		, ForkPointLSN numeric(25,0)
		, RecoveryModel nvarchar(60)
		, DifferentialBaseLSN numeric(25,0)
		, DifferentialBaseGUID uniqueidentifier
		, BackupTypeDescription nvarchar(60)
		, BackupSetGUID uniqueidentifier
		, CompressedBackupSize bigint
		, containment tinyint
	)
END

--IF (@version = '2005')
--BEGIN
--	DECLARE @headeronly TABLE
--	(
--		FileNumber INT
--		, BackupFormat SMALLINT
--		, [Guid] uniqueidentifier
--		, BackupName VARCHAR(500)
--		, BackupDescription VARCHAR(2000)
--		, BackupType SMALLINT
--		, ExpirationDate DATETIME
--		, Compressed SMALLINT
--		, Position SMALLINT
--		, DeviceType SMALLINT
--		, UserName VARCHAR(255)
--		, ServerName VARCHAR(255)
--		, DatabaseName VARCHAR(2000)
--		, DatabaseVersion SMALLINT
--		, DatabaseCreationDate DATETIME
--		, BackupSize BIGINT
--		, FirstLSN VARCHAR(2000)
--		, LastLSN VARCHAR(2000)
--		, CheckpointLSN VARCHAR(2000)
--		, DiffrentialBaseLSN VARCHAR(2000)
--		, BackupStartDate DATETIME
--		, BackupFinishDate DATETIME
--		, SortOrder INT
--		, [CodePage] INT
--		, CompatibilityLevel INT
--		, SoftwareVendorId INT
--		, SoftwareVersionMajor SMALLINT 
--		, SoftwareVersionMinor INT
--		, SoftwareVersionBuild INT
--		, MachineName VARCHAR(200)
--		, BindingId SMALLINT
--		, RecoveryForkId INT
--		, [Encryption] TINYINT
--		, IsCopyOnly VARCHAR(10)
--	)
--END

--IF (@version = '2005')
--BEGIN
--	DECLARE @filelistonly TABLE
--	(
--		LogicalName VARCHAR(2000)
--		, PhysicalName VARCHAR(2000)
--		, [Type] CHAR(1)
--		, FileGroupName VARCHAR(200)
--		, Size numeric(20,0)
--		, MaxSize numeric(25,0)
--		, FileId bigint
--		, CreateLSN numeric(25,0)
--		, DropLSN numeric(25,0)
--		, UniqueId uniqueidentifier
--		, ReadOnlyLSN numeric(25,0)
--		, ReadWriteLSN numeric(25,0)
--		, BackupSizeInBytes bigint
--		, SourceBlockSize int
--		, FileGroupID int
--		, LogGroupGUID uniqueidentifier
--		, DifferentialBaseLSN numeric(25,0)
--		, DifferentialBaseGUID uniqueidentifier
--		, IsReadOnly bit
--		, IsPresent bit
--	)
--END

IF (@version = '2012')
BEGIN
	DECLARE @filelistonly TABLE
	(
		LogicalName VARCHAR(2000)
		, PhysicalName VARCHAR(2000)
		, [Type] CHAR(1)
		, FileGroupName VARCHAR(200)
		, Size numeric(20,0)
		, MaxSize numeric(25,0)
		, FileId bigint
		, CreateLSN numeric(25,0)
		, DropLSN numeric(25,0)
		, UniqueId uniqueidentifier
		, ReadOnlyLSN numeric(25,0)
		, ReadWriteLSN numeric(25,0)
		, BackupSizeInBytes bigint
		, SourceBlockSize int
		, FileGroupID int
		, LogGroupGUID uniqueidentifier
		, DifferentialBaseLSN numeric(25,0)
		, DifferentialBaseGUID uniqueidentifier
		, IsReadOnly bit
		, IsPresent bit
		, TDEThumbPrint varbinary(32) 
	)
END



-------------------------------------------------------------------------------
--set the value for the backup file


SET @sql = 'restore filelistonly from disk = ''' + @backupfile + ''''

INSERT INTO @filelistonly
EXEC sp_executesql @sql
--EXEC master.dbo.xp_restore_filelistonly @filename = @backupfile

-------------------------------------------------------------------------------
--confirm the backup file exists

SET @sql = 'restore headeronly from disk = ''' + @backupfile + ''''

INSERT INTO @headeronly
EXEC sp_executesql @sql
--EXEC master.dbo.xp_restore_headeronly @filename = @backupfile

-------------------------------------------------------------------------------
--now build the restore statement
SELECT TOP 1 @databasename = DatabaseName FROM @headeronly

--SET @sql = ''
--SET @sql = @sql + 'exec master.dbo.xp_restore_database @database = N''' + @databasename + ''' ,' + CHAR(13)
--SET @sql = @sql + '@filename = N''' + @backupfile + ''' ,' + CHAR(13)
--SET @sql = @sql + '@filenumber = 1,' + CHAR(13)
--SET @sql = @sql + '@with = N''REPLACE'',' + CHAR(13)
--SET @sql = @sql + '@with = N''NORECOVERY'',' + CHAR(13)
--SET @sql = @sql + '@with = N''STATS = 10'',' + CHAR(13)
--SELECT @sql = @sql + '@with = N''MOVE N''''' + LogicalName + ''''' TO N''''' + PhysicalName + ''''''',' + CHAR(13)
--FROM @filelistonly
--SET @sql = @sql + '@affinity = 0,' + CHAR(13)
--SET @sql = @sql + '@logging = 0' 


SET @sql = ''
SET @sql = 'ALTER DATABASE ' + @databasename + ' SET SINGLE_USER WITH ROLLBACK IMMEDIATE' + CHAR(13)
SET @sql = @sql + 'ALTER DATABASE ' + @databasename + ' SET MULTI_USER WITH NO_WAIT' + CHAR(13)
SET @sql = @sql + 'RESTORE DATABASE ' + @databasename + CHAR(13)
SET @sql = @sql + 'FROM DISK = N''' + @backupfile + '''' + CHAR(13)
SET @sql = @sql + 'WITH FILE = 1' + CHAR(13)
--SET @sql = @sql + ', REPLACE' + CHAR(13)
SET @sql = @sql + ', NORECOVERY' + CHAR(13)
SET @sql = @sql + ', STATS = 10' + CHAR(13)
SELECT @sql = @sql + ', MOVE N''' + LogicalName + ''' TO N''' + PhysicalName + '''' + CHAR(13)
FROM @filelistonly

SELECT @sql

