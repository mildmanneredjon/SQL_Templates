:CONNECT HOSQUESTION\TIME

SELECT [server_id]
      ,[server_group_id]
      ,[Group_Name]
      ,[parent_id]
      ,[name]
      ,[server_name]
      ,[description]
      ,[server_type]
  FROM [Server_Info].[dbo].[Server_Descriptions]
  WHERE description LIKE '%BATMAN%'


SELECT *
FROM [Server_Info].[dbo].[All_Online_PFMS_SQL_Servers]
WHERE SQL_SERVER_NAME LIKE '%BATMAN%'