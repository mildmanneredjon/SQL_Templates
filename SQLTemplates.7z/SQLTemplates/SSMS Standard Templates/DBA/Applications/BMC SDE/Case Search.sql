select top 100 t.sequence, t.description, t.* 
	FROM MagicSDE._SMDBA_._TELMASTE_ t (nolock)
		--JOIN [_SMDBA_].[_CUSTOMER_] c
		--				ON t.client = c.sequence
where Description like '%HOSWIZARD\PRESTO%'
	AND LASTMODIFIED BETWEEN '20140818' AND '20150101'
	--AND c.client = 'conroys'
	--and lastuser = 'JONESA'
--ORDER by t.LASTMODIFIED desc


