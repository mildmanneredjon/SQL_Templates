SELECT Interaction_Number 
FROM dbo.Interaction WITH (NOLOCK)
WHERE Rn_Create_Date between DATEADD(d, DATEDIFF(d, 0, GETDATE() - 1), 0) and DATEADD(d, DATEDIFF(d, 0, GETDATE()), 0)
	AND SUBSTRING(Interaction_Number, 1, 1) = '8'
	AND Interaction_Number NOT IN
	(SELECT Interaction_Number FROM LS_MAIN.PFMS_CC_ED.dbo.Interaction WITH (NOLOCK)
	WHERE Rn_Create_Date between DATEADD(d, DATEDIFF(d, 0, GETDATE() - 1), 0) and DATEADD(d, DATEDIFF(d, 0, GETDATE()), 0))
