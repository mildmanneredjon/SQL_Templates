SET NOCOUNT ON;

DECLARE @FocusNum BIGINT
DECLARE @RapidNum BIGINT
DECLARE @TallyNum BIGINT

DECLARE @CustomerForename VARCHAR(200)
DECLARE @CustomerSurname VARCHAR(200)

--set @FocusNum = $(FocusNum)
--set @RapidNum = $(RapidNum)
set @TallyNum = '14357215'

SET @CustomerForename = 'Frank%'
SET @CustomerSurname = 'Worthington%'

--BIS = Tallyman
--NFS = Focus
--PRA =
--TAL =  

SELECT *
FROM    DW_EDW.EDW_DBO.DW_BIS_CUSTOMER_DIM
WHERE Forename LIKE @CustomerForename
AND Surname LIKE @CustomerSurname


SELECT *
FROM    DW_EDW.EDW_DBO.DW_NFS_CUSTOMER_DIM
WHERE Forename LIKE @CustomerForename
AND Surname LIKE @CustomerSurname


IF @FocusNum IS NULL
    AND @RapidNum IS NOT NULL
    BEGIN
        SET @FocusNum = ( SELECT    Customer_Id
                          FROM      DW_STAGING.EDW_DBO.DW_CUSTOMER_NUMBER_CONVERSION_STG
                          WHERE     External_Customer_Num = @RapidNum
                        )
    END

IF @RapidNum IS NULL
    AND @FocusNum IS NOT NULL
    BEGIN
        SET @RapidNum = ( SELECT    External_Customer_Num
                          FROM      DW_STAGING.EDW_DBO.DW_CUSTOMER_NUMBER_CONVERSION_STG
                          WHERE     Customer_Id = @FocusNum
                        )
    END

IF @FocusNum IS NULL
    AND @RapidNum IS NULL
    BEGIN
        SET @FocusNum = @TallyNum
        SET @RapidNum = @TallyNum
    END

IF @FocusNum IS NULL
    AND @TallyNum IS NULL
    BEGIN
        SET @FocusNum = @RapidNum
        SET @TallyNum = @RapidNum
    END

IF @RapidNum IS NULL
    AND @TallyNum IS NULL
    BEGIN
        SET @RapidNum = @FocusNum
        SET @TallyNum = @FocusNum
    END

IF EXISTS ( SELECT  1
            FROM    DW_EDW.EDW_DBO.DW_BIS_CUSTOMER_DIM
            WHERE   Customer_Unique_Identifier = @RapidNum
                    OR Customer_Unique_Identifier = @FocusNum )
    BEGIN
        SELECT  Customer_SK
              , Customer_Unique_Identifier
              , Bis_Customer_Number
              , Title
              , Forename
              , Surname
              , Birth_Date
              , House_Number
              , Address_Line_1
              , Address_Line_2
              , Address_Line_3
              , Postcode
              , Deceased_Flag
              , Tallyman_Deceased_Flag
              , Last_Updated_Date
              , Annual_Statement_Date
              , Cdr_Transfer_Balance
        FROM    DW_EDW.EDW_DBO.DW_BIS_CUSTOMER_DIM
        WHERE   Customer_Unique_Identifier = @RapidNum
                OR Customer_Unique_Identifier = @FocusNum
    END
IF @@rowcount <> 0
    PRINT 'DW_EDW.EDW_DBO.DW_BIS_CUSTOMER_DIM'

IF EXISTS ( SELECT  1
            FROM    DW_EDW.EDW_DBO.DW_NFS_CUSTOMER_DIM
            WHERE   Customer_Id = @FocusNum )
    BEGIN
--	select Customer_SK,Customer_Id,Title_Code,Surname,Forename,Postcode,Customer_Creation_Date,Customer_Status_Code,Paid_Up_Date,Written_Off_Date,Last_Updated_Date,Tallyman_Deceased_Flag,Cdr_Transfer_Balance
        SELECT  *
        FROM    DW_EDW.EDW_DBO.DW_NFS_CUSTOMER_DIM
        WHERE   Customer_Id = @FocusNum

        SELECT  *
        FROM    DW_EDW.EDW_DBO.DW_NFS_CUSTOMER_ADDRESS
        WHERE   Customer_Id = @FocusNum
    END
IF @@rowcount <> 0
    PRINT 'DW_EDW.EDW_DBO.DW_NFS_CUSTOMER_DIM, DW_EDW.EDW_DBO.DW_NFS_CUSTOMER_ADDRESS'

IF EXISTS ( SELECT  1
            FROM    DW_EDW.EDW_DBO.DW_PRA_CUSTOMER_DIM
            WHERE   Customer_Id = @FocusNum
                    OR Rapid_Unique_Number = @RapidNum
                    OR Tallyman_Unique_Number = @TallyNum )
    BEGIN	
        SELECT  *
        FROM    DW_EDW.EDW_DBO.DW_PRA_CUSTOMER_DIM
        WHERE   Customer_Id = @FocusNum
                OR Rapid_Unique_Number = @RapidNum
                OR Tallyman_Unique_Number = @TallyNum
    END
IF @@rowcount <> 0
    PRINT 'DW_EDW.EDW_DBO.DW_PRA_CUSTOMER_DIM'

IF EXISTS ( SELECT  1
            FROM    DW_EDW.EDW_DBO.DW_TAL_CUSTOMER_TABLE
            WHERE   Tallyman_Customer_Number = @FocusNum
                    OR Tallyman_Unique_Number = @TallyNum
                    OR Rapid_Unique_Number = @RapidNum )
    BEGIN	
        SELECT  *
        FROM    DW_EDW.EDW_DBO.DW_TAL_CUSTOMER_TABLE
        WHERE   Tallyman_Customer_Number = @FocusNum
                OR Tallyman_Unique_Number = @TallyNum
                OR Rapid_Unique_Number = @RapidNum
    END
IF @@rowcount <> 0
    PRINT 'DW_EDW.EDW_DBO.DW_TAL_CUSTOMER_TABLE'

IF EXISTS ( SELECT  1
            FROM    DW_EDW.EDW_DBO.DW_PRA_APPORTION_TABLE
            WHERE   Tallyman_Unique_Number = @TallyNum )
    BEGIN
        SELECT  *
        FROM    DW_EDW.EDW_DBO.DW_PRA_APPORTION_TABLE
        WHERE   Tallyman_Unique_Number = @TallyNum
    END
IF @@rowcount <> 0
    PRINT 'DW_EDW.EDW_DBO.DW_PRA_APPORTION_TABLE'

IF EXISTS ( SELECT  1
            FROM    DW_EDW.EDW_DBO.DW_BIS_AGREEMENT_DIM
            WHERE   Customer_Unique_Identifier = @RapidNum
                    OR Customer_Unique_Identifier = @FocusNum )
    BEGIN
--	select 	Agreement_SK,Agreement_Identifier,Customer_Unique_Identifier,Paid_Up_Date,Written_Off_Date,Tallyman_Balance,Tallyman_Write_Off_Date,Annual_Statement_Date,Last_Updated_Date
        SELECT  *
        FROM    DW_EDW.EDW_DBO.DW_BIS_AGREEMENT_DIM
        WHERE   Customer_Unique_Identifier = @RapidNum
                OR Customer_Unique_Identifier = @FocusNum
    END
IF @@rowcount <> 0
    PRINT 'DW_EDW.EDW_DBO.DW_BIS_AGREEMENT_DIM'

IF EXISTS ( SELECT  1
            FROM    DW_EDW.EDW_DBO.DW_NFS_AGREEMENT_DIM
            WHERE   Customer_Id = @FocusNum )
    BEGIN
--	select 	Agreement_SK,Agreement_Id,Agreement_Number,Customer_Id,Paid_Up_Date,Written_Off_Date,Cais_Submitted_Flag,Annual_Statement_Date,Settled_Date,Tallyman_Balance,Last_Updated_Date,Tallyman_Write_Off_Date,Exclude_From_Apportionment_Flag,Absolute_Arrears,Outstanding_Balance,Last_Annual_Statement_Date,Last_Initial_Arrears_Notice_Date,Arrears_Review_Cancellation_Date
        SELECT  *
        FROM    DW_EDW.EDW_DBO.DW_NFS_AGREEMENT_DIM
        WHERE   Customer_Id = @FocusNum
    END
IF @@rowcount <> 0
    PRINT 'DW_EDW.EDW_DBO.DW_NFS_AGREEMENT_DIM'

IF EXISTS ( SELECT  1
            FROM    DW_STAGING.EDW_DBO.DW_TAL_EXCEPTION_TABLE
            WHERE   Tallyman_Unique_Number = CONVERT(VARCHAR, @TallyNum)
                    OR Tallyman_Customer_Number = CONVERT(VARCHAR, @FocusNum)
                    OR Rapid_Unique_Number = CONVERT(VARCHAR, @RapidNum) )
    BEGIN
        SELECT  *
        FROM    DW_STAGING.EDW_DBO.DW_TAL_EXCEPTION_TABLE
        WHERE   Tallyman_Unique_Number = CONVERT(VARCHAR, @TallyNum)
                OR Tallyman_Customer_Number = CONVERT(VARCHAR, @FocusNum)
                OR Rapid_Unique_Number = CONVERT(VARCHAR, @RapidNum)
        ORDER BY Last_Updated_Date
    END
IF @@rowcount <> 0
    PRINT 'DW_STAGING.EDW_DBO.DW_TAL_EXCEPTION_TABLE'

IF EXISTS ( SELECT  1
            FROM    DW_STAGING.EDW_DBO.DW_PRA_TAL_WRITE_OFF_HIS
            WHERE   Tallyman_Unique_Number = @TallyNum )
    BEGIN
        SELECT  *
        FROM    DW_STAGING.EDW_DBO.DW_PRA_TAL_WRITE_OFF_HIS
        WHERE   Tallyman_Unique_Number = @TallyNum
        ORDER BY Last_Updated_Date
    END
IF @@rowcount <> 0
    PRINT 'DW_STAGING.EDW_DBO.DW_PRA_TAL_WRITE_OFF_HIS'

IF EXISTS ( SELECT  1
            FROM    DW_STAGING.EDW_DBO.DW_PRA_TAL_CUSTOMER_HIS
            WHERE   Tallyman_Unique_Number = CONVERT(VARCHAR, @TallyNum)
                    OR Tallyman_Customer_Number = CONVERT(VARCHAR, @FocusNum)
                    OR Rapid_Unique_Number = CONVERT(VARCHAR, @RapidNum) )
    BEGIN
        SELECT  *
        FROM    DW_STAGING.EDW_DBO.DW_PRA_TAL_CUSTOMER_HIS
        WHERE   Tallyman_Unique_Number = CONVERT(VARCHAR, @TallyNum)
                OR Tallyman_Customer_Number = CONVERT(VARCHAR, @FocusNum)
                OR Rapid_Unique_Number = CONVERT(VARCHAR, @RapidNum)
    END
IF @@rowcount <> 0
    PRINT 'DW_STAGING.EDW_DBO.DW_PRA_TAL_CUSTOMER_HIS'

IF EXISTS ( SELECT  1
            FROM    DW_STAGING.EDW_DBO.DW_PRA_CUSTOMER_DIM
            WHERE   Rapid_Unique_Number = @RapidNum
                    OR Tallyman_Unique_Number = @TallyNum
                    OR customer_id = @FocusNum )
    BEGIN
        SELECT  *
        FROM    DW_STAGING.EDW_DBO.DW_PRA_CUSTOMER_DIM
        WHERE   Rapid_Unique_Number = @RapidNum
                OR Tallyman_Unique_Number = @TallyNum
                OR customer_id = @FocusNum
    END
IF @@rowcount <> 0
    PRINT 'DW_STAGING.EDW_DBO.DW_PRA_CUSTOMER_DIM'

IF EXISTS ( SELECT  1
            FROM    DW_STAGING.EDW_DBO.DW_TAL_TRANSACTION_EXCEPTION_DATA
            WHERE   Tallyman_Customer_Number = @FocusNum
                    OR Tallyman_Unique_Number = @TallyNum
                    OR Rapid_Unique_Number = @RapidNum )
    BEGIN
        SELECT  *
        FROM    DW_STAGING.EDW_DBO.DW_TAL_TRANSACTION_EXCEPTION_DATA
        WHERE   Tallyman_Customer_Number = @FocusNum
                OR Tallyman_Unique_Number = @TallyNum
                OR Rapid_Unique_Number = @RapidNum
        ORDER BY Last_Updated_Date
    END
IF @@rowcount <> 0
    PRINT 'DW_STAGING.EDW_DBO.DW_TAL_TRANSACTION_EXCEPTION_DATA'

IF EXISTS ( SELECT  1
            FROM    DW_STAGING.EDW_DBO.DW_TAL_WRITE_OFF_EXCEPTION_DATA
            WHERE   Tallyman_Customer_Number = @FocusNum
                    OR Tallyman_Unique_Number = @TallyNum
                    OR Rapid_Unique_Number = @RapidNum )
    BEGIN
        SELECT  *
        FROM    DW_STAGING.EDW_DBO.DW_TAL_WRITE_OFF_EXCEPTION_DATA
        WHERE   Tallyman_Customer_Number = @FocusNum
                OR Tallyman_Unique_Number = @TallyNum
                OR Rapid_Unique_Number = @RapidNum
        ORDER BY Last_Updated_Date
    END
IF @@rowcount <> 0
    PRINT 'DW_STAGING.EDW_DBO.DW_TAL_WRITE_OFF_EXCEPTION_DATA'

IF EXISTS ( SELECT  1
            FROM    DW_STAGING.EDW_DBO.DW_TAL_WRITE_OFF_HISTORIC_DATA
            WHERE   Tallyman_Customer_Number = @FocusNum
                    OR Tallyman_Unique_Number = @TallyNum
                    OR Rapid_Unique_Number = @RapidNum )
    BEGIN
        SELECT  *
        FROM    DW_STAGING.EDW_DBO.DW_TAL_WRITE_OFF_HISTORIC_DATA
        WHERE   Tallyman_Customer_Number = @FocusNum
                OR Tallyman_Unique_Number = @TallyNum
                OR Rapid_Unique_Number = @RapidNum
        ORDER BY Last_Updated_Date
    END
IF @@rowcount <> 0
    BEGIN
        PRINT 'DW_STAGING.EDW_DBO.DW_TAL_WRITE_OFF_HISTORIC_DATA'
        SELECT  DW_EDW.EDW_DBO.DW_TAL_IGNORE_WRITE_OFF_CODE_MASTER.*
        FROM    DW_EDW.EDW_DBO.DW_TAL_IGNORE_WRITE_OFF_CODE_MASTER
                INNER JOIN DW_STAGING.EDW_DBO.DW_TAL_WRITE_OFF_HISTORIC_DATA ON Write_Off_Code = Code
                                                              OR Dca_Write_Off_Code = Code
        WHERE   Tallyman_Customer_Number = @FocusNum
                OR Tallyman_Unique_Number = @TallyNum
                OR Rapid_Unique_Number = @RapidNum	
    END