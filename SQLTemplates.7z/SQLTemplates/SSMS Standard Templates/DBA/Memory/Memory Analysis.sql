
-------------------------------------------------------------------------------

SELECT type
	 , memory_node_id
	 , pages_kb
	 , virtual_memory_reserved_kb
	 , virtual_memory_committed_kb
	 , awe_allocated_kb
FROM sys.dm_os_memory_clerks
ORDER BY virtual_memory_reserved_kb DESC;

-------------------------------------------------------------------------------

SELECT name
	 , type
	 , pages_kb
	 , entries_count
FROM sys.dm_os_memory_cache_counters
ORDER BY pages_kb DESC;


-------------------------------------------------------------------------------

SELECT COUNT(*) * 8 / 1024 AS 'Cached Size (MB)'
	 , CASE database_id
	   WHEN 32767 THEN 'ResourceDb'
		   ELSE DB_NAME(database_id)
	   END AS 'Database'
FROM sys.dm_os_buffer_descriptors
GROUP BY DB_NAME(database_id)
	   , database_id
ORDER BY 'Cached Size (MB)' DESC;


-------------------------------------------------------------------------------
--objects in the buffer by database
;WITH src AS
(
   SELECT
       [Object] = o.name,
       [Type] = o.type_desc,
       [Index] = COALESCE(i.name, ''),
       [Index_Type] = i.type_desc,
       p.[object_id],
       p.index_id,
       au.allocation_unit_id
   FROM
       sys.partitions AS p
   INNER JOIN
       sys.allocation_units AS au
       ON p.hobt_id = au.container_id
   INNER JOIN
       sys.objects AS o
       ON p.[object_id] = o.[object_id]
   INNER JOIN
       sys.indexes AS i
       ON o.[object_id] = i.[object_id]
       AND p.index_id = i.index_id
   WHERE
       au.[type] IN (1,2,3)
       AND o.is_ms_shipped = 0
)
SELECT
   src.[Object],
   src.[Type],
   src.[Index],
   src.Index_Type,
   buffer_pages = COUNT_BIG(b.page_id),
   buffer_mb = COUNT_BIG(b.page_id) / 128
FROM
   src
INNER JOIN
   sys.dm_os_buffer_descriptors AS b
   ON src.allocation_unit_id = b.allocation_unit_id
WHERE
   b.database_id = DB_ID()
GROUP BY
   src.[Object],
   src.[Type],
   src.[Index],
   src.Index_Type
ORDER BY
   buffer_pages DESC;


------------------------------------------------------------------------------
--cached plans in memory and the size of the plan
SELECT  text
      , objtype
      , refcounts
      , usecounts
      , size_in_bytes
      , disk_ios_count
      , context_switches_count
      , original_cost
      , current_cost
FROM    sys.dm_exec_cached_plans p
        CROSS APPLY sys.dm_exec_sql_text(plan_handle)
        JOIN sys.dm_os_memory_cache_entries e 
          ON p.memory_object_address = e.memory_object_address
WHERE   cacheobjtype = 'Compiled Plan'
        AND type IN ( 'CACHESTORE_SQLCP', 'CACHESTORE_OBJCP' )
ORDER BY objtype DESC
      , usecounts DESC;