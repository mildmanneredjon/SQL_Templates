DECLARE @path nvarchar(260);

SELECT @path = REVERSE(SUBSTRING(REVERSE([path]), CHARINDEX('\', REVERSE([path])), 260)) + N'log.trc'
FROM sys.traces
WHERE is_default = 1;

SELECT *
FROM sys.fn_trace_gettable(@path, DEFAULT)
WHERE EventClass IN(105,109)
	AND targetusername = 'HO\Khalidr'
ORDER BY DatabaseName, StartTime DESC;

