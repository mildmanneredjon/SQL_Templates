/**
debug particular user permissions
EXECUTE AS USER = ''
EXECUTE AS USER = ''
EXECUTE AS USER = ''

SELECT SUSER_NAME()

SELECT CURRENT_USER

REVERT

SELECT DISTINCT class_desc 
FROM fn_builtin_permissions(DEFAULT)
ORDER BY class_desc;

SELECT * FROM fn_my_permissions('', 'OBJECT')
SELECT * FROM fn_my_permissions(NULL, 'DATABASE')
SELECT * FROM fn_my_permissions('', 'USER')
**/

-----------------------------------------------------------------------------
--all object level permissions in the database

SELECT pr.principal_id, pr.name, pr.type_desc, 
    pr.authentication_type_desc, pe.state_desc, 
    pe.permission_name, s.name + '.' + o.name AS ObjectName
FROM sys.database_principals AS pr
JOIN sys.database_permissions AS pe
    ON pe.grantee_principal_id = pr.principal_id
JOIN sys.objects AS o
    ON pe.major_id = o.object_id
JOIN sys.schemas AS s
    ON o.schema_id = s.schema_id
where pe.class = 1

-------------------------------------------------------------------------------
--http://consultingblogs.emc.com/jamiethomson/archive/2007/02/09/sql-server-2005_3a00_-view-all-permissions.aspx
--list all user permissions on the database

SELECT dp.NAME AS principal_name
    , dp.type_desc AS principal_type_desc
    , o.NAME AS OBJECT_NAME
    , p.permission_name
    , p.state_desc AS permission_state_desc
FROM sys.database_permissions p
    LEFT OUTER JOIN sys.all_objects o
	   ON p.major_id = o.OBJECT_ID
    INNER JOIN sys.database_principals dp
	   ON p.grantee_principal_id = dp.principal_id
where dp.type_desc = 'DATABASE_ROLE'

--SELECT prin.[name] [User], sec.state_desc + ' ' + sec.permission_name [Permission] 
--FROM [sys].[database_permissions] sec 
--  JOIN [sys].[database_principals] prin 
--    ON sec.[grantee_principal_id] = prin.[principal_id] 
----WHERE sec.class = 0 
--ORDER BY [User], [Permission];



SELECT *
FROM sys.database_permissions

-------------------------------------------------------------------------------
--http://stackoverflow.com/questions/1565278/sql-server-find-out-which-users-have-write-access-to-which-tables

--
SELECT u.name, o.name
FROM syspermissions p, sysobjects o, sysusers u
WHERE p.id = o.id
AND u.uid = p.grantee
--AND u.name IN ('UserOne', 'UserTwo', 'UserThree')
AND o.xtype = 'U'
AND p.actadd = 27

--login permissions for sql 2000
exec xp_logininfo

-------------------------------------------------------------------------------
--http://www.sqlservercentral.com/articles/Security/76919/

SET XACT_ABORT OFF;
SET NOCOUNT ON;

DECLARE @principals TABLE
(
 PRIMARY KEY ( principal_type, principal_name, member_name ),
 principal_type VARCHAR(180) NOT NULL,
 principal_name VARCHAR(180) NOT NULL,
 member_name VARCHAR(180) NOT NULL,
 create_date DATETIME NULL,
 modify_date DATETIME NULL,
 admin_role_desc VARCHAR(180) NULL,
 logininfo_note VARCHAR(8000) NULL
);

-- insert all accounts and groups into result:
INSERT INTO @principals
SELECT
 type_desc,
 name,
 '-' AS member_name,
 create_date,
 modify_date,
 (
  CASE IS_SRVROLEMEMBER('sysadmin',name) WHEN 1 THEN 'sysadmin|' ELSE NULL END
  + CASE IS_SRVROLEMEMBER('securityadmin',name) WHEN 1 THEN 'securityadmin|' ELSE NULL END
  + CASE IS_SRVROLEMEMBER('serveradmin',name) WHEN 1 THEN 'serveradmin|' ELSE NULL END
  + CASE IS_SRVROLEMEMBER('setupadmin',name) WHEN 1 THEN 'setupadmin|' ELSE NULL END  
  + CASE IS_SRVROLEMEMBER('processadmin',name) WHEN 1 THEN 'processadmin|' ELSE NULL END  
  + CASE IS_SRVROLEMEMBER('diskadmin',name) WHEN 1 THEN 'diskadmin|' ELSE NULL END  
  + CASE IS_SRVROLEMEMBER('dbcreator',name) WHEN 1 THEN 'dbcreator|' ELSE NULL END  
  + CASE IS_SRVROLEMEMBER('bulkadmin',name) WHEN 1 THEN 'bulkadmin|' ELSE NULL END
 ) AS admin_role_desc,
 NULL AS logininfo_note
FROM sys.server_principals
;

DECLARE @admin_groups TABLE
(
 PRIMARY KEY ( group_type, group_name ),
 group_type VARCHAR(180) NOT NULL,
 group_name VARCHAR(180) NOT NULL
);

DECLARE @logininfo TABLE
(
 PRIMARY KEY ( account_name, permission_path ),
 account_name VARCHAR(180) NOT NULL,
 TYPE VARCHAR(180) NULL,
 privilege VARCHAR(180) NULL,
 mapped_login_name VARCHAR(180) NULL,
 permission_path VARCHAR(180) NOT NULL
);

-- For each domain group with admin privilages,
-- insert one record for each of it's member accounts into the result:
DECLARE @group_type VARCHAR(180), @group_name VARCHAR(180);
SELECT @group_type = '*', @group_name = '*';
WHILE @group_name IS NOT NULL
BEGIN
 SELECT @group_type = NULL, @group_name = NULL;
 SELECT TOP 1 @group_type = principal_type, @group_name = principal_name
  FROM @principals
   WHERE principal_type IN ('windows_group')
    AND member_name = '-'      
    AND admin_role_desc IS NOT NULL
    AND principal_name NOT IN (SELECT group_name FROM @admin_groups);
 IF @group_name IS NOT NULL
 BEGIN
  -- Call xp_logininfo to return all domain accounts belonging to group:
  INSERT @admin_groups VALUES (@group_type, @group_name);
  BEGIN TRY
   DELETE FROM @logininfo;
   INSERT INTO @logininfo
    EXEC master..xp_logininfo @group_name,'members';
   -- Update number of members for group to logininfo_note:
     UPDATE @principals
    SET logininfo_note = 'xp_logininfo returned '+CAST(@@ROWCOUNT AS VARCHAR(9))+' members.'
     WHERE principal_type IN ('windows_group')
      AND principal_name = @group_name
      AND member_name = '-';   
  END TRY
  BEGIN CATCH
   -- If an error occurred, then update it to logininfo_note, and then continue:
     UPDATE @principals
    SET logininfo_note = 'xp_logininfo returned error '+CAST(ERROR_NUMBER() AS VARCHAR(9))
     WHERE principal_type IN ('windows_group')
      AND principal_name = @group_name
      AND member_name = '-';
  END CATCH
  -- For each group member, insert a record into the result:
  INSERT INTO @principals
  SELECT
   @group_type AS principal_type,
   @group_name AS principal_name,
   account_name AS member_name,
   NULL AS create_date,
   NULL AS modify_date,
   (SELECT admin_role_desc
    FROM @principals
     WHERE principal_type = @group_type
     AND principal_name = @group_name
     AND member_name = '-') AS admin_role_desc,
   NULL AS logininfo_note
  FROM @logininfo;
  -- For each group member that is a group,
  -- insert a record of type 'WINDOWS_GROUP' into the result:
  INSERT INTO @principals
  SELECT
   'WINDOWS_GROUP' AS principal_type,
   account_name AS principal_name,
   '-' AS member_name,
   NULL AS create_date,
   NULL AS modify_date,
   (SELECT admin_role_desc
    FROM @principals
     WHERE principal_type = @group_type
     AND principal_name = @group_name
     AND member_name = '-') AS admin_role_desc,
   NULL AS logininfo_note
  FROM @logininfo
   WHERE TYPE = 'group'
   AND NOT EXISTS
    (SELECT 1
     FROM @principals
      WHERE principal_type = 'WINDOWS_GROUP' AND principal_name = account_name AND member_name = '-'
    );
 END; 
END;

-- Return result of only those accounts, groups, and members who have an admin role:
SELECT principal_type, principal_name, logininfo_note, member_name, create_date, modify_date, admin_role_desc
 FROM @principals
  WHERE admin_role_desc IS NOT NULL
   ORDER BY principal_type, principal_name, member_name;
