use msdb
go
exec sp_help_targetserver