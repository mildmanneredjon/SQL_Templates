;WITH task_space_usage AS (
    -- SUM alloc/delloc pages
    SELECT session_id,
           request_id,
           SUM(internal_objects_alloc_page_count) AS alloc_pages,
           SUM(internal_objects_dealloc_page_count) AS dealloc_pages
    FROM sys.dm_db_task_space_usage WITH (NOLOCK)
    WHERE session_id <> @@SPID
    GROUP BY session_id, request_id
)
SELECT TSU.session_id,
       TSU.alloc_pages * 1.0 / 128 AS [internal object MB space],
       TSU.dealloc_pages * 1.0 / 128 AS [internal object dealloc MB space],
       EST.text,
       -- Extract statement from sql text
       ISNULL(
           NULLIF(
               SUBSTRING(
                 EST.text, 
                 ERQ.statement_start_offset / 2, 
                 CASE WHEN ERQ.statement_end_offset < ERQ.statement_start_offset 
                  THEN 0 
                 ELSE( ERQ.statement_end_offset - ERQ.statement_start_offset ) / 2 END
               ), ''
           ), EST.text
       ) AS [statement text],
       EQP.query_plan
FROM task_space_usage AS TSU
INNER JOIN sys.dm_exec_requests ERQ WITH (NOLOCK)
    ON  TSU.session_id = ERQ.session_id
    AND TSU.request_id = ERQ.request_id
OUTER APPLY sys.dm_exec_sql_text(ERQ.sql_handle) AS EST
OUTER APPLY sys.dm_exec_query_plan(ERQ.plan_handle) AS EQP
WHERE EST.text IS NOT NULL OR EQP.query_plan IS NOT NULL
ORDER BY 3 DESC;

SELECT r.session_id
	 , r.request_id
	 , s.host_name AS host_name
	 , s.program_name AS program_name
	 , s.login_name AS login_name
	 , sq.text AS sql_query
	 , t.request_mode AS request_mode
	 , request_type AS lock_request_type
	 , request_status AS lock_request_status
	 , request_lifetime AS lock_request_lifetime
	 , SUM(internal_objects_alloc_page_count) * 1.0 / 128 AS [internal object MB space]
	 , SUM(internal_objects_dealloc_page_count) * 1.0 / 128 AS [internal object dealloc MB space]
FROM sys.dm_exec_requests AS r
	 JOIN sys.dm_exec_sessions AS s
		  ON r.session_id = s.session_id
	 LEFT JOIN master.sys.dm_tran_locks AS t
		  ON r.session_id = t.request_session_id
		 AND r.request_id = t.request_request_id
	 CROSS APPLY sys.dm_exec_sql_text(r.sql_handle)AS sq
				 LEFT JOIN sys.dm_db_task_space_usage AS tu
					  ON r.session_id = tu.session_id
					 AND r.request_id = tu.request_id
GROUP BY r.session_id
	   , r.request_id
	   , s.host_name
	   , s.program_name
	   , s.login_name
	   , sq.text
	   , t.request_mode
	   , request_type
	   , request_status
	   , request_lifetime;      
