--put the db into emergency mode (2k5 onwards)
ALTER DATABASE <Database Name, sysname, > SET EMERGENCY;

--put the db into single user mode to allow the dbcc command to run
ALTER DATABASE <Database Name, sysname, > SET SINGLE_USER;

--backup the tail of the log if possible


--run the DBCC command
DBCC CHECKDB('Database Name, sysname, >',REPAIR_ALLOW_DATA_LOSS);


--if the log cannot be repaired then recreate it
CREATE DATABASE <Database Name, sysname, > ON 
    (FILENAME = N'<MDF File Path, sysname, >')
    FOR ATTACH_REBUILD_LOG;