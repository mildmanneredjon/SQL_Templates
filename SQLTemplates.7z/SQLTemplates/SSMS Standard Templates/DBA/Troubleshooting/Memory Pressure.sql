

-------------------------------------------------------------------------------
--

--http://sqlsimonl.blogspot.co.uk/2012/08/sysdmosringbuffers.html

-- System memory usage
-- if IndicatorsProcess = 0 and IndicatorsSystem <> 0, then its system wide
-- if IndicatorsProcess <> 0 and IndicatorsSystem = 0, then its single process
SELECT  
    EventTime, 
    record.value('(/Record/ResourceMonitor/Notification)[1]', 'varchar(max)') as [Type], 
    CASE record.value('(/Record/ResourceMonitor/IndicatorsProcess)[1]', 'int') 
  WHEN 0 THEN '0 - No single process pressure'
  WHEN 1 THEN '1 - Single Process memory pressure'
  ELSE record.value('(/Record/ResourceMonitor/IndicatorsProcess)[1]', 'varchar(20)') END [SQL2008IndicatorsProcess], 
    CASE record.value('(/Record/ResourceMonitor/IndicatorsSystem)[1]', 'int') 
  WHEN 1 then '1 - High Physical Memory'
  WHEN 2 then '2 - Low Physical Memory'
  WHEN 3 then '4 - Low Virtual Memory' 
  ELSE record.value('(/Record/ResourceMonitor/IndicatorsSystem)[1]', 'varchar(20)') END SQL2008IndicatorsSystem,
    CASE record.value('(/Record/ResourceMonitor/Indicators)[1]', 'int') 
  WHEN 1 then '1 - High Physical Memory'
  WHEN 2 then '2 - Low Physical Memory'
  WHEN 3 then '4 - Low Virtual Memory' 
  ELSE record.value('(/Record/ResourceMonitor/Indicators)[1]', 'varchar(20)') END SQL2005Indicators,
    record.value('(/Record/MemoryRecord/AvailablePhysicalMemory)[1]', 'bigint')/1000 AS [Avail Phys Mem, MB], 
    record.value('(/Record/MemoryRecord/AvailableVirtualAddressSpace)[1]', 'bigint')/1000 AS [Avail VAS, MB] 
FROM ( 
    SELECT 
        DATEADD (ss, (-1 * ((cpu_ticks / CONVERT (float, ( cpu_ticks / ms_ticks ))) - [timestamp])/1000), GETDATE()) AS EventTime, 
        CONVERT (xml, record) AS record 
    FROM sys.dm_os_ring_buffers 
    CROSS JOIN sys.dm_os_sys_info 
    WHERE ring_buffer_type = 'RING_BUFFER_RESOURCE_MONITOR') AS tab 
ORDER BY EventTime DESC;



-------------------------------------------------------------------------------
/**
http://social.msdn.microsoft.com/Forums/sqlserver/en-US/9ff24502-18f9-4b49-9cfa-a584f23b0a45/memory-grants-pending
**/

SELECT session_id, request_id,requested_memory_kb,required_memory_kb,
used_memory_kb,ideal_memory_kb,sql_handle, plan_handle
FROM sys.dm_exec_query_memory_grants


/**
http://searchsqlserver.techtarget.com/tutorial/SQL-Server-queries-with-DMVs-for-examining-bottlenecks
**/
DBCC MEMORYSTATUS

/**
Run DBCC MEMORYSTATUS and observe the values for buffer distribution table. 
If the number of targeted pages decreases over time, it is likely that your 
SQL Server is experiencing external memory pressure. Compare the number of 
targeted pages against the stolen pages. If the number of stolen pages does 
not stabilize over time, the server may eventually get into internal physical 
memory pressure. Here is another SQL Server 2005 query that will expose these same counters:
**/

SELECT * 
FROM SYS.SYSPERFINFO 
WHERE OBJECT_NAME='MSSQL$LOGILITY2:Buffer Manager' 
AND
    (
	   COUNTER_NAME='TARGET PAGES' 
	   OR COUNTER_NAME='TOTAL PAGES' 
	   OR COUNTER_NAME='DATABASE PAGES' 
	   OR COUNTER_NAME='STOLEN PAGES' 
	   OR COUNTER_NAME='FREE PAGES'
    )


/**
Use the following DMV query to determine which SQL Server components 
are consuming the most amount of memory, and observe how this changes 
over time:
**/

SELECT TYPE, SUM(MULTI_PAGES_KB) FROM
SYS.DM_OS_MEMORY_CLERKS WHERE
MULTI_PAGES_KB != 0 GROUP BY TYPE



/**
To get an idea of which individual processes are taking up memory, use the following query:
**/

SELECT 
    TYPE
    , PAGES_ALLOCATED_COUNT 
FROM	SYS.DM_OS_MEMORY_OBJECTS 
WHERE PAGE_ALLOCATOR_ADDRESS 
IN 
    (
	   SELECT TOP 10
	   PAGE_ALLOCATOR_ADDRESS 
	   FROM	SYS.DM_OS_MEMORY_CLERKS 
	   ORDER BY MULTI_PAGES_KB DESC
    ) 
ORDER BY PAGES_ALLOCATED_COUNT DESC

/**
Processes that are disk intensive typically do not have the appropriate 
indexes or have poor execution plans. Here is a DMV query that lists the 
top 25 tables experiencing I/O waits.
**/

SELECT TOP 25 DB_NAME(D.DATABASE_ID)AS DATABASE_NAME
			, QUOTENAME(OBJECT_SCHEMA_NAME(D.OBJECT_ID, D.DATABASE_ID)) + N'.' + QUOTENAME(OBJECT_NAME(D.OBJECT_ID, D.DATABASE_ID))AS OBJECT_NAME
			, D.DATABASE_ID
			, D.OBJECT_ID
			, D.PAGE_IO_LATCH_WAIT_COUNT
			, D.PAGE_IO_LATCH_WAIT_IN_MS
			, D.RANGE_SCANS
			, D.INDEX_LOOKUPS
FROM(SELECT DATABASE_ID
		  , OBJECT_ID
		  , ROW_NUMBER()OVER(PARTITION BY DATABASE_ID ORDER BY SUM(PAGE_IO_LATCH_WAIT_IN_MS)DESC)AS ROW_NUMBER
		  , SUM(PAGE_IO_LATCH_WAIT_COUNT)AS PAGE_IO_LATCH_WAIT_COUNT
		  , SUM(PAGE_IO_LATCH_WAIT_IN_MS)AS PAGE_IO_LATCH_WAIT_IN_MS
		  , SUM(RANGE_SCAN_COUNT)AS RANGE_SCANS
		  , SUM(SINGLETON_LOOKUP_COUNT)AS INDEX_LOOKUPS
	 FROM SYS.DM_DB_INDEX_OPERATIONAL_STATS(NULL, NULL, NULL, NULL)
	 WHERE PAGE_IO_LATCH_WAIT_COUNT > 0
	 GROUP BY DATABASE_ID
			, OBJECT_ID)AS D
	LEFT JOIN(SELECT DISTINCT DATABASE_ID
							, OBJECT_ID
			  FROM SYS.DM_DB_MISSING_INDEX_DETAILS)AS MID
		ON MID.DATABASE_ID = D.DATABASE_ID
	   AND MID.OBJECT_ID = D.OBJECT_ID
WHERE D.ROW_NUMBER > 20
ORDER BY PAGE_IO_LATCH_WAIT_COUNT DESC;

/**
You can also generate a list of columns that should have indexes on them:
**/

SELECT * 
FROM SYS.DM_DB_MISSING_INDEX_GROUPS G 
    JOIN SYS.DM_DB_MISSING_INDEX_GROUP_STATS GS
	   ON GS.GROUP_HANDLE = G.INDEX_GROUP_HANDLE
    JOIN SYS.DM_DB_MISSING_INDEX_DETAILS D 
	   ON G.INDEX_HANDLE = D.INDEX_HANDLE

/**
One of the most frequent contributors to high CPU consumption is stored 
procedure recompilation. Here is a DMV that displays the list of 
the top 25 recompilations:
**/

SELECT TOP 25 
    SQL_TEXT.TEXT
    , SQL_HANDLE
    , PLAN_GENERATION_NUM
    , EXECUTION_COUNT
    , DBID
    , OBJECTID 
select *
FROM SYS.DM_EXEC_QUERY_STATS A
    CROSS APPLY SYS.DM_EXEC_SQL_TEXT(SQL_HANDLE) AS SQL_TEXT 
WHERE PLAN_GENERATION_NUM >1
ORDER BY PLAN_GENERATION_NUM DESC

/**
This DMV lists the top CPU consumers:
**/

SELECT TOP 50 SUM(QS.TOTAL_WORKER_TIME)AS TOTAL_CPU_TIME
			, SUM(QS.EXECUTION_COUNT)AS TOTAL_EXECUTION_COUNT
			, COUNT(*)AS NUMBER_OF_STATEMENTS
			, SQL_TEXT.TEXT
			, QS.PLAN_HANDLE
FROM SYS.DM_EXEC_QUERY_STATS QS
	 CROSS APPLY SYS.DM_EXEC_SQL_TEXT(SQL_HANDLE)AS SQL_TEXT
GROUP BY SQL_TEXT.TEXT
	   , QS.PLAN_HANDLE
ORDER BY SUM(QS.TOTAL_WORKER_TIME)DESC;

/**
Other things that cause high CPU usage are bookmark lookups, 
bad parallelism and looping code.
**/


SELECT
    distinct mcc.cache_address, 
    mcc.name, 
    mcc.type,
    mcc.single_pages_kb,
    mcc.multi_pages_kb, 
    mcc.single_pages_in_use_kb,
    mcc.multi_pages_in_use_kb, 
    mcc.entries_count, 
    mcc.entries_in_use_count,
    mcch.removed_all_rounds_count, 
    mcch.removed_last_round_count

select *
FROM sys.dm_os_memory_cache_counters mcc 
    JOIN sys.dm_os_memory_cache_clock_hands mcch 
 ON (mcc.cache_address = mcch.cache_address)
 
 
SELECT  *
FROM sys.dm_os_memory_cache_clock_hands
WHERE rounds_count > 0