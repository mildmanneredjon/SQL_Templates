SELECT percent_complete as 'Percent Complete', start_time as Start, status as Status, command as Command , estimated_completion_time as ETA,
(estimated_completion_time / 1000/60 /60/ 24) as Days ,
((estimated_completion_time / 1000/60 /60) % 24 ) as Hours,
((estimated_completion_time / 1000/60 ) % 60) as Mins,
((estimated_completion_time / 1000) % 60) as Secs,
total_elapsed_time as Total_Elapsed_Time,
(total_elapsed_time / 1000/60 /60/ 24) as Days ,
((total_elapsed_time / 1000/60 /60) % 24  )as 'Hours',
((total_elapsed_time / 1000/60 ) % 60  )as 'Mins',
((total_elapsed_time / 1000) % 60  )as 'Sec'
FROM sys .dm_exec_requests
WHERE percent_complete > 0
ORDER BY start_time DESC
