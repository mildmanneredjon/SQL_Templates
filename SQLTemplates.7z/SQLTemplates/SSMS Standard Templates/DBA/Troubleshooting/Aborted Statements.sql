SELECT CAST(target_data as xml) AS targetdata
INTO #system_health_data
FROM sys.dm_xe_session_targets xet
JOIN sys.dm_xe_sessions xe
    ON xe.address = xet.event_session_address
WHERE name = 'system_health'
AND xet.target_name = 'ring_buffer';
 
SELECT
    DATEADD(mi, DATEDIFF(mi, GETUTCDATE(), CURRENT_TIMESTAMP), xevents.event_data.value('(@timestamp)[1]', 'datetime2')) AS [err timestamp],
    xevents.event_data.value('(data[@name="severity"]/value)[1]', 'bigint') AS [err severity],
    xevents.event_data.value('(data[@name="error_number"]/value)[1]', 'bigint') AS [err number],
    xevents.event_data.value('(data[@name="message"]/value)[1]', 'nvarchar(512)') AS [err message],
    xevents.event_data.value('(action[@name="sql_text"]/value)[1]', 'nvarchar(max)') AS [query text],
    xevents.event_data.query('.') as [event details]
FROM #system_health_data
CROSS APPLY targetdata.nodes('//RingBufferTarget/event') AS xevents (event_data)
WHERE xevents.event_data.value('(@name)[1]', 'nvarchar(256)')='error_reported';
 
DROP TABLE #system_health_data;

-------------------------------------------------------------------------------

SELECT
    DES.session_id,
    DES.[host_name],
    DES.[program_name],
    DES.login_name,
    DES.last_request_start_time,
    DES.reads,
    DES.writes,
    transaction_isolation_level =
        CASE DES.transaction_isolation_level
            WHEN 0 THEN 'Unspecified'
            WHEN 1 THEN 'Read Uncomitted'
            WHEN 2 THEN 'Read Committed'
            WHEN 3 THEN 'Repeatable Read'
            WHEN 4 THEN 'Serializable'
            WHEN 5 THEN 'Snapshot'
        END,
    DES.open_transaction_count,
    DTDT.database_transaction_begin_time,
    transaction_state =
        CASE DTDT.database_transaction_state
            WHEN 1 THEN 'Not initialized'
            WHEN 3 THEN 'Initialized'
            WHEN 4 THEN 'Open and has generated log records'
            WHEN 5 THEN 'Prepared'
            WHEN 10 THEN 'Committed'
            WHEN 11 THEN 'Aborted'
            WHEN 12 THEN 'Being committed'
        END
FROM sys.dm_exec_sessions AS DES
JOIN sys.dm_tran_session_transactions AS DTST
    ON DTST.session_id = DES.session_id
JOIN sys.dm_tran_database_transactions AS DTDT
    ON DTDT.database_id = DES.database_id
WHERE 
    DES.is_user_process = 1
    AND DTST.is_user_transaction = 1
    AND DTDT.database_transaction_type = 1
    AND DES.open_transaction_count > 0;



-------------------------------------------------------------------------------

SELECT CAST(target_data as xml) AS targetdata
INTO #system_health_data
FROM sys.dm_xe_session_targets xet
JOIN sys.dm_xe_sessions xe
ON xe.address = xet.event_session_address
WHERE name = 'system_health'
AND xet.target_name = 'ring_buffer';

SELECT
DATEADD(mi, DATEDIFF(mi, GETUTCDATE(), CURRENT_TIMESTAMP), xevents.event_data.value('(@timestamp)[1]', 'datetime2')) AS [err timestamp],
xevents.event_data.value('(data[@name="severity"]/value)[1]', 'bigint') AS [err severity],
xevents.event_data.value('(data[@name="error_number"]/value)[1]', 'bigint') AS [err number],
xevents.event_data.value('(data[@name="message"]/value)[1]', 'nvarchar(512)') AS [err message],
xevents.event_data.value('(action[@name="sql_text"]/value)[1]', 'nvarchar(max)') AS [query text],
xevents.event_data.query('.') as [event details]
FROM #system_health_data
CROSS APPLY targetdata.nodes('//RingBufferTarget/event') AS xevents (event_data)
WHERE xevents.event_data.value('(@name)[1]', 'nvarchar(256)')='error_reported';

DROP TABLE #system_health_data;
GO