-------------------------------------------------------------------------------
--find cross AG calls
SELECT 
	(
		SELECT MAX(AG2.NAME)
		FROM sys.dm_hadr_database_replica_states HDRS2
			INNER JOIN sys.availability_groups ag2
				ON HDRS2.group_id = ag2.group_id
		WHERE db_id() = HDRS2.database_id
			AND HDRS.is_local = 1
	)
	, db_name() [Source Database]
	, OBJECT_NAME (referencing_id) [Object]
	, ag.name [referenced_availability_group]
	, referenced_server_name
	, referenced_database_name
	, referenced_schema_name
	, referenced_entity_name
FROM sys.sql_expression_dependencies SED
	LEFT OUTER JOIN sys.dm_hadr_database_replica_states HDRS
		ON SED.referenced_database_name = db_name(HDRS.database_id)
			AND HDRS.is_local = 1
	INNER JOIN sys.availability_groups ag
		ON HDRS.group_id = ag.group_id
WHERE referenced_database_name IS NOT NULL
order by referenced_database_name;

-------------------------------------------------------------------------------
--get referenced objects that have been used recently
SELECT 
	(
		SELECT MAX(AG2.NAME)
		FROM sys.dm_hadr_database_replica_states HDRS2
			INNER JOIN sys.availability_groups ag2
				ON HDRS2.group_id = ag2.group_id
		WHERE db_id() = HDRS2.database_id
			AND HDRS.is_local = 1
	)
	, db_name() [Source Database]
	, OBJECT_NAME (referencing_id) [Object]
	, ag.name [referenced_availability_group]
	, referenced_server_name
	, referenced_database_name
	, referenced_schema_name
	, referenced_entity_name
	, ps.last_execution_time
FROM sys.sql_expression_dependencies SED
	LEFT OUTER JOIN sys.dm_hadr_database_replica_states HDRS
		ON SED.referenced_database_name = db_name(HDRS.database_id)
			AND HDRS.is_local = 1
	INNER JOIN sys.availability_groups ag
		ON HDRS.group_id = ag.group_id
	INNER JOIN sys.dm_exec_procedure_stats ps
		ON SED.referenced_id = ps.object_id
WHERE referenced_database_name IS NOT NULL
order by referenced_database_name;


-------------------------------------------------------------------------------
--find synonyms and the procedures referenced by them
SELECT s.name, s.base_object_name, sre.referencing_schema_name, sre.referencing_entity_name
FROM SYS.SYNONYMS s
	CROSS APPLY sys.dm_sql_referencing_entities(SCHEMA_NAME(schema_id) + '.' + OBJECT_NAME(object_id),'OBJECT') sre

