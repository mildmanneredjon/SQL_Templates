
DECLARE @SQL VARCHAR(MAX)

SET @SQL = ''
SET CONCAT_NULL_YIELDS_NULL OFF;
SET NOCOUNT ON ;
-------------------------------------------------------------------------------
--script out operators
select @SQL = @SQL 
    + 'IF NOT EXISTS (SELECT 1 FROM msdb..sysoperators WHERE name = ''' + name + ''')'
    + CHAR(13)
    + 'BEGIN'
    + CHAR(13)
    + 'EXEC msdb.dbo.sp_add_operator @name=N''' + name + ''', '
    + '@enabled=' + CONVERT(VARCHAR(200),enabled) + ', '
    + '@pager_days=' + CONVERT(VARCHAR(200),pager_days) + ', '
    + '@email_address=N''' + email_address + ''';'
    + CHAR(13)
    + 'END'
    + CHAR(13)
    + CHAR(13)
from msdb..sysoperators so


-------------------------------------------------------------------------------
--script out alerts

select @SQL = @SQL 
    + 'IF NOT EXISTS (SELECT 1 FROM msdb..sysalerts WHERE name = ''' + sa.name + ''')'
    + CHAR(13)
    + 'BEGIN'
    + CHAR(13)
    + 'EXEC msdb.dbo.sp_add_alert @name=N''' + sa.[name] + ''','    
    + '@message_id=' + CONVERT(VARCHAR(200),sa.message_id) + ','
    + '@severity=' + CONVERT(VARCHAR(200),sa.severity) + ','
    + '@enabled=' + CONVERT(VARCHAR(200),sa.enabled) + ','
    + '@delay_between_responses=' + CONVERT(VARCHAR(200),sa.delay_between_responses) + ','
    + '@include_event_description_in=' + CONVERT(VARCHAR(200),sa.include_event_description) + ','
    + '@job_id=''' + CONVERT(VARCHAR(200),sa.job_id) + ''';'
    + CHAR(13)
    + 'END'
    + CHAR(13)
    + CHAR(13)
from msdb..sysalerts sa
    LEFT OUTER JOIN msdb..sysnotifications sn
        ON sa.id = sn.alert_id
    INNER JOIN msdb..sysoperators so
        ON sn.operator_id = so.id

-------------------------------------------------------------------------------
--script out notifications
 SELECT @SQL = @SQL 
    + 'IF NOT EXISTS (SELECT 1 FROM msdb..sysnotifications WHERE alert_id = ''' + CONVERT(VARCHAR(200),sa.id) + ''')'
    + CHAR(13)
    + 'BEGIN'
    + CHAR(13)	  
    + 'EXEC msdb.dbo.sp_add_notification @alert_name=N''' 
    + sa.name + ''', @operator_name=N''' 
    + so.name + ''', @notification_method = ' 
    + CONVERT(VARCHAR(200),sn.notification_method) + ';'
    + CHAR(13)
    + 'END'
    + CHAR(13)
    + CHAR(13)
from msdb..sysalerts sa
    INNER JOIN msdb..sysnotifications sn
        ON sa.id = sn.alert_id
    INNER JOIN msdb..sysoperators so
        ON sn.operator_id = so.id


SELECT @SQL
