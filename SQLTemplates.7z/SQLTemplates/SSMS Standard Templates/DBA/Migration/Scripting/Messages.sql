DECLARE @SQL VARCHAR(MAX)

SET @SQL = ''
SET CONCAT_NULL_YIELDS_NULL OFF;
SET NOCOUNT ON ;
-------------------------------------------------------------------------------
select @SQL = @SQL + 'IF NOT EXISTS (SELECT 1 FROM sys.sysmessages WHERE error = ' + convert(varchar(200),error) + ')'
    + CHAR(13)
    + 'BEGIN'
    + CHAR(13)
    + 'exec sp_addmessage @msgnum = ' + convert(varchar(200),error)
    + ', @severity = ' + convert(varchar(200),severity)
    + ', @msgtext = ' + [description]
    + ', @lang= ' + convert(varchar(200),msglangid)
    + CHAR(13)
    + 'END'
    + CHAR(13)
from sys.sysmessages
where error > 50000

SELECT @SQL