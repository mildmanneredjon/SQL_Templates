select top 100 *
from sys.stats
where object_id = object_id('')

	

DBCC SHOW_STATISTICS ('','') WITH STAT_HEADER

--UPDATE STATISTICS () WITH FULLSCAN

--UPDATE STATISTICS () WITH SAMPLE 50 PERCENT;

update statistics 

SELECT * 
FROM sys.dm_db_index_physical_stats (DB_ID(N''), OBJECT_ID(N''), null, NULL , 'LIMITED');

