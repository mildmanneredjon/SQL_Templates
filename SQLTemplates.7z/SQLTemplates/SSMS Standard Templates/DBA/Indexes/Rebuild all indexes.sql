DECLARE @SQL NVARCHAR(MAX) = ''

SELECT @SQL = @SQL + 'ALTER INDEX ALL ON [' + sch.name + '].[' + st.name + '] REBUILD WITH (ONLINE=OFF)' + char(13)
FROM sys.tables st
	INNER JOIN sys.schemas sch
		ON st.schema_id = sch.schema_id
WHERE st.type = 'U'
	AND NOT EXISTS (SELECT 1 FROM sys.columns sc WHERE st.object_id = sc.object_id AND sc.is_computed = 1)
ORDER by st.name

EXEC sp_executesql @sql


