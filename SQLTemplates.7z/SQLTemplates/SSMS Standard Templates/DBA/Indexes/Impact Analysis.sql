
DECLARE @TableName sysname = '',
		@Updates BIT = 1	--change to 0 if you want just select related stored procs
	
SELECT o.name,
	ps.cached_time,
	ps.execution_count,
	(ps.execution_count/DATEDIFF(MINUTE,ps.cached_time,GETDATE()))*60 AS executionsPerHour,
	ps.last_execution_time, 
	ps.last_elapsed_time/1000 last_elapsed_time_ms,
	ps.last_logical_reads,
	ps.last_physical_reads,
	ps.last_worker_time/1000 last_worker_time_ms,
	(ps.total_worker_time / 1000 ) / ps.execution_count AS avg_worker_time_ms ,
	ps.total_logical_reads / ps.execution_count AS avg_logical_reads ,
	( ps.total_elapsed_time / 1000 ) / ps.execution_count AS avg_elapsed_time_ms
FROM sys.objects o
LEFT OUTER JOIN sys.dm_exec_procedure_stats ps ON o.object_id = ps.object_id
WHERE o.type = 'P' 
AND EXISTS (
	SELECT 1  FROM sys.dm_sql_referenced_entities(OBJECT_SCHEMA_NAME(o.OBJECT_ID) + '.' + OBJECT_NAME(o.object_id),'Object')
	WHERE is_updated = @Updates -- comment out if you want all 
	AND referenced_entity_name = @TableName
	)
AND o.object_id IN (
	SELECT referencing_id
	FROM sys.sql_expression_dependencies AS sed
	INNER JOIN sys.objects AS o ON sed.referencing_id = o.object_id
	WHERE referenced_id = OBJECT_ID(@TableName)
	)

-------------------------------------------------------------------------------
-- Specify table
	DECLARE @TableName sysname = '<Table Name, sysname, Table_Name>',
-- Specify 1 for Updates or 0 for Select related stored procs
		@Updates BIT = 1

	DECLARE @columnList table (
				columnName varchar(255)
				)
	
	--Insert columns you want to check if effected here 
	INSERT INTO @columnList  (columnName)
	VALUES 
		('')
		,('')
		,('')
	
SELECT o.name,
	ps.cached_time,
	ps.execution_count,
	(ps.execution_count/DATEDIFF(MINUTE,ps.cached_time,GETDATE()))*60 AS executionsPerHour,
	ps.last_execution_time, 
	ps.last_elapsed_time/1000 last_elapsed_time_ms,
	ps.last_logical_reads,
	ps.last_physical_reads,
	ps.last_worker_time/1000 last_worker_time_ms,
	(ps.total_worker_time / 1000 ) / ps.execution_count AS avg_worker_time_ms ,
	ps.total_logical_reads / ps.execution_count AS avg_logical_reads ,
	( ps.total_elapsed_time / 1000 ) / ps.execution_count AS avg_elapsed_time_ms
FROM sys.objects o
LEFT OUTER JOIN sys.dm_exec_procedure_stats ps ON o.object_id = ps.object_id
WHERE o.type = 'P' 
AND EXISTS (
	SELECT 1  FROM sys.dm_sql_referenced_entities(OBJECT_SCHEMA_NAME(o.OBJECT_ID) + '.' + OBJECT_NAME(o.object_id),'Object')
	WHERE is_updated = @Updates -- comment out if you want all 
	AND referenced_entity_name = @TableName
	AND referenced_minor_id IN (select column_id 
								from sys.tables t
								inner join sys.columns c on t.object_id = c.object_id
								where t.object_id = OBJECT_ID(@TableName)
								and c.name in (select columnName from @columnList)
								)
	)
AND o.object_id IN (
	SELECT referencing_id
	FROM sys.sql_expression_dependencies AS sed
	INNER JOIN sys.objects AS o ON sed.referencing_id = o.object_id
	WHERE referenced_id = OBJECT_ID(@TableName)
	)

