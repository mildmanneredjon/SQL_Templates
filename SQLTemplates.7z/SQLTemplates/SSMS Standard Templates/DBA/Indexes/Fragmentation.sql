SELECT * 
FROM sys.dm_db_index_physical_stats (DB_ID(N'<Database Name, sysname, Database_Name>'), OBJECT_ID(N'<Table Name, sysname, Table_Name>'), 1, NULL , 'LIMITED');
