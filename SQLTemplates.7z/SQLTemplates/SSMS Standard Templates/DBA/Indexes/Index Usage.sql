
--write to read ratios
SELECT 
	DB_NAME(database_id)
	, OBJECT_NAME(OBJECT_ID)
	, s.name
	, (user_updates * 1.0) / (user_seeks + user_scans+user_lookups + 1) writes_per_read
	, ius.*
FROM sys.dm_db_index_usage_stats ius
    INNER JOIN sys.sysindexes S 
	   ON ius.object_id = s.id 
		  AND ius.index_id = s.indid
WHERE OBJECT_ID = OBJECT_ID('<Table Name, sysname, Table_Name>')
ORDER BY (user_updates * 1.0) / (user_seeks + user_scans+user_lookups + 1) desc
    

SELECT 
DB_NAME(database_id)
, OBJECT_NAME(OBJECT_ID)
, s.name
, ius.*
FROM sys.dm_db_index_usage_stats ius
    INNER JOIN sys.sysindexes S 
	   ON ius.object_id = s.id 
		  AND ius.index_id = s.indid
WHERE s.name IN ('<Index Name, sysname, Index_Name>')
    AND OBJECT_ID = OBJECT_ID('<Table Name, sysname, Table_Name>')
    
    
    
--find what columns are indexed    
SELECT ind.name
    , ind.index_id
    , ic.index_column_id
    , col.name
    --, ind.*
    --, ic.*
    --, col.*
FROM sys.indexes ind
    INNER JOIN sys.index_columns ic 
	   ON ind.object_id = ic.object_id 
		  AND ind.index_id = ic.index_id
    INNER JOIN sys.columns col 
	   ON ic.object_id = col.object_id 
		  AND ic.column_id = col.column_id 
    INNER JOIN sys.tables t 
	   ON ind.object_id = t.object_id
WHERE ind.is_primary_key = 0 
    --AND ind.is_unique = 0 
    --AND ind.is_unique_constraint = 0
    AND t.is_ms_shipped = 0
    AND t.object_id = object_id('<Table Name, sysname, Table_Name>')
ORDER BY t.name
    , ind.name
    , ind.index_id
    , ic.index_column_id    