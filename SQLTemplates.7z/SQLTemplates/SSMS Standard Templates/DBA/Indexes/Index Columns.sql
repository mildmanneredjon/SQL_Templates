select distinct o.name object_name
	, i.name index_name
	, c.name column_name
	, i.is_disabled
	, ic.key_ordinal
from sys.indexes i
	inner join sys.objects o
		on i.object_id = o.object_id
	inner join sys.index_columns ic
		on i.index_id = ic.index_id
			and ic.object_id = i.object_id
	inner join sys.columns c
		on c.column_id = ic.column_id
			and c.object_id = o.object_id
ORDER BY o.name, i.name, ic.key_ordinal
