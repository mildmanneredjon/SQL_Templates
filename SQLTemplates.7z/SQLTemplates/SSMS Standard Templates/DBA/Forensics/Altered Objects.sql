DECLARE @path nvarchar(260);

SELECT @path = REVERSE(SUBSTRING(REVERSE([path]), CHARINDEX('\', REVERSE([path])), 260)) + N'log.trc'
FROM sys.traces
WHERE is_default = 1;

--SELECT EventClass, MAX(te.name)
--FROM sys.fn_trace_gettable(@path,  DEFAULT) GT
--	INNER JOIN sys.trace_events TE
--		ON TE.trace_event_id = GT.EventClass
--GROUP BY EventClass


SELECT *
FROM sys.fn_trace_gettable(@path, DEFAULT)
WHERE EventClass IN(164)
ORDER BY DatabaseName, StartTime DESC;