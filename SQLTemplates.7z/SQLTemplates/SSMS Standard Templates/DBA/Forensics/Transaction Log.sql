SELECT *
FROM ::fn_dblog(NULL, NULL)



/**
0 - minimal info
1 - slightly more info
2 - detailed info including pageid, slotid
3 - full information about each operation
4 - full information on each operation in addition to hex dump of current data row
**/
DBCC LOG (<DATABASE NAME>, 3)