SELECT SERVERPROPERTY('ComputerNamePhysicalNetBIOS') AS [CurrentNodeName] 

SELECT * FROM fn_virtualservernodes() 

SELECT * FROM sys.dm_os_cluster_nodes 

SELECT * FROM fn_servershareddrives() 

SELECT * FROM sys.dm_io_cluster_shared_drives