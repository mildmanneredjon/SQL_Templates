DECLARE @Report TABLE
(
	Check_Value VARCHAR(max)
)

-------------------------------------------------------------------------------
--check for use of encryption functions
INSERT INTO @Report
SELECT 'Encrypted functions found ' + CONVERT(VARCHAR(128),object_name(sm.object_id))
FROM sys.sql_modules sm
WHERE definition like '%DecryptByKey%'
	OR definition like '%EncryptByKey%'

-------------------------------------------------------------------------------
--check for max size
INSERT INTO @Report
SELECT name + ' has exceeded file size rule thresholds'
FROM sys.database_files
WHERE (max_size = -1 OR max_size > 268000000)
	OR (CASE is_percent_growth
		WHEN 1 THEN (growth/100) 
		WHEN 0 THEN (growth/size)
		END) > 0.2

-------------------------------------------------------------------------------
--check for schema seperation
INSERT INTO @Report
SELECT 'schema report: ' + ss.name + CONVERT(VARCHAR(128),COUNT(*))
FROM sys.schemas ss
	INNER JOIN sys.objects so
		ON ss.schema_id = so.schema_id
WHERE ss.name <> 'sys'
GROUP BY ss.name

-------------------------------------------------------------------------------
--check for heaps
INSERT INTO @Report
SELECT object_name(si.object_id) + ' is a heap'
FROM sys.indexes si
	INNER JOIN sys.objects so
		ON si.object_id = so.object_id
WHERE si.index_id = 0
	AND so.type NOT IN ('P', 'S', 'IT', 'TT')

-------------------------------------------------------------------------------
--check for tables with no primary key
INSERT INTO @Report
select t.name + ' has no primary key defined'
from sys.key_constraints kc
	RIGHT OUTER JOIN sys.tables t
		ON KC.Parent_object_id = t.object_id
WHERE KC.object_id IS NULL

-------------------------------------------------------------------------------
--check for triggers
INSERT INTO @Report
SELECT 'trigger found ' + name
FROM sys.triggers

-------------------------------------------------------------------------------
--Compatability level
INSERT INTO @Report
SELECT 'compatibility level is ' + CONVERT(VARCHAR(128),compatibility_level)
FROM sys.databases
WHERE db_id() = database_id

-------------------------------------------------------------------------------
--Trustworthy turned on
INSERT INTO @Report
SELECT 'Database has trustworthy enabled'
FROM sys.databases
WHERE db_id() = database_id
	AND is_trustworthy_on > 0

-------------------------------------------------------------------------------
--db chaining enabled
INSERT INTO @Report
SELECT 'Database chainging is turned on'
FROM sys.databases
WHERE db_id() = database_id
	AND is_db_chaining_on > 0

-------------------------------------------------------------------------------
--check for recursive triggers enabled
INSERT INTO @Report
SELECT 'Collation is set to ' + CONVERT(VARCHAR(128),DATABASEPROPERTYEX(db_name(), 'Collation'))
UNION ALL
SELECT 'AutoShrink is set to ' + CONVERT(VARCHAR(128),DATABASEPROPERTYEX(db_name(), 'IsAutoShrink'))
UNION ALL
SELECT 'AutoShrink is set to ' + CONVERT(VARCHAR(128),DATABASEPROPERTYEX(db_name(), 'IsAutoClose'))
UNION ALL
SELECT 'AutoUpdateStatistics is set to ' + CONVERT(VARCHAR(128),DATABASEPROPERTYEX(db_name(), 'IsAutoUpdateStatistics'))
UNION ALL
SELECT 'FulltextEnabled is set to ' + CONVERT(VARCHAR(128),DATABASEPROPERTYEX(db_name(), 'IsFulltextEnabled'))
UNION ALL
SELECT 'ParameterizationForced is set to ' + CONVERT(VARCHAR(128),DATABASEPROPERTYEX(db_name(), 'IsParameterizationForced'))
UNION ALL
SELECT 'Database replication publication status is' + CONVERT(VARCHAR(128),DATABASEPROPERTYEX(db_name(), 'IsPublished'))
UNION ALL
SELECT 'Recovery is ' + CONVERT(VARCHAR(128),DATABASEPROPERTYEX(db_name(), 'Recovery'))
UNION ALL
SELECT 'RecursiveTriggersEnabled is set to ' + CONVERT(VARCHAR(128),DATABASEPROPERTYEX(db_name(), 'IsRecursiveTriggersEnabled'))

-------------------------------------------------------------------------------
--use of xp_cmdshell
INSERT INTO @Report
SELECT 'xp_cmdshell was found in ' + object_name(object_id)
FROM sys.sql_modules
WHERE definition like '%xp_cmdhsell%'

-------------------------------------------------------------------------------
--use of Cursors
INSERT INTO @Report
SELECT 'the use of cursors was found in ' + object_name(object_id)
FROM sys.sql_modules
WHERE definition like '%cursor%'

-------------------------------------------------------------------------------
--
INSERT INTO @Report
SELECT 'Custom assemblies found ' + name
FROM sys.assemblies
WHERE assembly_id > 1

-------------------------------------------------------------------------------
--elevated Security check

--are any users db_owner?
INSERT INTO @Report
SELECT '[' + DP.name + '] is in the db_owner database role and can affect the schema'
FROM sys.database_role_members drm
	INNER JOIN sys.database_principals dp
		on drm.member_principal_id = dp.principal_id
	INNER JOIN sys.database_principals dp2
		ON DRM.role_principal_id = DP2.principal_id
WHERE DP2.name = 'db_owner'
	AND dp.name <> 'dbo'

-------------------------------------------------------------------------------
--can any users affect the schema?
INSERT INTO @Report
SELECT '[' + DP.name + '] is in the db_owner database role and can affect the schema'
FROM sys.database_role_members drm
	INNER JOIN sys.database_principals dp
		on drm.member_principal_id = dp.principal_id
	INNER JOIN sys.database_principals dp2
		ON DRM.role_principal_id = DP2.principal_id
WHERE DP2.name = 'ddl_admin'
	AND dp.name <> 'dbo'

-------------------------------------------------------------------------------
--use of GUIDs in the database
INSERT INTO @Report
SELECT sc.name + ' in table ' + object_name(sc.object_id) + ' uses uniqueidentifiers'
FROM sys.columns sc
	INNER JOIN sys.objects SO
		ON sc.object_id = so.object_id
WHERE user_type_id = 36
	AND so.type NOT IN ('P', 'S', 'IT', 'TT')

-------------------------------------------------------------------------------
--check for different collations in the columns to the database
INSERT INTO @Report
SELECT object_name(sc.object_id) + ' ' + sc.name
FROM sys.columns sc
	INNER JOIN sys.objects SO
		ON sc.object_id = so.object_id
WHERE collation_name <> DATABASEPROPERTYEX(db_name(), 'Collation') 
	AND so.type NOT IN ('P', 'S', 'IT')

-------------------------------------------------------------------------------
--
INSERT INTO @Report
SELECT  'Database [' + [name] + '] has auto-create-stats disabled.  SQL Server uses statistics to build better execution plans, and without the ability to automatically create more, performance may suffer.'  AS Details
FROM    sys.databases
WHERE   is_auto_create_stats_on = 0

-------------------------------------------------------------------------------
--
INSERT INTO @Report
SELECT  'Database [' + [name] + '] has auto-update-stats disabled.  SQL Server uses statistics to build better execution plans, and without the ability to automatically update them, performance may suffer.'  AS Details
FROM    sys.databases
WHERE   is_auto_update_stats_on = 0

-------------------------------------------------------------------------------
--
INSERT INTO @Report
SELECT  'Database [' + [name] + '] has auto-update-stats-async enabled.  When SQL Server gets a query for a table with out-of-date statistics, it will run the query with the stats it has - while updating stats to make later queries better. The initial run of the query may suffer, though.'  AS Details
FROM    sys.databases
WHERE   is_auto_update_stats_async_on = 1

-------------------------------------------------------------------------------
--
INSERT INTO @Report
SELECT  'Database [' + [name] + '] has forced parameterization enabled.  SQL Server will aggressively reuse query execution plans even if the applications do not parameterize their queries.  This can be a performance booster with some programming languages, or it may use universally bad execution plans when better alternatives are available for certain parameters.'  AS Details
FROM    sys.databases
WHERE   is_parameterization_forced = 1

-------------------------------------------------------------------------------
--
INSERT INTO @Report
SELECT  'Database [' + [name] + '] is a replication publisher, subscriber, or distributor.'  AS Details
FROM    sys.databases
WHERE is_published = 1
        OR is_subscribed = 1
        OR is_merge_published = 1
        OR is_distributor = 1;
       
-------------------------------------------------------------------------------
--
INSERT INTO @Report
SELECT  'Database [' + [name] + '] has date correlation enabled.  This is not a default setting, and it has some performance overhead.  It tells SQL Server that date fields in two tables are related, and SQL Server maintains statistics showing that relation.'  AS Details
FROM    sys.databases
WHERE   is_date_correlation_on = 1

-------------------------------------------------------------------------------
--
INSERT INTO @Report
 SELECT  CAST(occurrence AS VARCHAR(10)) + ' instances of order hinting have been recorded since restart.  This means queries are bossing the SQL Server optimizer around, and if they don''t know what they''re doing, this can cause more harm than good.  This can also explain why DBA tuning efforts aren''t working.' AS Details
FROM    sys.dm_exec_query_optimizer_info
WHERE   counter = 'order hint'
AND occurrence > 1

-------------------------------------------------------------------------------
--
INSERT INTO @Report
SELECT  CAST(occurrence AS VARCHAR(10)) + ' instances of join hinting have been recorded since restart.  This means queries are bossing the SQL Server optimizer around, and if they don''t know what they''re doing, this can cause more harm than good.  This can also explain why DBA tuning efforts aren''t working.' AS Details
FROM    sys.dm_exec_query_optimizer_info
WHERE   counter = 'join hint'
AND occurrence > 1

-------------------------------------------------------------------------------
--
INSERT INTO @Report
SELECT 'The [' + name + '] extended stored procedure is in the master database. CLR may be in use, and the master database now needs to be part of your backup/recovery planning.'
FROM    master.sys.extended_procedures

-------------------------------------------------------------------------------
--
INSERT INTO @Report
SELECT ('The index [' + DB_NAME() + '].[' + s.name + '].[' + o.name + '].[' + i.name + '] is a leftover hypothetical index from the Index Tuning Wizard or Database Tuning Advisor.  This index is not actually helping performance and should be removed.') 
from sys.indexes i INNER JOIN sys.objects o ON i.object_id = o.object_id INNER JOIN sys.schemas s ON o.schema_id = s.schema_id 
WHERE i.is_hypothetical = 1

-------------------------------------------------------------------------------
--
INSERT INTO @Report
SELECT ('The index [' + DB_NAME() + '].[' + s.name + '].[' + o.name + '].[' + i.name + '] is disabled.  This index is not actually helping performance and should either be enabled or removed.') 
from sys.indexes i INNER JOIN sys.objects o ON i.object_id = o.object_id INNER JOIN sys.schemas s ON o.schema_id = s.schema_id 
WHERE i.is_disabled = 1

-------------------------------------------------------------------------------
--
INSERT INTO @Report
SELECT DISTINCT ('The [' + DB_NAME() + '] database has foreign keys that were probably disabled, data was changed, and then the key was enabled again.  Simply enabling the key is not enough for the optimizer to use this key - we have to alter the table using the WITH CHECK CHECK CONSTRAINT parameter.') 
from sys.foreign_keys i INNER JOIN sys.objects o ON i.parent_object_id = o.object_id INNER JOIN sys.schemas s ON o.schema_id = s.schema_id 
WHERE i.is_not_trusted = 1 AND i.is_not_for_replication = 0 AND i.is_disabled = 0

-------------------------------------------------------------------------------
--
INSERT INTO @Report
SELECT ('The check constraint [' + DB_NAME() + '].[' + s.name + '].[' + o.name + '].[' + i.name + '] is not trusted - meaning, it was disabled, data was changed, and then the constraint was enabled again.  Simply enabling the constraint is not enough for the optimizer to use this constraint - we have to alter the table using the WITH CHECK CHECK CONSTRAINT parameter.') 
from sys.check_constraints i INNER JOIN sys.objects o ON i.parent_object_id = o.object_id 
INNER JOIN sys.schemas s ON o.schema_id = s.schema_id 
WHERE i.is_not_trusted = 1 AND i.is_not_for_replication = 0 AND i.is_disabled = 0

-------------------------------------------------------------------------------
--
INSERT INTO @Report
SELECT ('Database [' + DB_NAME() + '] has query plan guides so a query will always get a specific execution plan. If you are having trouble getting query performance to improve, it might be due to a frozen plan. Review the DMV sys.plan_guides to learn more about the plan guides in place on this server.') AS Details 
FROM sys.plan_guides WHERE is_disabled = 0

-------------------------------------------------------------------------------
--
INSERT INTO @Report
SELECT  'The [' + DB_NAME() + '] database has objects with fill factor <> 0. This can cause memory and storage performance problems, but may also prevent page splits.'
FROM    sys.indexes 
WHERE   fill_factor <> 0 AND fill_factor <> 100 AND is_disabled = 0 AND is_hypothetical = 0

-------------------------------------------------------------------------------
--
INSERT INTO @Report
SELECT ('[' + DB_NAME() + '].[' + SPECIFIC_SCHEMA + '].[' + SPECIFIC_NAME + '] has WITH RECOMPILE in the stored procedure code, which may cause increased CPU usage due to constant recompiles of the code.') 
from INFORMATION_SCHEMA.ROUTINES WHERE ROUTINE_DEFINITION LIKE N'%WITH RECOMPILE%'

-------------------------------------------------------------------------------
--wide tables
INSERT INTO @Report
SELECT object_name(object_id) + ' has more then 50 columns'
FROM SYS.COLUMNS
GROUP BY object_name(object_id)
HAVING COUNT(*) > 50

-------------------------------------------------------------------------------
--check for a lack of foreign key constraints
SELECT object_name(si.object_id)
FROM sys.indexes si
    INNER JOIN sys.objects so
        ON si.object_id = so.parent_object_id
where si.index_id = 1
    and si.object_id not in (select fk.referenced_object_id from sys.foreign_keys fk)
    and si.object_id not in (select fk.object_id from sys.foreign_keys fk)
    and so.type = 'U'

-------------------------------------------------------------------------------
SELECT * FROM @Report