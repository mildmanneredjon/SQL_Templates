DECLARE @TableName sysname = ''

select * from sys.objects where name = @TableName


--get missing indexes
SELECT db.name AS MissingIndexName, mid.statement, mid.object_id,
	migs.avg_total_user_cost * ( migs.avg_user_impact / 100.0 )
	* ( migs.user_seeks + migs.user_scans ) AS improvement_measure ,
	'CREATE INDEX [missing_index_'
	+ CONVERT (VARCHAR, mig.index_group_handle) + '_'
	+ CONVERT (VARCHAR, mid.index_handle) + '_'
	+ LEFT(PARSENAME(mid.statement, 1), 32) + ']' + ' ON '
	+ mid.statement
	+ ' (' + ISNULL(mid.equality_columns, '')
	+ CASE WHEN mid.equality_columns IS NOT NULL
	AND mid.inequality_columns IS NOT NULL THEN ','
	ELSE ''
	END + ISNULL(mid.inequality_columns, '') + ')'
		+ ISNULL(' INCLUDE ('
		+ mid.included_columns
		+ ')', '')
	AS create_index_statement ,
	migs.* ,
	mid.database_id ,
	mid.[object_id]
FROM sys.dm_db_missing_index_groups mig
	INNER JOIN sys.dm_db_missing_index_group_stats migs
		ON migs.group_handle = mig.index_group_handle
	INNER JOIN sys.dm_db_missing_index_details mid
		ON mig.index_handle = mid.index_handle
	INNER JOIN sys.databases db
		ON mid.database_id = db.database_id
WHERE migs.avg_total_user_cost * ( migs.avg_user_impact / 100.0 )
	* ( migs.user_seeks + migs.user_scans ) > 10
	AND mid.object_id = object_id(@TableName)
ORDER BY migs.avg_total_user_cost * migs.avg_user_impact
	* ( migs.user_seeks + migs.user_scans ) DESC


--Get Table Size
exec sp_spaceused @TableName
--Get Current Index Size

SELECT
    i.name                  AS CurrentIndexSize_Name,
    SUM(s.used_page_count) * 8   AS IndexSizeKB
FROM sys.dm_db_partition_stats  AS s 
	JOIN sys.indexes                AS i
		ON s.[object_id] = i.[object_id] AND s.index_id = i.index_id
WHERE s.[object_id] = object_id( @TableName)
GROUP BY i.name
ORDER BY i.name


--Get TableUsage Stats

select top 10  i.name CurrentIndexUsage_Name,i.type_desc, ius.* From sys.dm_db_index_usage_stats ius
inner join sys.indexes i on ius.index_id = i.index_id and ius.object_id = i.object_id
--inner join sys.objects o on i.object_id = o.object_id
where i.object_id = OBJECT_ID(@TableName)
and database_id = db_id()

--dependencies

SELECT OBJECT_SCHEMA_NAME ( referencing_id ) AS dependencies_and_Exec_schema_name,
    OBJECT_NAME(referencing_id) AS referencing_entity_name, 
    o.type_desc AS referencing_desciption, 
       ps.cached_time,
       ps.execution_count,
       ps.last_execution_time, 
       ps.last_elapsed_time/1000 last_elapsed_time_ms,
       ps.last_logical_reads,
       ps.last_physical_reads,
       ps.last_worker_time/1000 last_worker_time_ms,
       (ps.execution_count/datediff(MINUTE,ps.cached_time,getdate()))*60 as executionsPerHour,
       (ps.total_worker_time / 1000 ) / ps.execution_count AS avg_worker_time_ms ,
       ps.total_logical_reads / ps.execution_count AS avg_logical_reads ,
       ( ps.total_elapsed_time / 1000 ) / ps.execution_count AS avg_elapsed_time_ms,
          COALESCE(COL_NAME(referencing_id, referencing_minor_id), '(n/a)') AS referencing_minor_id, 
    referencing_class_desc, referenced_class_desc,
    referenced_server_name, referenced_database_name, referenced_schema_name,
    referenced_entity_name, 
    COALESCE(COL_NAME(referenced_id, referenced_minor_id), '(n/a)') AS referenced_column_name,
    is_caller_dependent, is_ambiguous
FROM sys.sql_expression_dependencies AS sed
	INNER JOIN sys.objects AS o ON sed.referencing_id = o.object_id
	LEFT OUTER JOIN sys.dm_exec_procedure_stats ps on o.object_id = ps.object_id
WHERE referenced_id = OBJECT_ID(@TableName)
