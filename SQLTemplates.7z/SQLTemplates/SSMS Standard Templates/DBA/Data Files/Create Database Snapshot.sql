
DECLARE @SQL VARCHAR(MAX)
DECLARE @Restore_SQL VARCHAR(MAX)

SET @SQL = 'CREATE DATABASE [' + DB_NAME() + '_ss] ON ' 

select @SQL = @SQL + CHAR(13) + '(NAME = ''' + NAME + ''', FILENAME = ''' + LEFT(FILENAME, LEN(FILENAME) - 4) + '.ss''),'
from dbo.sysfiles
where groupid <> 0

SET @SQL = LEFT(@SQL, LEN(@SQL) - 1)

select @SQL = @SQL + CHAR(13) + ' AS SNAPSHOT OF [' + DB_NAME() + ']'

SELECT @SQL

SET @Restore_SQL = 'RESTORE DATABASE [' + DB_NAME() + '] FROM 
DATABASE_SNAPSHOT = ''' + DB_NAME() + '_ss'';'

SELECT @Restore_SQL

