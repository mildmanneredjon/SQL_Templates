declare @Test table 
(
	database_name sysname
	, database_id int
	, file_id int
	, file_name sysname
	, file_type_id int
	, file_type varchar(500)
	, physical_name varchar(500)
	, size_in_mb varchar(500)
	, space_used_in_mb varchar(500)
	, max_size_in_mb varchar(500)
	, available_space_for_growth_in_mb varchar(500)
	, growth_in_mb varchar(500)
	, growth_in_percent varchar(500)
	, autogrow_enabled varchar(500)
	, autogrow_unlimited varchar(500)
	, database_state_desc varchar(500)
	, database_read_only varchar(500)
	, file_read_only varchar(500)
	, total varchar(500)
	, Used decimal(20,2)
	, [free space percentage] decimal(20,2)
)
	
declare @SQL nvarchar(max)
select @SQL = coalesce(@SQL,'') + 
'USE ' + QUOTENAME(Name) + '
select DB.name database_name
	, AF.dbid database_id
	, ssf.fileid
	, ssf.name filename
	, file_type_id
	, file_type
	, ssf.filename physical_name
	, size_in_mb
	, space_used_in_mb
	, max_size_in_mb
	, available_space_for_growth_in_mb
	, growth_in_mb
	, growth_in_percent
	, autogrow_enabled
	, autogrow_unlimited
	, database_state_desc
	, database_read_only
	, file_read_only
	, ssf.size*8 as total
	, FILEPROPERTY (AF.name, ''spaceused'')*8 as used
	, ((ssf.size*8) - (FILEPROPERTY (AF.name, ''spaceused'')*8))*100/(ssf.size*8) as [free_space_percentage]
from sys.sysALTfiles AF 
	inner join sys.sysfiles ssf 
		on ssf.name=AF.name COLLATE SQL_Latin1_General_CP1_CI_AS
	INNER JOIN sys.databases DB 
		ON AF.dbid=DB.database_id 
where ssf.groupid<>1' from sys.databases

insert into @Test
execute(@SQL)
 
select * from @Test order by database_name

select * from sys.sysaltfiles




select DB.name database_name
	, AF.dbid database_id
	, ssf.fileid
	, ssf.name filename
	, ssf.groupid file_type_id
	, ssf.filename physical_name
	, ssf.size*8 size_in_mb
	, FILEPROPERTY (AF.name, 'spaceused')*8 space_used_in_mb
	, ssf.maxsize*8 max_size_in_mb
	--, available_space_for_growth_in_mb
	--, growth_in_mb
	--, growth_in_percent
	--, autogrow_enabled
	--, autogrow_unlimited
	, state_desc database_state_desc
	, is_read_only database_read_only
	--, file_read_only
	--, db.*
	, ssf.*
	, ssf.size*8 as total
	, ((ssf.size*8) - (FILEPROPERTY (AF.name, 'spaceused')*8))*100/(ssf.size*8) as [free_space_percentage]
from sys.sysALTfiles AF 
	inner join sys.sysfiles ssf 
		on ssf.name=AF.name COLLATE SQL_Latin1_General_CP1_CI_AS
	INNER JOIN sys.databases DB 
		ON AF.dbid=DB.database_id 


