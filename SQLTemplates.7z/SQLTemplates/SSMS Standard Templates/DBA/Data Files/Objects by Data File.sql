SELECT so.name, ds.name, SUM(au.data_pages) * 0.0078125 total_size_MB
FROM sys.objects so 
	INNER JOIN sys.partitions sp
		ON so.object_id = sp.object_id
	INNER JOIN sys.allocation_units au
		ON sp.hobt_id = au.container_id
	INNER JOIN sys.data_spaces ds
		ON au.data_space_id = ds.data_space_id
WHERE ds.name = 'PRIMARY'
GROUP BY so.name, ds.name
ORDER BY ds.name, SUM(au.data_pages) * 0.0078125 desc
