SELECT t.NAME AS TableName ,
       --p.rows AS RowCounts,
       SUM( a.total_pages
          ) * 8 / 1024 AS TotalSpaceMB , 
       SUM( a.used_pages
          ) * 8 / 1024 AS UsedSpaceMB , 
       (SUM( a.total_pages
           ) - SUM( a.used_pages
                  )) * 8 / 1024 AS UnusedSpaceMB
  FROM
       sys.tables t
       INNER JOIN sys.indexes i ON t.OBJECT_ID = i.object_id
       INNER JOIN sys.partitions p ON i.object_id = p.OBJECT_ID
                                  AND i.index_id = p.index_id
       INNER JOIN sys.allocation_units a ON p.partition_id = a.container_id
  WHERE t.NAME IN( SELECT t.name
                     FROM
                          sys.tables t
                          INNER JOIN sys.indexes i ON t.object_id = i.object_id
                          INNER JOIN sys.columns c ON t.object_id = c.object_id
                          INNER JOIN sys.types st ON st.system_type_id = C.system_type_id
                     WHERE i.type = 0
                       AND t.type = 'U'
                       AND (st.name IN( 'text' , 'ntext' , 'xml' , 'image' ,'geometry' , 'geography')
                         OR st.name IN( 'varchar' , 'nvarchar')
                        AND c.max_length = -1)
                 )
  GROUP BY t.Name , p.Rows
  ORDER BY t.Name;