
--check for numeric columns with long precisions
SELECT *
	, ((Actual_Data_Length - Suggested_Data_Length) * Rows) * 1.0 / 1024 / 1024 / 1024 AS Estimated_Space_Saving_GB
FROM 
(
	SELECT s.name schemaname
		, so.name objectname
		, sc.name columnname
		, SUM(max_length) AS Actual_Data_Length
		, SUM(9) AS Suggested_Data_Length
		, MAX(SP.Rows) Rows
	FROM sys.objects so
		INNER JOIN sys.schemas s
			ON so.schema_id = s.schema_id
		INNER JOIN sys.columns sc
			ON so.object_id = sc.object_id
		INNER JOIN sys.partitions sp
			ON sc.object_id = sp.object_id
	WHERE user_type_id = 108
		AND precision > 19
	GROUP BY s.name, so.name, sc.name
) AS A

