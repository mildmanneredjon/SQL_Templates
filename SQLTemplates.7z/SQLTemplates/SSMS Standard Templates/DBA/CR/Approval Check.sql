
--what time is the change scheduled, are there any jobs running then?



--is the server listed on HOSQUESTION
SELECT *
FROM dbo.All_Online_PFMS_SQL_Servers
WHERE SQL_SERVER_NAME LIKE '%RSSHARMONIC%'

SELECT *
FROM dbo.Server_Descriptions 
WHERE name LIKE '%RSSHARMONIC%'

SELECT *
FROM all_database_info
WHERE servername LIKE '%RSSHARMONIC%'

