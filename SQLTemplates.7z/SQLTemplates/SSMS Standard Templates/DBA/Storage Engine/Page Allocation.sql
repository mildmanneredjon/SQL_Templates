SELECT o.object_id
	,iau.first_iam_page
	,s.name AS schema_name
	,o.name AS table_name
	,i.name AS index_name
	,is_ms_shipped AS system
	,p.index_id
	,i.type AS index_type
	,iau.type AS allocation_unit_type
	,CASE iau.type
		WHEN 1 THEN 'Row Data'
		WHEN 2 THEN 'LOB Data'
		WHEN 3 THEN 'Row Overflow Data'
	END AS type_description
	,iau.used_pages
	,iau.total_pages
	,'(' + CONVERT (VARCHAR (6),
	CONVERT (INT, SUBSTRING (iau.first_page, 6, 1) +
		SUBSTRING (iau.first_page, 5, 1))) +
	':' + CONVERT (VARCHAR (20),
	CONVERT (INT, SUBSTRING (iau.first_page, 4, 1) +
		SUBSTRING (iau.first_page, 3, 1) +
		SUBSTRING (iau.first_page, 2, 1) +
		SUBSTRING (iau.first_page, 1, 1))) +
	')' AS [First Page],
	'(' + CONVERT (VARCHAR (6),
	CONVERT (INT,
		SUBSTRING (iau.root_page, 6, 1) +
		SUBSTRING (iau.root_page, 5, 1))) +
	':' + CONVERT (VARCHAR (20),
	CONVERT (INT,
		SUBSTRING (iau.root_page, 4, 1) +
		SUBSTRING (iau.root_page, 3, 1) +
		SUBSTRING (iau.root_page, 2, 1) +
		SUBSTRING (iau.root_page, 1, 1))) +
	')' AS [Root Page],
	'(' + CONVERT (VARCHAR (6),
	CONVERT (INT,
		SUBSTRING (iau.first_iam_page, 6, 1) +
		SUBSTRING (iau.first_iam_page, 5, 1))) +
	':' + CONVERT (VARCHAR (20),
	CONVERT (INT,
		SUBSTRING (iau.first_iam_page, 4, 1) +
		SUBSTRING (iau.first_iam_page, 3, 1) +
		SUBSTRING (iau.first_iam_page, 2, 1) +
		SUBSTRING (iau.first_iam_page, 1, 1))) +
	')' AS [First IAM Page]
FROM   sys.all_objects o
	   INNER JOIN sys.schemas s ON o.schema_id = s.schema_id 
	   INNER JOIN sys.partitions p ON p.object_id = o.object_id
       INNER JOIN sys.indexes i ON i.object_id = o.object_id AND i.index_id = p.index_id
	   INNER JOIN sys.system_internals_allocation_units iau ON iau.container_id = p.partition_id
ORDER BY is_ms_shipped desc, s.name asc , o.name asc


SELECT o.object_id
	, iau.first_iam_page
	, s.name AS schema_name
	, o.name AS table_name
	, i.name AS index_name
	, is_ms_shipped AS system
	, p.index_id
	, i.type AS index_type
	, iau.type AS allocation_unit_type
	, CASE iau.type
			WHEN 1 THEN 'Row Data'
			WHEN 2 THEN 'LOB Data'
			WHEN 3 THEN 'Row Overflow Data'
		END AS type_description
	, iau.used_pages
	, iau.total_pages
	, CONVERT (INT, SUBSTRING (iau.first_page, 6, 1) +
			SUBSTRING (iau.first_page, 5, 1)) AS [First Page File]
	, CONVERT (INT, SUBSTRING (iau.first_page, 4, 1) +
			SUBSTRING (iau.first_page, 3, 1) +
			SUBSTRING (iau.first_page, 2, 1) +
			SUBSTRING (iau.first_page, 1, 1)) AS [First Page]
	, CONVERT (INT,
			SUBSTRING (iau.root_page, 6, 1) +
			SUBSTRING (iau.root_page, 5, 1)) AS [Root Page File]
	, CONVERT (INT,
			SUBSTRING (iau.root_page, 4, 1) +
			SUBSTRING (iau.root_page, 3, 1) +
			SUBSTRING (iau.root_page, 2, 1) +
			SUBSTRING (iau.root_page, 1, 1)) AS [Root Page]
	, CONVERT (INT,
			SUBSTRING (iau.first_iam_page, 6, 1) +
			SUBSTRING (iau.first_iam_page, 5, 1)) AS [First IAM Page File]
	, CONVERT (INT,
			SUBSTRING (iau.first_iam_page, 4, 1) +
			SUBSTRING (iau.first_iam_page, 3, 1) +
			SUBSTRING (iau.first_iam_page, 2, 1) +
			SUBSTRING (iau.first_iam_page, 1, 1)) AS [First IAM Page]
FROM   sys.all_objects o
	INNER JOIN sys.schemas s 
		ON o.schema_id = s.schema_id 
	INNER JOIN sys.partitions p 
		ON p.object_id = o.object_id
	INNER JOIN sys.indexes i 
		ON i.object_id = o.object_id AND i.index_id = p.index_id
	INNER JOIN sys.system_internals_allocation_units iau 
		ON iau.container_id = p.partition_id
ORDER BY is_ms_shipped desc, s.name asc , o.name asc