--http://stackoverflow.com/questions/1540192/searching-for-table-index-scans

WITH XMLNAMESPACES(DEFAULT N'http://schemas.microsoft.com/sqlserver/2004/07/showplan'),
CachedPlans
(
	PlanHandle,
	Objectid,
	ObjectName,
	CacheObjectType
)
AS
(
	SELECT
		cp.plan_handle AS PlanHandle
		, pa2.value AS Objectid
		, OBJECT_NAME(CONVERT(bigint,pa2.value)) AS ObjectName
		, cp.cacheobjtype AS CacheObjectType
	FROM sys.dm_exec_cached_plans cp
		CROSS APPLY sys.dm_exec_plan_attributes(cp.plan_handle) pa
		CROSS APPLY sys.dm_exec_plan_attributes(cp.plan_handle) pa2
	WHERE pa.attribute = 'dbid'
		and pa.value = DB_ID()
		and pa2.attribute = 'objectid'
		and cp.objtype = 'Proc'
)
SELECT *
FROM
(
	SELECT 
		PlanHandle
		, ObjectName
		, Referenced_Object_Name
		, RelOp.op.value(N'@PhysicalOp', N'varchar(50)') AS PhysicalOperator
		, RelOp.op.value(N'@EstimatedTotalSubtreeCost ', N'float') AS EstimatedCost
		, RelOp.op.value(N'@EstimateRows', N'float') AS EstimatedRows
	FROM 
		(
			SELECT
				PlanHandle
				, ObjectName
				, Object_Name(referenced_id) Referenced_Object_Name
			FROM CachedPlans
				INNER JOIN sys.sql_expression_dependencies AS sed
					ON sed.referencing_id = CachedPlans.objectid
			WHERE CacheObjectType = N'Compiled Plan'
				AND Object_Name(referenced_id) = '<Table Name, sysname, Table_Name>'
		) AS A
		CROSS APPLY sys.dm_exec_query_plan(PlanHandle) qp
		CROSS APPLY qp.query_plan.nodes(N'//RelOp') RelOp (op)
) AS B
WHERE (PhysicalOperator = 'Clustered Index Scan' or PhysicalOperator = 'Table Scan'
	or PhysicalOperator = 'Index Scan')
