--taken from Grant Finchley - SQL Server Execution Plans
SELECT TOP 100 qt.text AS 'SP Name'
	, qs.execution_count AS 'Execution Count'
	, qs.execution_count / DATEDIFF(Second, qs.creation_time, GETDATE())AS 'Calls/Second'
	, qs.total_worker_time / qs.execution_count AS 'AvgWorkerTime'
	, qs.total_worker_time AS 'TotalWorkerTime'
	, qs.total_elapsed_time / qs.execution_count AS 'AvgElapsedTime'
	, qs.max_logical_reads
	, qs.max_logical_writes
	, qs.total_physical_reads
	, DATEDIFF(Minute, qs.creation_time, GETDATE())AS 'Age in Cache'
	, qp.query_plan AS QueryPlan
	, SUBSTRING
		(
			qt.text,
			qs.statement_start_offset/2,
			(CASE WHEN qs.statement_end_offset = -1
				THEN LEN(CONVERT(nvarchar(MAX), qt.text)) * 2
				ELSE qs.statement_end_offset
				END - qs.statement_start_offset)/2
		) SQLStatement
FROM sys.dm_exec_query_stats AS qs
       CROSS APPLY sys.dm_exec_sql_text(qs.sql_handle)AS qt
       OUTER APPLY sys.dm_exec_query_plan(qs.plan_handle) as qp
WHERE qt.dbid = DB_ID() -- Filter by current database
ORDER BY qs.execution_count DESC;

-------------------------------------------------------------------------------
select top 10 object_name(qp.objectid) AS ObjectName
    , refcounts
    , usecounts
    , objtype
    , db_name(dbid)
    , qp.query_plan
from sys.dm_exec_cached_plans cp
    CROSS APPLY sys.dm_exec_query_plan(cp.plan_handle) as qp
WHERE qp.objectid = object_id('<Procedure Name, sysname, up_procedure>')


select *
from sys.dm_exec_cached_plans cp
    CROSS APPLY sys.dm_exec_plan_attributes(cp.plan_handle) pa
    OUTER APPLY sys.dm_exec_query_plan(cp.plan_handle) as qp
WHERE pa.attribute = 'objectid'
	and cp.objtype = 'Proc'
    and pa.value = object_id('<Procedure Name, sysname, up_procedure>')

select object_name(convert(int,pa.value))
    , refcounts
    , usecounts
    , objtype
    , cp.plan_handle
from sys.dm_exec_cached_plans cp
    CROSS APPLY sys.dm_exec_plan_attributes(cp.plan_handle) pa    
WHERE pa.attribute = 'objectid'
    and cp.objtype = 'Proc'
ORDER BY object_name(convert(int,pa.value))



