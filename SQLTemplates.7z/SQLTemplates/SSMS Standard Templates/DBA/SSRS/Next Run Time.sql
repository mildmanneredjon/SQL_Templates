/****** Script for SelectTopNRows command from SSMS  ******/
SELECT c.name, sc.LastRunTime, dateadd(minute,sc.minutesinterval,Sc.LastRunTime)
  FROM [dbo].[Schedule] Sc
	INNER JOIN [ReportSchedule] rs
		ON SC.ScheduleID = rs.ScheduleID
	INNER JOIN Subscriptions Su
		ON su.SubscriptionID = rs.SubscriptionID
	INNER JOIN Catalog c
		ON rs.ReportID = c.ItemID
where sc.RecurrenceType = 3