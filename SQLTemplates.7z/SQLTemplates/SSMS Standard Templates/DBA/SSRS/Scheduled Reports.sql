SELECT TOP 1000 c.*
  FROM [ReportServer].[dbo].[Subscriptions] sub
	INNER JOIN ReportServer..[Catalog] c
		on sub.Report_OID = C.Itemid
  where laststatus = 'Pending'

  --exec ReportServer.dbo.AddEvent @EventType='TimedSubscription', @EventData='374913d3-b3d9-405a-98d7-6f8a827bfea0'