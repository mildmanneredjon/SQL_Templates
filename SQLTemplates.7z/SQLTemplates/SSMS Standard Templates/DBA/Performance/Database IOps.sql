DECLARE @crdate DATETIME, @hr VARCHAR(50), @min VARCHAR(5)


--get sql server uptime
SELECT @crdate=crdate FROM sysdatabases WHERE NAME='tempdb'


--get the file performance stats
SELECT
	DB_NAME(database_id)
	, num_of_reads *1.0 / (sample_ms / 1000) Read_IOps
	, num_of_writes * 1.0 / (sample_ms / 1000) Write_IOps
	, (num_of_bytes_read / 1024 / 1024) * 1.0 / (sample_ms/1000) Read_Throughput_MB
	, (num_of_bytes_written / 1024 / 1024) * 1.0 / (sample_ms/1000) Write_Throughput_MB
	, *
FROM sys.dm_io_virtual_file_stats(null,null)

SELECT SUM(pending_disk_io_count) AS [Number of pending I/Os] FROM sys.dm_os_schedulers 


