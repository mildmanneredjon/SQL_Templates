SELECT object_name(convert(int,pa.value)) ObjectName
		  , qs.execution_count AS [Execution Count]
		  , total_logical_reads / qs.execution_count AS AvgLogicalReads
		  , qs.max_logical_reads
		  , total_logical_reads
		  , qs.total_physical_reads
		  , qs.total_worker_time / qs.execution_count AS AvgWorkerTime
		  , qs.max_worker_time
		  , qs.total_worker_time
		  , qs.total_elapsed_time / qs.execution_count AS AvgElapsedTime
		  , qs.max_elapsed_time
		  , qs.total_elapsed_time
		  , qs.total_logical_writes / qs.execution_count AS AvgLogicalWrites
		  , qs.max_logical_writes
		  , qs.total_logical_writes
		  , qs.execution_count / DATEDIFF(Second, qs.creation_time, GETDATE())AS [Calls/Second]
		  , DATEDIFF(Minute, qs.creation_time, GETDATE())AS 'Age in Cache'
		  , qt.dbid
FROM sys.dm_exec_query_stats AS qs
	CROSS APPLY sys.dm_exec_sql_text(qs.sql_handle)AS qt
	CROSS APPLY sys.dm_exec_plan_attributes(qs.plan_handle) pa
WHERE qt.dbid = DB_ID() -- Filter by current database
	and qt.text like '%<Procedure Name, sysname, up_procedure>%'
	and pa.attribute = 'objectid'
    and pa.value = object_id('<Procedure Name, sysname, up_procedure>')



select *
from sys.dm_exec_cached_plans cp
    CROSS APPLY sys.dm_exec_plan_attributes(cp.plan_handle) pa
    OUTER APPLY sys.dm_exec_query_plan(cp.plan_handle) as qp
WHERE pa.attribute = 'objectid'
    and pa.value = object_id('<Procedure Name, sysname, up_procedure>')