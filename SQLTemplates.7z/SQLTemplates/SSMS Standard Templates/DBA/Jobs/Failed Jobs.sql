use msdb
go
select 'FAILED' as Status, cast(sj.name as varchar(100)) as "Job Name",
       cast(sjs.step_id as varchar(5)) as "Step ID",
       cast(sjs.step_name as varchar(50)) as "Step Name",
       dbo.agent_datetime(sjh.run_date, sjh.run_time) 'Start Date Time',
       sjh.message as "Message"
	   , sjh.run_status
from sysjobs sj
join sysjobsteps sjs 
 on sj.job_id = sjs.job_id
join sysjobhistory sjh 
 on sj.job_id = sjh.job_id and sjs.step_id = sjh.step_id
where sjh.run_status NOT IN (1, 4)
  and dbo.agent_datetime(sjh.run_date, sjh.run_time) > DATEADD(D,-3,GETDATE())
	AND cast(sjs.step_name as varchar(50)) NOT IN ('<Job step Name, sysname, Job_Step>')

