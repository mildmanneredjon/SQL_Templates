select 'EXEC msdb..sp_update_job @job_name = ''' + name + ''', @enabled = 1'
from msdb..sysjobs sj
where sj.enabled = 1

select 'EXEC msdb..sp_update_job @job_name = ''' + name + ''', @enabled = 0'
from msdb..sysjobs sj
where sj.enabled = 0