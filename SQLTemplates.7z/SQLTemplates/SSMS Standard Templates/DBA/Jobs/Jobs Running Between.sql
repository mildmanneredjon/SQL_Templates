SELECT
    @@SERVERNAME [ServerName]
    , name
	, freq_subday_interval
    , [Frequency]
    , [Interval]
	, [Schedule Start Time]
	, endtime
	, Frequency
	, interval
	, enabled
FROM
(
	SELECT
		j.name 
		, ss.freq_subday_interval
		, [Schedule Start Time] = 
			CONVERT(VARCHAR,CONVERT(DATETIME,RTRIM(run_date)) 
			+ ((active_start_time * 9
			+ active_start_time % 10000 * 6
			+ active_start_time % 100 * 10) / 216e4), 114)
		, endTime = 
			CONVERT(VARCHAR,CONVERT (DATETIME,RTRIM(run_date)) 
			+ ((run_time * 9 
				+ run_time % 10000 * 6 
				+ run_time % 100 * 10) / 216e4)
			+ ((run_duration * 9
				+ run_duration % 10000 * 6
				+ run_duration % 100 * 10) / 216e4), 114)
		, [Frequency] = CASE(SS.freq_type)
				WHEN 1 THEN 'Once'
				WHEN 4 THEN 'Daily'
				WHEN 8 THEN (CASE WHEN (SS.freq_recurrence_factor > 1) 
							   THEN  'Every ' 
								+ CONVERT(VARCHAR(3),SS.freq_recurrence_factor) 
								+ ' Weeks'  else 'Weekly'  END)
				WHEN 16 THEN (CASE WHEN (SS.freq_recurrence_factor > 1) 
							   THEN  'Every ' 
								+ convert(varchar(3),SS.freq_recurrence_factor) 
								+ ' Months' else 'Monthly' END)
				WHEN 32 THEN 'Every ' 
					+ CONVERT(VARCHAR(3),ss.freq_recurrence_factor) 
					+ ' Months'
				WHEN 64 THEN 'SQL Startup'
				WHEN 128 THEN 'SQL Idle'
			ELSE '??'
		END
		, [Interval] = 
		CASE
		   WHEN (freq_type = 1)                       
			  THEN 'One time only'
		   WHEN (freq_type = 4 AND freq_interval = 1) 
			  THEN 'Every Day'
		   WHEN (freq_type = 4 AND freq_interval > 1) 
			  THEN 'Every ' + CONVERT(VARCHAR(10),freq_interval) + ' Days'
		   WHEN (freq_type = 8) 
			  THEN (SELECT 'Weekly Schedule' = D1 + D2 + D3 + D4 + D5 + D6 + D7
		   FROM 
		   (
			  SELECT 
				 ss.schedule_id
				 , freq_interval
				 , 'D1' = CASE WHEN (freq_interval & 1  <> 0) 
								 THEN 'Sun ' ELSE '' END
				 , 'D2' = CASE WHEN (freq_interval & 2  <> 0) 
								 THEN 'Mon '  ELSE '' END
				 , 'D3' = CASE WHEN (freq_interval & 4  <> 0) 
								 THEN 'Tue '  ELSE '' END
				 , 'D4' = CASE WHEN (freq_interval & 8  <> 0) 
								 THEN 'Wed '  ELSE '' END
				 , 'D5' = CASE WHEN (freq_interval & 16 <> 0) 
								 THEN 'Thu '  ELSE '' END
				 , 'D6' = CASE WHEN (freq_interval & 32 <> 0) 
								 THEN 'Fri '  ELSE '' END
				 , 'D7' = CASE WHEN (freq_interval & 64 <> 0) 
								 THEN 'Sat '  ELSE '' END 
			 FROM msdb..sysschedules ss

					WHERE freq_type = 8
		   ) AS F
		WHERE schedule_id = ss.schedule_id
		)
		WHEN (freq_type = 16) 
		   THEN 'Day ' + CONVERT(VARCHAR(2),freq_interval)
		WHEN (freq_type = 32) 
		   THEN 
		(
		   SELECT freq_rel + WDAY
		   FROM 
				 (
					SELECT 
						ss.schedule_id
						, 'freq_rel' = 
						   CASE(freq_relative_interval)
							  WHEN 1 THEN 'First'
							  WHEN 2 THEN 'Second'
							  WHEN 4 THEN 'Third'
							  WHEN 8 THEN 'Fourth'
							  WHEN 16 THEN 'Last'
							  ELSE '??'
						   END
						, 'WDAY'     = 
						   CASE (freq_interval)
							  WHEN 1 THEN ' Sun'
							  WHEN 2 THEN ' Mon'
							  WHEN 3 THEN ' Tue'
							  WHEN 4 THEN ' Wed'
							  WHEN 5 THEN ' Thu'
							  WHEN 6 THEN ' Fri'
							  WHEN 7 THEN ' Sat'
							  WHEN 8 THEN ' Day'
							  WHEN 9 THEN ' Weekday'
							  WHEN 10 THEN ' Weekend'
							  ELSE '??'
						   END
					FROM msdb..sysschedules ss
					WHERE ss.freq_type = 32
				 ) AS WS
		   WHERE WS.schedule_id = ss.schedule_id
		)
		END
		, j.enabled
	FROM msdb..sysjobhistory jh 
			INNER JOIN msdb..sysjobs j 
				ON j.job_id = jh.job_id 
			LEFT OUTER JOIN msdb..sysjobschedules S
				ON j.job_id = s.job_id
			LEFT OUTER JOIN msdb..sysschedules SS
				ON ss.schedule_id = s.schedule_id
	where run_duration = 0
) AS A
WHERE ([Schedule Start Time] > '00:30:00:000'
	AND endtime < '04:00:00:000'
	AND [Schedule Start Time] < '04:00:00:000')
	OR ([Schedule Start Time] < '04:00:00:000'
		AND endtime > '04:00:00:000')
GROUP BY     
	name
	, freq_subday_interval
    , [Frequency]
    , [Interval]
	, [Schedule Start Time]
	, endtime
	, Frequency
	, interval
	, enabled