
SELECT *
FROM    sys.xml_schema_collections XSC JOIN sys.xml_schema_namespaces XSN
    ON (XSC.xml_collection_id = XSN.xml_collection_id)
WHERE    XSC.name = 'myCollection' 


SELECT XML_SCHEMA_NAMESPACE (N'dbo', N'SystemItemConfigurationSC')